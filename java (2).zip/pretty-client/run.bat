@echo off
setlocal
cd /d "%~dp0"
set "J="
for %%D in ("%ProgramFiles%\Eclipse Adoptium" "%ProgramFiles%\Java" "%ProgramFiles%\Microsoft" "%ProgramFiles%\Zulu" "%ProgramFiles%\BellSoft" "%ProgramFiles%\Amazon Corretto" "%ProgramFiles(x86)%\Eclipse Adoptium" "%USERPROFILE%\.jdks" "%LOCALAPPDATA%\Programs\Eclipse Adoptium") do (
  if exist "%%~D" for /d %%K in ("%%~D\*21*") do if exist "%%K\bin\javac.exe" set "J=%%K"
)
if "%J%"=="" (
  echo Java 21 not found. Install Temurin 21 JDK from adoptium.net and run this file again.
  pause
  exit /b 1
)
set "JAVA_HOME=%J%"
set "PATH=%J%\bin;%PATH%"
echo Using Java: %J%
call gradlew.bat runClient
pause
