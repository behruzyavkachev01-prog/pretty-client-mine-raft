PrettyClient 1.8 (Fabric, Minecraft 1.21.4, Java 21) - 119 modules

Code: src/client/java/com/pretty/client/
  PrettyClient.java  core, config, events
  Modules.java       modules, batch 1 (add new ones here)
  Modules2.java      modules, batch 2
  Descs.java         tooltip texts (RU) shown when you hover a module
  WorldRender.java   ESP, StorageESP, OreESP, ProjectileESP, LightLevel, trajectories
  Hud.java           HUD overlays (Compass, ServerInfo, ItemCounter, InventoryHUD ...)
  Gui.java           ClickGUI (Right Shift)
  ModsScreen.java    "Mods & Packs": one-click install from Modrinth
  PrettyTitle.java   main menu
  Ui.java            draws all text with the client fonts

Run in dev:  run.bat  or  gradlew.bat runClient   (Linux/Mac: ./gradlew runClient)
Build jar:   gradlew.bat build       -> build/libs/pretty-client-1.8.0.jar (not the -sources jar)
Install:     jar into .minecraft/mods + Fabric API 0.119.4+1.21.4, JDK 21

Right Shift = ClickGUI (LMB toggle, RMB settings, MMB bind key, search bar, themes)
Hover a module for ~0.3 s -> tooltip with what it does. Selected module shows its description on the right.
C = zoom (hold)      Config: .minecraft/config/prettyclient.txt

Mods & Packs (button in the main menu and at the bottom-left of the ClickGUI)
  Mods:   Sodium, Lithium, FerriteCore, ImmediatelyFast, Entity Culling, ModernFix, Krypton,
          Dynamic FPS, Iris, Mod Menu. "Install optimization pack" installs the first seven.
  Packs:  Faithful 32x / 64x, Default Dark Mode, Bare Bones, Better Leaves, Low Fire.
  Files come from the official Modrinth API for 1.21.4, SHA-512 is verified, required
  dependencies are installed too. Mods need a game restart. Packs: Download -> Enable.
  Installed files are tracked in config/prettyclient-installed.txt.

Fonts: assets/pretty/font/ui.json and title.json (Poppins + Carlito for Cyrillic, both SIL OFL).
  If text sits too high/low, change "shift" in those two json files; "size" changes the text size.

pretty.accesswidener is needed by FastPlace, FastBreak and NoJumpDelay.

--- v1.2 changes ---
AccountsScreen.java / AccountManager.java: offline account manager in the main menu ("Accounts"). No password,
  nick only (3-16: a-z 0-9 _). Stored in config/prettyaccounts.txt, last account is restored on start.
  Needs 2 new lines in pretty.accesswidener (Minecraft.user accessible + mutable).
Gui.java: ClickGUI redesigned as 5 glass columns (Combat / Movement / Visuals / Player / Other), Right Shift.
  LMB toggle, RMB or dots = settings popup, MMB bind, search at the bottom.
ShaderHands (Visual): animated colour aura + shimmer over first-person hands (HUD overlay, no mixin).

--- v1.3 changes ---
Built-in Minimap removed (Minimap.java deleted). Xaero's Minimap + Xaero's World Map are in Mods & Packs (Modrinth).
Modules3.java (new): SwingAnimation, ShiftTap, HitRange, ClickGuiWalk, TargetEsp, ChinaHat, World (no rain),
  Particles, Zoom (now a module, key C), ItemScroller, StreamerMode.
Modules with no mixins only; ViewModel / Motion Blur / NoRender / SelfNametags need mixins and are not included.

--- v1.4 changes ---
First mixins: src/client/resources/pretty.mixins.json + com/pretty/client/mixin/*. Hooks.java is the public bridge.
NoRender (Visuals): Fire, Water, Pumpkin and snow overlay, Hurt cam. Mixins use defaultRequire 0, so if a method name
  differs in your game version the game still starts and only that option does nothing (see latest.log, "Skipping").

--- v1.5 changes ---
SafeWalk (Movement, mixin PlayerMixin -> Hooks.safeWalk): you cannot walk off an edge on the ground, no sneaking needed.
  Option "Only with blocks" = works only while a block is in your hand.
AutoBlockSwap (Player): when the block stack in your hand runs out, picks another block stack from the hotbar.
BlockCounter (HUD): total blocks while you hold a block.
(Scaffold and Eagle already existed.)

--- v1.6 changes ---
AutoGap (fixed): once it starts eating it holds the use key until the apple is fully eaten (or 3.5 s timeout), then
  switches back. Old version released the key too early when health went above the threshold.
TargetEsp (Visual): new options "Crystals" (crystals orbit the target, count 3-8) and "Crosshair" (also works on
  whatever living entity you are looking at, not only on the one you hit).
BlockESP (Render, on by default): pulsing frame + filled hit face + label "block name [distance]" for the block you look at.
  "Range" up to 20 blocks (further than normal reach).
DamageIndicator (Render): floating -damage / +heal numbers above entities.
ArmorStatus (HUD, on by default): armor icons + bar + % right of the hotbar, and the armor of the target you are hitting.
ShaderHands: new option "Both hands" (aura on the left side too when the off-hand holds an item).
ServerHelper.java (new):
  FunTimeHelper / HolyWorldHelper / ReallyWorldHelper (Other): panel on the right with the server items found in
  your hotbar (ready / cooldown / missing) and their keys.
  Actions "FT Trap", "FT Disorient", "HW HolyWater", "RW Plast" ... : bind a key (middle mouse on the module in the
  ClickGUI). Key press = switch to the hotbar item whose NAME contains a keyword, use it, switch back.
  Keywords are only my best guess of the item names (they differ between servers and seasons): edit
  config/prettyhelpers.txt (one "FT Trap=трапка|ловушка" line per action) and restart the game.
  Universal actions (Player): UsePearl, UseFirework, UseWindCharge, ElytraSwap (chestplate <-> elytra).
  AutoFirework (Player): while gliding and slowing down, uses a firework from the hotbar.

--- v1.7 changes ---
SkyChanger (Visual, new): own sky + cloud colour (rainbow or fixed Hue), Strength, Saturation, optional fixed time of day.
  Mixin ClientLevelMixin; day/night brightness is kept. Client side only, other players do not see it.
ShaderHands: Style (0 aura, 1 galaxy, 2 fire) and Layers (6-20, quality/smoothness); the swing reaction is now smoothed
  per frame. Layers keep the same brightness at any value.
Mods & Packs: 24 mods and 12 packs (Sodium Extra, Reese's Sodium Options, More Culling, Noisium, ScalableLux, Continuity,
  LambDynamicLights, Skin Layers 3D, Not Enough Animations, AppleSkin, Mouse Tweaks, No Chat Reports; packs Stay True,
  Mizuno's 16 Craft, Faithless, Dramatic Skys, Cubic Sun & Moon, Fast Better Grass). "Install optimization pack" now
  installs the first nine mods (adds Sodium Extra + Reese's Sodium Options). Items that Modrinth has no 1.21.4 build for
  just show an error in the list.
ServerHelper panel no longer runs without a player (main menu).

--- v1.7 (update 2) ---
Hands (Visual, new): real gradient on the first-person arm (empty hand). Flat unlit colour, vertical two-colour gradient
  (Hue 1 / Hue 2), Gradient speed, Alpha, Rainbow. Mixin ItemInHandRendererMixin -> Hooks.handBuffer -> HandGradient.java.
SkyChanger: now a solid fill like a colour picker with alpha: Hue, Saturation, Brightness, Alpha (opacity of the fill).
  "Keep day/night" keeps the original day/night darkness.

--- v1.8 changes ---
CustomHand (Visual, new, on by default): moves / rotates / scales the first-person hand and the item in it.
  Main hand / Off hand switches, X Y Z offset, Rot X/Y/Z, Scale. "Lying sword" lays a sword almost flat across the
  lower screen (the look from the video); it only affects swords. Mixin ItemInHandRendererMixin (renderArmWithItem)
  -> Hooks.customHand. The preset angles are a starting point: tune Rot Z / Y / X with the sliders (RMB on the module).
CritSound (Combat, new, on by default): the pleasant crit sound on every hit, on the ground too. Sound 0 = crit,
  1 = xp orb, 2 = amethyst chime. A real vanilla crit is skipped, because the server already plays the sound for it.
Mods & Packs: new "PvP" tab. Bundled packs (inside the jar, Install copies them to resourcepacks, then Enable):
  Mini Tools (small swords/pickaxes/axes/shovels/hoes in hand), Mini Totem, PvP Glint (cyan enchant shimmer).
  Plus Modrinth packs: Short Swords, Faithless, Bare Bones, Low Fire. Packs live in src/main/resources/assets/pretty/packs/.

v1.8 fix: ClientLevelMixin crashed on entering a world (ClassCastException Integer -> Vec3): in 1.21.4 getSkyColor and
  getCloudColor return an ARGB int. The mixin now works on the int and converts to/from Vec3 inside.

v1.8.1: CustomHand now moves the held ITEM (all items) after the vanilla swing transform, so the arm is untouched and the
  hit animation stays smooth; empty arm has its own settings (Arm X/Y/Z, Arm scale); Swing smoothing eases the swing.
  ItemShader (Visual, new): gradient tint on held items per type (Totems on by default, Swords/Tools/Food/Blocks/Other off),
  each type has its own hue shift. If a mixin target descriptor does not match, that part does nothing (see "Cannot find target method" warnings).

v1.8.2: the right-side list of enabled modules is now the HUD module "ModuleList" and is OFF by default (it was "ArrayList",
  on by default). CustomHand: "Lying sword" became "Lying pose" and applies to every held item, not only swords.

--- v1.9.0 ---
SkyParticles (Visual): few hearts / dust / sparks around you; colour = SkyChanger hue (hearts are not tintable in vanilla,
  so coloured dust flies around them).
ChunkFade (Visual, on by default): mixin LevelRendererMixin shifts the chunk-offset uniform so new sections rise from below.
  Vanilla renderer only (Sodium replaces that code). If the target does not match you get a "Cannot find target method" warning.
BaseFinder (Render, off by default; BaseFinder.java): scores loaded chunks (containers, furnaces, beds, shulkers, ender chests,
  beacons, enchanting tables, plus unnatural blocks), merges neighbouring chunks into one base, damps villages. Result goes only
  to your own chat (nothing is sent to the server), config/prettybases.txt, ESP + tracer + HUD line. With Xaero's Minimap
  loaded the chat line gets a clickable [+Xaero] waypoint link.

--- v1.10.0 ---
KillAura rewritten: attack Range + Aim range, Sort (distance/health/angle), FOV, Walls, Sticky target, Rotation 0 off / 1 smooth /
  2 snap / 3 silent (LocalPlayerMixin swaps the rotation only for sendPosition), mouse-sensitivity GCD on every step,
  attacks only when the ray from the sent rotation hits the hitbox and the rotation packet already reached the server,
  Cooldown, Random delay, Only crits (+Crit wait). Silent + strafing may flag strict anti-cheats: use Rotation 1/2 there.
Jesus: LivingEntityMixin.canStandOnFluid -> real collision on water (Lava option); Shift sinks.
NoFall: sends "on ground" while falling above Distance; very fast falls (>3 b/tick) can still hurt.
Criticals: packets only when standing still (Only standing), full charge, Cooldown ms. The two extra position packets sent while
  moving were what made anti-cheats pull you back.
CustomHand: own swing (Swing mode 1 slash / 2 poke / 3 overhead, Swing power) turns the item in place, vanilla swing motion is off.
CritSound: modes 3-7 = our own synthesized keyboard / chime sounds (assets/pretty/sounds): thock, clack, creamy, crystal, bell.
HUD: watermark (fps + ping) moved to the top centre; Info / ServerInfo / Compass / BaseFinder stack under it.
Main menu: new background (aurora glows, vignette), glass-style buttons. Fonts: FreeSans for Latin + Cyrillic (replace
  assets/pretty/font/freesans*.ttf to change). Resource packs: FunTime added (Modrinth search by name, unverified).

v1.10.1: KeySounds (Other, on by default): keyboard sound on every key press (softer one on release), polled once per frame in
  Hud.render via GLFW, no mixin. Sound 0 thock / 1 clack / 2 creamy, space/enter lower, Movement keys / Only in menus & chat /
  Mouse clicks switches. Uses the synthesized sounds from assets/pretty/sounds.

v1.10.2: BlockHighlight got Fill opacity (default 0.06, was 0.22) and Line opacity. KeySounds Sound=3 (default) plays the events
  pretty:key_down / key_up / key_space / key_enter / mouse_down / mouse_up from sounds.json; a resource pack can replace them with
  real recordings (template: assets/pretty/packs/pretty_keysounds.zip, installable from Mods & Packs > Resource packs).

--- v1.11.0 ---
CrowdBoost (Performance, ON by default): crowd mode for warps / arenas with 20-30 players. Once "Crowd at" players are within
  "Far range", only the nearest "Max players" (+ everyone within 10 blocks + the player under the crosshair) are rendered;
  the rest are skipped (EntityRenderDispatcherMixin.shouldRender). Far players lose their armor layer (HumanoidArmorLayerMixin),
  far item / xp-orb entities are skipped, particles get a per-tick budget and a 24-block range (ParticleEngineMixin), shadows /
  clouds / particle level are lowered while the crowd lasts and restored afterwards, ShaderHands is skipped (Lite HUD).
  Outside a crowd nothing is changed. Every mixin target uses a full descriptor: if one does not match 1.21.4 it is skipped
  (look for "Cannot find target method" in latest.log), the rest keeps working.
  For the rest of the FPS: Mods & Packs > Install optimization pack (Sodium, Lithium, Entity Culling, ImmediatelyFast ...), and
  JVM args in the launcher: -Xms2G -Xmx4G -XX:+UseG1GC -XX:MaxGCPauseMillis=50 -XX:+UnlockExperimentalVMOptions -XX:+DisableExplicitGC

--- v1.12.0 ---
Optimize (Performance, ON by default; Optimizer.java): one switch for general FPS. Level 1 light / 2 balanced / 3 max (turns the
  decorative modules off). Adaptive lowers the render distance by one chunk while FPS stays under Target FPS (not below Min chunks)
  and restores it when there is headroom. It switches the existing Perf modules on and remembers which ones it switched, so turning
  Optimize off puts them back. Works together with CrowdBoost (crowds) and the optimization pack (Sodium etc.).

--- v1.13.0 ---
Sodium crash fix (runClient): mods downloaded from Modrinth use release (intermediary) names. gradlew runClient runs with dev
  names, and files in run/mods are NOT remapped, so Sodium / Lithium / ... crash the game at start. Now: (1) build.gradle pulls
  Sodium from the Modrinth maven as modRuntimeOnly, Loom remaps it (not part of the built jar; dev_sodium=false in
  gradle.properties turns it off); (2) in runClient the "Mods" tab refuses to install mods and says so (packs still install).
  DELETE any sodium*.jar, lithium*.jar, etc. in run/mods first. In a normal launcher (the built jar in .minecraft/mods) the
  installer works as before. Judge FPS from the jar in a normal launcher: runClient is much slower (dev environment).
Packs: +30 resource packs for smooth PvP, low-end FPS and chill. Entries marked "поиск ..." take the best Modrinth search result
  for that query; the status shows the downloaded file name.

--- v1.14.0 ---
Optimize: + Block entity range (BlockEntityRenderDispatcherMixin: chests / signs / heads far away are skipped), Particle range
  (particles beyond it are never added, also outside crowds), Background FPS (frame cap while the window is not focused).
CrowdBoost: + Hide behind walls: players more than 12 blocks away are skipped while every one of 5 test rays from your eyes to them
  is blocked for 3 ticks in a row (glass / plants do not block). Costs a few ray casts per tick, only when a crowd is around.

--- v1.15.0 ---
Quality (Visual): Bright (gamma 100%), Mipmaps 0-4, Biome blend 0-7. Applied through Options and restored when switched off.
Mods & Packs: new "Shaders" tab (download to .minecraft/shaderpacks, needs the Iris mod; pick the pack in Video Settings > Shader Packs):
  Complementary Reimagined / Unbound, BSL, Solas, MakeUp Ultra Fast, Photon, Rethinking Voxels, Miniature, Sildur's.
  New mods: RenderScale (render at 1.5x-2x and downscale = the "2K sharp" look) and QDAA (2x SSAA). They cost a lot of GPU;
  start at 1.5x. Not compatible with Lunar / Feather. Do not use together with shaders that have their own anti-aliasing at 2x.

--- v1.16.0 ---
AuctionHelper (Other; AuctionHelper.java): in the auction menu (a chest-style menu whose title contains Аукцион / Auction / AH /
  Маркет / Рынок, or any chest with "Any menu") it frames lots: green + "-NN%" = unit price at least Deal % under the usual one,
  cyan = cheapest of its kind on the page. Server: 0 auto (from the server address), 1 FunTime, 2 HolyWorld, 3 SpookyTime,
  4 ReallyWorld, 5 ArtiGrief. Prices are read from the item lore (lines with Цена / Стоимость / Price / Cost, else a line with $ or
  "монет"), unit price = price / stack size. Usual price = median of the same item on the page (3+ lots) blended with a learned
  average (config/pretty_ah.json). Read-only: it never clicks or buys. If the header says "цены не распознаны", the lore format
  of that server differs: send a screenshot of one lot's tooltip.

--- v1.17.0 ---
Duplicates removed: ArmorHUD (ArmorStatus does the same and more), PerfBoost (Optimize replaces it), BackgroundSaver (Optimize has
  Background FPS), BiomeBlend + NoMipmaps (Quality owns biome blend / mipmaps; Optimize sets blend 0 itself only while Quality is off),
  MiddleClickPearl now calls the same ServerHelper.use() as UsePearl (its own copy of the slot-swap code is gone). Code: one Ui.approach()
  instead of two copies in Gui / ModsScreen, one PrettyClient.cfgFile() instead of three config-path helpers.
  Old configs keep working: unknown module names are simply ignored.
CrowdBoost: + Hide far held items (ItemInHandLayerMixin), Hide far nametags + Name range (EntityRendererMixin), Sound cap + Sounds per tick
  (SoundManagerMixin: far player/block/mob sounds over the per-tick budget are dropped; UI, music and anything within 6 blocks always play).
  The "hide behind walls" ray test now runs once per 3 ticks per player instead of every tick (5 rays x 30 players x 20 = was 3000 rays/s),
  ChunkFade does no work during a crowd. Every new mixin uses a full descriptor: a mismatch just skips it (see latest.log).
New HUD: FrameGraph (frame-time graph + average ms + 1% low FPS, to measure the optimization), CPS (left | right clicks per second).
AuctionHelper: + servers 6 SunRise, 7 FunSky, 8 MineBlaze, 9 CheatMine (only change which server history is used / auto-detected from the IP;
  if a server prints prices differently, the header says "цены не распознаны").
AuctionHelper v2: lots are coloured green (cheap) -> yellow -> red (expensive); MIN / MAX tags on the cheapest and the priciest lot; a gold
  pulsing star + header line on the BEST VALUE lot of the page (biggest discount to the usual price, or biggest saving in coins: "Best by").
  Compare: same items by unit price / whole page by total price. Server slider now shows the server NAME. Own servers: config/pretty_ah_servers.txt
  (created on first start: Name | ip parts | price words | menu title words), restart the game after editing. "Mark cheapest" is gone (replaced by Gradient/MIN).
NOT compiled here (no Gradle/network in the sandbox): run gradlew build once and send me the log if anything fails.

v1.17.2: startup crash fix with Sodium (runClient): ChunkFade's LevelRendererMixin cannot be applied when Sodium replaces
  renderSectionLayer ("cannot inject into ... merged by net.caffeinemc.mods.sodium"). PrettyMixinPlugin now skips that mixin when Sodium /
  Embeddium is loaded (ChunkFade simply does nothing then), and pretty.mixins.json is "required": false, so a mixin that does not fit
  is logged in latest.log instead of crashing the game. If a module seems to do nothing, search latest.log for "Mixin apply".

v1.17.3: BaseFinder no longer flags generated structures (abandoned mineshafts in badlands were "~1300 build-blocks" = 25 points per chunk).
  Chunk score now = evidence (containers / furnaces / beds / shulkers / redstone / storage blocks) + at most 3 points for planks, glass, wool,
  concrete. A chunk with 3+ markers of a generated structure (cobwebs, rails, cracked / mossy bricks, sculk, trial blocks ...) gets 0 from
  building blocks. A base needs evidence >= 60% of Sensitivity, so building blocks alone can never create one. A bell in a cluster = village
  (x0.3). Gold blocks / TNT are no longer "strong" (bastions, desert temples). config/prettybases.txt: old file is moved to
  prettybases_old.txt once (it contained the false bases), the new file starts with "#v2".
