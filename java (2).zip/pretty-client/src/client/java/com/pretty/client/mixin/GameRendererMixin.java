package com.pretty.client.mixin;

import com.pretty.client.Hooks;
import net.minecraft.client.renderer.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** NoRender: camera shake when you take damage. */
@Mixin(GameRenderer.class)
public class GameRendererMixin {
    @Inject(method = "bobHurt", at = @At("HEAD"), cancellable = true)
    private void pretty$noHurtCam(CallbackInfo ci) {
        if (Hooks.noRender("Hurt cam")) ci.cancel();
    }
}
