package com.pretty.client.mixin;

import com.pretty.client.Hooks;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** SkyChanger: custom sky / cloud colour and a fixed time of day (client side only). */
@Mixin(ClientLevel.class)
public class ClientLevelMixin {
    // In 1.21.4 getSkyColor / getCloudColor return an ARGB int, not a Vec3.
    @Inject(method = "getSkyColor", at = @At("RETURN"), cancellable = true)
    private void pretty$sky(Vec3 pos, float partial, CallbackInfoReturnable<Integer> cir) {
        cir.setReturnValue(pretty$tint(cir.getReturnValue(), false));
    }

    @Inject(method = "getCloudColor", at = @At("RETURN"), cancellable = true)
    private void pretty$clouds(float partial, CallbackInfoReturnable<Integer> cir) {
        cir.setReturnValue(pretty$tint(cir.getReturnValue(), true));
    }

    private static int pretty$tint(int argb, boolean cloud) {
        Vec3 orig = new Vec3((argb >> 16 & 255) / 255.0, (argb >> 8 & 255) / 255.0, (argb & 255) / 255.0);
        Vec3 r = Hooks.skyColor(orig, cloud);
        if (r == null) return argb;
        int rr = (int) Math.max(0, Math.min(255, Math.round(r.x * 255.0)));
        int gg = (int) Math.max(0, Math.min(255, Math.round(r.y * 255.0)));
        int bb = (int) Math.max(0, Math.min(255, Math.round(r.z * 255.0)));
        return (argb & 0xFF000000) | (rr << 16) | (gg << 8) | bb;
    }

    /** Second long argument of setTimeFromServer(gameTime, dayTime, ...) = time of day. */
    @ModifyVariable(method = "setTimeFromServer", at = @At("HEAD"), argsOnly = true, ordinal = 1)
    private long pretty$time(long dayTime) {
        return Hooks.dayTime(dayTime);
    }
}
