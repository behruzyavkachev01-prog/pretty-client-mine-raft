package com.pretty.client.mixin;

import com.mojang.blaze3d.vertex.PoseStack;
import com.pretty.client.Hooks;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderDispatcher;
import net.minecraft.world.level.block.entity.BlockEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Optimize: chests, signs, heads, banners ... farther than "Block entity range" are not drawn. */
@Mixin(BlockEntityRenderDispatcher.class)
public class BlockEntityRenderDispatcherMixin {
    @Inject(method = "render(Lnet/minecraft/world/level/block/entity/BlockEntity;FLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;)V",
        at = @At("HEAD"), cancellable = true)
    private void pretty$beCull(BlockEntity be, float partial, PoseStack ps, MultiBufferSource buf, CallbackInfo ci) {
        if (Hooks.cullBlockEntity(be)) ci.cancel();
    }
}
