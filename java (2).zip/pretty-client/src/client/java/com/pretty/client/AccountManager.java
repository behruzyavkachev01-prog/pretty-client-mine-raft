package com.pretty.client;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Random;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.client.User;
import net.minecraft.core.UUIDUtil;

/**
 * Offline account storage: only a nickname, no password, no tokens.
 * File: .minecraft/config/prettyaccounts.txt (first line "current=Nick", then one nick per line).
 */
final class AccountManager {
    private AccountManager() {}

    static final List<String> NAMES = new ArrayList<>();
    static String current = "";
    private static final String[] A = {"Dark", "Neo", "Pixel", "Frost", "Void", "Lunar", "Sky", "Nova", "Ghost", "Zen", "Rush", "Toxic"};
    private static final String[] B = {"Wolf", "Fox", "Blade", "Mage", "Rider", "Hunter", "Craft", "Storm", "Bee", "Cat", "Shot", "Lord"};

    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("prettyaccounts.txt");
    }

    static boolean valid(String n) {
        return n != null && n.matches("[A-Za-z0-9_]{3,16}");
    }

    static void load() {
        NAMES.clear();
        try {
            Path p = path();
            if (!Files.exists(p)) return;
            for (String line : Files.readAllLines(p)) {
                line = line.trim();
                if (line.startsWith("current=")) current = line.substring(8);
                else if (valid(line) && !NAMES.contains(line)) NAMES.add(line);
            }
        } catch (IOException | RuntimeException ignored) {
        }
    }

    static void save() {
        try {
            StringBuilder sb = new StringBuilder("current=").append(current).append('\n');
            for (String n : NAMES) sb.append(n).append('\n');
            Files.writeString(path(), sb.toString());
        } catch (IOException | RuntimeException ignored) {
        }
    }

    /** Adds a nickname to the list. Returns false if it is invalid or already there. */
    static boolean add(String name) {
        if (!valid(name) || NAMES.contains(name)) return false;
        NAMES.add(name);
        save();
        return true;
    }

    static void remove(String name) {
        NAMES.remove(name);
        save();
    }

    static String random() {
        Random r = new Random();
        for (int i = 0; i < 20; i++) {
            String n = A[r.nextInt(A.length)] + B[r.nextInt(B.length)] + (r.nextInt(90) + 10);
            if (!NAMES.contains(n)) return n;
        }
        return "Player" + r.nextInt(9999);
    }

    /** Switches the current game session to an offline profile with this nickname. */
    static void login(String name) {
        if (!valid(name)) return;
        Minecraft mc = Minecraft.getInstance();
        mc.user = new User(name, UUIDUtil.createOfflinePlayerUUID(name), "", Optional.empty(), Optional.empty(), User.Type.MSA);
        current = name;
        save();
    }

    /** Called once when the client has started: restores the last used account. */
    static void applySaved() {
        load();
        if (valid(current)) {
            if (!NAMES.contains(current)) NAMES.add(0, current);
            login(current);
        } else {
            current = Minecraft.getInstance().getUser().getName();
        }
    }
}
