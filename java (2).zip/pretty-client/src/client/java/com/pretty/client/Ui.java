package com.pretty.client;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.resources.ResourceLocation;

/**
 * Text helper: draws everything with the client's own fonts (assets/pretty/font/ui.json and title.json).
 * Glyphs missing in the TTF (for example Cyrillic in Poppins) fall back to Carlito, then to the vanilla font.
 */
final class Ui {
    private Ui() {}

    static final ResourceLocation UI = ResourceLocation.fromNamespaceAndPath("pretty", "ui");
    static final ResourceLocation TITLE = ResourceLocation.fromNamespaceAndPath("pretty", "title");

    private static final Map<String, Component> UI_CACHE = new HashMap<>();
    private static final Map<String, Component> TITLE_CACHE = new HashMap<>();

    private static Component comp(Map<String, Component> cache, ResourceLocation font, String s) {
        if (cache.size() > 1500) cache.clear();
        return cache.computeIfAbsent(s, k -> Component.literal(k).withStyle(Style.EMPTY.withFont(font)));
    }

    static Component c(String s) { return comp(UI_CACHE, UI, s); }
    static Component ct(String s) { return comp(TITLE_CACHE, TITLE, s); }

    /** Width of a string in the UI font. */
    static int w(String s) { return Minecraft.getInstance().font.width(c(s)); }
    /** Width of a string in the title font. */
    static int wt(String s) { return Minecraft.getInstance().font.width(ct(s)); }

    static void d(GuiGraphics g, String s, int x, int y, int color, boolean shadow) {
        g.drawString(Minecraft.getInstance().font, c(s), x, y, color, shadow);
    }

    static void dt(GuiGraphics g, String s, int x, int y, int color, boolean shadow) {
        g.drawString(Minecraft.getInstance().font, ct(s), x, y, color, shadow);
    }

    static void center(GuiGraphics g, String s, int cx, int y, int color) {
        d(g, s, cx - w(s) / 2, y, color, false);
    }

    /** Word wrap by pixel width. */
    static List<String> wrap(String s, int maxW) {
        List<String> out = new ArrayList<>();
        StringBuilder line = new StringBuilder();
        for (String word : s.split(" ")) {
            String t = line.length() == 0 ? word : line + " " + word;
            if (w(t) > maxW && line.length() > 0) {
                out.add(line.toString());
                line = new StringBuilder(word);
            } else {
                line = new StringBuilder(t);
            }
        }
        if (line.length() > 0) out.add(line.toString());
        return out;
    }

    /** Exponential ease of \"cur\" towards \"target\" (shared by the GUI screens). */
    static float approach(float cur, float target, float dt, float speed) {
        return cur + (target - cur) * Math.min(1f, dt * speed);
    }
}
