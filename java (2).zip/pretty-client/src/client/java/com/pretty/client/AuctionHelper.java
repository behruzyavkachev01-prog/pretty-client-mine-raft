package com.pretty.client;

import static com.pretty.client.PrettyClient.*;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.ContainerScreen;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.ItemLore;

/**
 * AuctionHelper: colours the lots of the auction menu of the server you pick (/ah style chest menus).
 * It only READS what the server shows you (item name, count, lore with the price) and draws over the slots:
 *   green -> yellow -> red = cheap -> expensive (inside the group of the same item, or over the whole page),
 *   MIN / MAX marks on the cheapest and the most expensive lot, a gold star on the best value lot of the page.
 * "Best value" = the biggest discount (or the biggest saving in coins) against the usual price of that item, which is the
 * median of the same item on the page (3+ lots) blended with a learned average kept per server in config/pretty_ah.json.
 * Own servers can be added in config/pretty_ah_servers.txt (see the file, it is created with examples).
 * Nothing is clicked or bought for you.
 */
final class AuctionHelper {
    private AuctionHelper() {}

    record Prof(String name, String[] ip, Pattern key, Pattern title) {}

    static final List<Prof> PROFS = new ArrayList<>();
    static String[] PROF_NAMES = {"Auto"};

    private static void builtin(String name, String... ip) { PROFS.add(new Prof(name, ip, null, null)); }

    static final class Lot {
        int slot, count;
        double unit, total, metric, ref = Double.NaN, pct, save;
        float t = Float.NaN;          // 0 = cheapest .. 1 = most expensive
        boolean deal, min, max, best;
        String name = "";
    }

    static final Pattern TITLE = Pattern.compile("(?i)(аукцион|auction|\\bah\\b|маркет|market|рынок|торгов)");
    static final Pattern KEY = Pattern.compile("(?i)(цена|стоимост|price|cost|купить|покупк|продаж)");
    static final Pattern NUM = Pattern.compile(
        "(\\d{1,3}(?:[\\s\\u00A0\\u202F,.']\\d{3})+(?:[.,]\\d{1,2})?|\\d+(?:[.,]\\d+)?)\\s*([kкKК]{1,2}|[mмMМ])?");

    static final List<Lot> lots = new ArrayList<>();
    static long lastScan;
    static int deals, mins, maxs;
    static Lot bestLot;
    static String shownProf = "";
    static boolean active;
    /** server -> item key -> {ema, samples} */
    static final Map<String, Map<String, double[]>> HISTORY = new HashMap<>();
    static boolean loaded;

    // ------------------------------------------------------------------ server list (built-in + config/pretty_ah_servers.txt)
    static Path serversFile() { return PrettyClient.cfgFile("pretty_ah_servers.txt"); }

    static void loadProfiles() {
        PROFS.clear();
        builtin("Auto");
        builtin("FunTime", "funtime");
        builtin("HolyWorld", "holyworld", "holy");
        builtin("SpookyTime", "spooky");
        builtin("ReallyWorld", "reallyworld", "really");
        builtin("ArtiGrief", "arti");
        builtin("SunRise", "sunrise");
        builtin("FunSky", "funsky");
        builtin("MineBlaze", "mineblaze");
        builtin("CheatMine", "cheatmine");
        Path f = serversFile();
        try {
            if (!Files.exists(f)) {
                Files.writeString(f, String.join("\n",
                    "# Свои сервера для AuctionHelper. Одна строка = один сервер, поля через |",
                    "# Название | часть IP через запятую | слова цены через запятую (можно пусто) | слова в названии меню аукциона (можно пусто)",
                    "# Пример (раскомментируй и поменяй):",
                    "# MyServer | myserver.net,my-srv | Цена,Price | Аукцион,Рынок",
                    "# После правки файла перезапусти игру: список серверов в ClickGUI строится при запуске.", ""));
            } else {
                for (String line : Files.readAllLines(f)) {
                    line = line.trim();
                    if (line.isEmpty() || line.startsWith("#")) continue;
                    String[] p = line.split("\\|", -1);
                    if (p.length < 2 || p[0].trim().isEmpty()) continue;
                    String name = p[0].trim();
                    if (PROFS.stream().anyMatch(x -> x.name().equalsIgnoreCase(name))) continue;
                    String[] ip = Arrays.stream(p[1].split(",")).map(x -> x.trim().toLowerCase(Locale.ROOT)).filter(x -> !x.isEmpty()).toArray(String[]::new);
                    Pattern key = p.length > 2 ? words(p[2]) : null;
                    Pattern title = p.length > 3 ? words(p[3]) : null;
                    PROFS.add(new Prof(name, ip, key, title));
                }
            }
        } catch (IOException | RuntimeException ignored) {
        }
        PROF_NAMES = PROFS.stream().map(Prof::name).toArray(String[]::new);
    }

    private static Pattern words(String csv) {
        List<String> w = new ArrayList<>();
        for (String s : csv.split(",")) if (!s.trim().isEmpty()) w.add(Pattern.quote(s.trim()));
        return w.isEmpty() ? null : Pattern.compile("(?i)(" + String.join("|", w) + ")");
    }

    static void register() {
        loadProfiles();
        add(new Mod("AuctionHelper", Cat.OTHER)
            .with(new Num("Server", 0, PROFS.size() - 1, 0, 1).labels(PROF_NAMES),
                new Num("Compare", 0, 1, 0, 1).labels("Одинаковые", "Вся страница"),
                new Bool("Gradient", true),
                new Num("Deal %", 5, 80, 25, 5),
                new Bool("Mark best", true), new Num("Best by", 0, 1, 0, 1).labels("Процент", "Экономия"),
                new Bool("Show prices", false), new Bool("Dim others", false), new Bool("Learn prices", true), new Bool("Any menu", false))
            .d("Раскрашивает лоты в меню аукциона (/ah): ЗЕЛЁНЫЙ = дешёвый, КРАСНЫЙ = дорогой, жёлтый посередине. "
                + "Server: выбери сервер из списка (Auto определяет по адресу; свои сервера добавляются в config/pretty_ah_servers.txt). "
                + "Compare: Одинаковые = сравнивать цену за штуку у одинаковых предметов, Вся страница = все лоты по общей цене. "
                + "Gradient: красить плавно все лоты; выключи, чтобы отмечать только самый дешёвый (MIN) и самый дорогой (MAX). "
                + "Mark best: золотая рамка со звездой на самом ВЫГОДНОМ лоте страницы (самая большая скидка к обычной цене); "
                + "Best by: считать по проценту скидки или по экономии в монетах. Deal %: от какой скидки писать -NN%. "
                + "Обычная цена = медиана таких же лотов на странице (от 3 шт) вместе с запомненной средней (Learn prices). "
                + "Show prices: цена за штуку на лоте. Dim others: затемнять неотмеченные. Any menu: работать в любом сундуке. Ничего не покупает."));

        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            if (!(screen instanceof ContainerScreen cs)) return;
            ScreenEvents.afterRender(screen).register((s, g, mx, my, dt) -> {
                try { render(g, cs); } catch (Throwable ignored) { }
            });
            ScreenEvents.remove(screen).register(s -> save());
        });
    }

    // ------------------------------------------------------------------ price parsing
    // ------------------------------------------------------------------ price parsing
    static double parseNum(String s) {
        Matcher m = NUM.matcher(s);
        if (!m.find()) return Double.NaN;
        String t = m.group(1).replaceAll("[\\s\\u00A0\\u202F']", "");
        int lastDot = t.lastIndexOf('.'), lastCom = t.lastIndexOf(',');
        if (lastDot >= 0 && lastCom >= 0) {
            int dec = Math.max(lastDot, lastCom);
            t = t.substring(0, dec).replaceAll("[.,]", "") + "." + t.substring(dec + 1);
        } else if (lastDot >= 0 || lastCom >= 0) {
            int p = Math.max(lastDot, lastCom);
            int seps = t.length() - t.replaceAll("[.,]", "").length();
            int after = t.length() - p - 1;
            if (seps > 1 || after == 3) t = t.replaceAll("[.,]", "");
            else t = t.replace(',', '.');
        }
        double v;
        try { v = Double.parseDouble(t); } catch (NumberFormatException e) { return Double.NaN; }
        String sfx = m.group(2) == null ? "" : m.group(2).toLowerCase(Locale.ROOT);
        if (sfx.equals("kk") || sfx.equals("кк")) v *= 1_000_000;
        else if (sfx.equals("k") || sfx.equals("к")) v *= 1_000;
        else if (sfx.equals("m") || sfx.equals("м")) v *= 1_000_000;
        return v;
    }


    static double priceOf(ItemStack st, Prof prof) {
        ItemLore lore = st.get(DataComponents.LORE);
        if (lore == null) return Double.NaN;
        List<Component> ls = lore.lines();
        Pattern key = prof != null && prof.key() != null ? prof.key() : KEY;
        for (Component c : ls) {
            String s = c.getString();
            Matcher k = key.matcher(s);
            if (k.find()) {
                double v = parseNum(s.substring(k.end()));
                if (!Double.isNaN(v)) return v;
            }
        }
        for (Component c : ls) {
            String s = c.getString();
            if (s.contains("$") || s.contains("¤") || s.toLowerCase(Locale.ROOT).contains("монет")) {
                double v = parseNum(s);
                if (!Double.isNaN(v)) return v;
            }
        }
        return Double.NaN;
    }

    static String keyOf(ItemStack st) {
        String id = BuiltInRegistries.ITEM.getKey(st.getItem()).toString();
        String name = st.getHoverName().getString();
        Object ench = st.get(DataComponents.ENCHANTMENTS);
        Object stored = st.get(DataComponents.STORED_ENCHANTMENTS);
        return id + "|" + name + "|" + (ench == null ? "" : ench) + "|" + (stored == null ? "" : stored);
    }


    // ------------------------------------------------------------------ server
    static Prof profile(Mod m) {
        int i = (int) m.n("Server");
        if (i > 0 && i < PROFS.size()) return PROFS.get(i);
        ServerData sd = Minecraft.getInstance().getCurrentServer();
        if (sd != null && sd.ip != null) {
            String ip = sd.ip.toLowerCase(Locale.ROOT);
            for (Prof p : PROFS) for (String h : p.ip()) if (ip.contains(h)) return p;
        }
        return PROFS.get(0);
    }

    // ------------------------------------------------------------------ scan + draw
    static double median(List<Double> v) {
        List<Double> s = new ArrayList<>(v);
        s.sort(Double::compare);
        int n = s.size();
        return n % 2 == 1 ? s.get(n / 2) : (s.get(n / 2 - 1) + s.get(n / 2)) / 2.0;
    }

    /** Colours one group of lots between its cheapest and most expensive metric. */
    private static void spread(List<Lot> g) {
        if (g.size() < 2) return;
        double lo = Double.MAX_VALUE, hi = -Double.MAX_VALUE;
        for (Lot l : g) { lo = Math.min(lo, l.metric); hi = Math.max(hi, l.metric); }
        if (hi <= lo * 1.0001) return;                       // all the same price: nothing to compare
        for (Lot l : g) {
            l.t = (float) ((l.metric - lo) / (hi - lo));
            l.min = l.metric <= lo;
            l.max = l.metric >= hi;
        }
    }

    static void scan(Minecraft mc, ContainerScreen cs, Mod m) {
        loadHistory();
        lots.clear();
        deals = 0; mins = 0; maxs = 0;
        bestLot = null;
        Prof prof = profile(m);
        shownProf = prof.name();
        boolean page = (int) m.n("Compare") == 1;
        ChestMenu menu = cs.getMenu();
        int n = menu.getRowCount() * 9;
        Map<String, List<Lot>> groups = new HashMap<>();
        for (int i = 0; i < n && i < menu.slots.size(); i++) {
            ItemStack st = menu.slots.get(i).getItem();
            if (st.isEmpty()) continue;
            double total = priceOf(st, prof);
            if (Double.isNaN(total) || total <= 0) continue;
            Lot l = new Lot();
            l.slot = i;
            l.count = Math.max(1, st.getCount());
            l.total = total;
            l.unit = total / l.count;
            l.name = st.getHoverName().getString();
            lots.add(l);
            groups.computeIfAbsent(keyOf(st), k -> new ArrayList<>()).add(l);
        }
        Map<String, double[]> hist = HISTORY.computeIfAbsent(prof.name(), k -> new HashMap<>());
        double dealPct = m.n("Deal %");
        boolean learn = m.b("Learn prices");
        boolean bySave = (int) m.n("Best by") == 1;

        // 1) usual price per item (needs 3+ lots or a learned average; with 2 lots the pricier one is the reference)
        for (Map.Entry<String, List<Lot>> e : groups.entrySet()) {
            List<Lot> g = e.getValue();
            double[] h = hist.get(e.getKey());
            double ref = Double.NaN;
            if (g.size() >= 3) {
                List<Double> units = new ArrayList<>();
                for (Lot l : g) units.add(l.unit);
                double med = median(units);
                ref = h != null && h[1] >= 2 ? 0.6 * med + 0.4 * h[0] : med;
                if (learn) {
                    if (h == null) hist.put(e.getKey(), new double[] {med, 1});
                    else { h[0] = h[0] * 0.8 + med * 0.2; h[1] = Math.min(50, h[1] + 1); }
                }
            } else if (h != null && h[1] >= 2) {
                ref = h[0];
            } else if (g.size() == 2) {
                ref = Math.max(g.get(0).unit, g.get(1).unit);
            }
            for (Lot l : g) {
                l.ref = ref;
                if (!Double.isNaN(ref) && ref > 0) {
                    l.pct = (1.0 - l.unit / ref) * 100.0;
                    l.save = (ref - l.unit) * l.count;
                    l.deal = l.pct >= dealPct;
                    if (l.deal) deals++;
                }
            }
            // 2) colour inside the group of the same item
            if (!page) {
                for (Lot l : g) l.metric = l.unit;
                spread(g);
            }
        }
        // 2b) or over the whole page by the total price
        if (page) {
            for (Lot l : lots) l.metric = l.total;
            spread(lots);
        }
        // a single lot with a known usual price is coloured by how far it is from it (0.5x = green, 1.5x = red)
        for (Lot l : lots) {
            if (Float.isNaN(l.t) && !Double.isNaN(l.ref) && l.ref > 0) l.t = (float) Math.max(0, Math.min(1, l.unit / l.ref - 0.5));
            if (l.min) mins++;
            if (l.max) maxs++;
        }
        // 3) best value lot of the page
        double bestV = 0;
        for (Lot l : lots) {
            if (Double.isNaN(l.ref) || l.pct < Math.min(dealPct, 10)) continue;
            double v = bySave ? l.save : l.pct;
            if (v > bestV) { bestV = v; bestLot = l; }
        }
        if (bestLot != null) bestLot.best = true;
        if (hist.size() > 4000) hist.clear();
    }

    static String fmt(double v) {
        if (v >= 1_000_000) return String.format(Locale.ROOT, "%.1fM", v / 1_000_000);
        if (v >= 1_000) return String.format(Locale.ROOT, "%.1fk", v / 1_000);
        return String.valueOf((long) v);
    }

    private static final int GREEN = 0x3DDC84, YELLOW = 0xFFD84D, RED = 0xFF4D4D, GOLD = 0xFFC933;

    private static int ramp(float t) {
        return t < 0.5f ? mix(GREEN, YELLOW, t * 2f) : mix(YELLOW, RED, (t - 0.5f) * 2f);
    }

    private static void frame(GuiGraphics g, int x, int y, int col, int th) {
        g.fill(x - th, y - th, x + 16 + th, y, col);
        g.fill(x - th, y + 16, x + 16 + th, y + 16 + th, col);
        g.fill(x - th, y, x, y + 16, col);
        g.fill(x + 16, y, x + 16 + th, y + 16, col);
    }

    private static void tag(GuiGraphics g, int x, int y, String t, int col) {
        int w = Ui.w(t);
        g.fill(x, y, x + w + 2, y + 9, alpha(0x000000, 0.75f));
        Ui.d(g, t, x + 1, y + 1, alpha(col, 1f), false);
    }

    static void render(GuiGraphics g, ContainerScreen cs) {
        Mod m = find("AuctionHelper");
        active = false;
        if (m == null || !m.enabled) return;
        Minecraft mc = Minecraft.getInstance();
        Prof prof = profile(m);
        String title = cs.getTitle().getString();
        if (!m.b("Any menu") && !TITLE.matcher(title).find() && !(prof.title() != null && prof.title().matcher(title).find())) return;
        active = true;
        long now = System.currentTimeMillis();
        if (now - lastScan > 300) { lastScan = now; scan(mc, cs, m); }

        ChestMenu menu = cs.getMenu();
        int rows = menu.getRowCount();
        int left = (cs.width - 176) / 2, top = (cs.height - (114 + rows * 18)) / 2;
        boolean dim = m.b("Dim others"), grad = m.b("Gradient"), prices = m.b("Show prices"), markBest = m.b("Mark best");
        float pulse = 0.7f + 0.3f * (float) Math.sin(now / 170.0);
        for (Lot l : lots) {
            Slot s = menu.slots.get(l.slot);
            int x = left + s.x, y = top + s.y;
            boolean extreme = l.min || l.max;
            if (Float.isNaN(l.t) || !(grad || extreme)) {
                if (dim && !l.best) g.fill(x, y, x + 16, y + 16, alpha(0x000000, 0.5f));
            } else {
                int c = l.min ? GREEN : l.max ? RED : ramp(l.t);
                g.fill(x, y, x + 16, y + 16, alpha(c, extreme ? 0.26f : 0.13f));
                frame(g, x, y, alpha(c, extreme ? 1f : 0.75f), 1);
                if (l.min) tag(g, x, y, "MIN", GREEN);
                else if (l.max) tag(g, x, y, "MAX", RED);
            }
            if (l.deal) {
                String t = "-" + (int) l.pct + "%";
                int w = Ui.w(t);
                g.fill(x + 16 - w - 2, y + 16 - 9, x + 17, y + 17, alpha(0x000000, 0.75f));
                Ui.d(g, t, x + 16 - w - 1, y + 16 - 8, alpha(GREEN, 1f), false);
            }
            if (prices) {
                String t = fmt(l.unit);
                g.fill(x, y + 16 - 9, x + Ui.w(t) + 2, y + 17, alpha(0x000000, 0.7f));
                Ui.d(g, t, x + 1, y + 16 - 8, 0xFFFFFFFF, false);
            }
            if (l.best && markBest) {
                int c = alpha(GOLD, pulse);
                frame(g, x, y, c, 2);
                g.fill(x, y, x + 16, y + 16, alpha(GOLD, 0.14f));
                tag(g, x + 5, y - 10, "★", GOLD);
            }
        }
        // header: line 1 = server + counts, line 2 = best value lot
        String head = "AH " + shownProf + (lots.isEmpty() ? " | цены не распознаны" : " | лотов: " + lots.size() + " | выгодных: " + deals);
        int hw = Ui.w(head);
        int hx = cs.width / 2 - hw / 2, hy = Math.max(14, top - 13);
        g.fill(hx - 4, hy - 2, hx + hw + 4, hy + 10, alpha(0x000000, 0.65f));
        Ui.d(g, head, hx, hy, alpha(deals > 0 ? GREEN : 0xDDDDDD, 1f), false);
        if (bestLot != null && markBest) {
            String b = "★ Лучший: " + bestLot.name + (bestLot.count > 1 ? " x" + bestLot.count : "") + " за " + fmt(bestLot.total)
                + " (-" + (int) bestLot.pct + "%, экономия " + fmt(bestLot.save) + ")";
            int bw = Ui.w(b);
            int bx = cs.width / 2 - bw / 2, by = hy - 12;
            g.fill(bx - 4, by - 2, bx + bw + 4, by + 10, alpha(0x000000, 0.7f));
            Ui.d(g, b, bx, by, alpha(GOLD, 1f), false);
        }
    }

    // ------------------------------------------------------------------ history file
    static Path file() { return PrettyClient.cfgFile("pretty_ah.json"); }

    static void loadHistory() {
        if (loaded) return;
        loaded = true;
        try {
            if (!Files.exists(file())) return;
            JsonObject root = JsonParser.parseString(Files.readString(file())).getAsJsonObject();
            for (Map.Entry<String, JsonElement> se : root.entrySet()) {
                Map<String, double[]> mm = new HashMap<>();
                for (Map.Entry<String, JsonElement> ie : se.getValue().getAsJsonObject().entrySet()) {
                    double[] a = new Gson().fromJson(ie.getValue(), double[].class);
                    if (a != null && a.length == 2) mm.put(ie.getKey(), a);
                }
                HISTORY.put(se.getKey(), mm);
            }
        } catch (IOException | RuntimeException ignored) {
        }
    }

    static void save() {
        if (!loaded || HISTORY.isEmpty()) return;
        try {
            Files.writeString(file(), new Gson().toJson(HISTORY));
        } catch (IOException ignored) {
        }
    }
}
