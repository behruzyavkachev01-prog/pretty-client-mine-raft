package com.pretty.client;

import static com.pretty.client.PrettyClient.*;

import com.mojang.blaze3d.platform.InputConstants;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import org.lwjgl.glfw.GLFW;

/**
 * ClickGUI (Right Shift): five glass columns (Combat / Movement / Visuals / Player / Other).
 * LMB = toggle, RMB or the dots = settings, MMB = bind key, wheel = scroll a column.
 * The search field sits at the bottom, just above the hotbar.
 */
final class Gui extends Screen {
    private static final int[] HUES = {145, 275, 200, 335, 45};

    private static final String[] TITLES = {"Combat", "Movement", "Visuals", "Player", "Other"};
    private static final Cat[][] GROUPS = {
        {Cat.COMBAT}, {Cat.MOVEMENT}, {Cat.RENDER, Cat.VISUAL, Cat.HUD}, {Cat.PLAYER}, {Cat.PERF, Cat.OTHER}
    };

    private static Mod sel;

    private float open = 0f;
    private long last = System.nanoTime();
    private String query = "";
    private boolean searching, closing;
    private Mod binding;
    private Num dragging;
    private int dragX, dragW;
    private boolean storeHover;
    private float storeHov, searchHov, setAnim;
    private final float[] scroll = new float[5], scrollT = new float[5];
    private final int[] colX = new int[5];
    private int colY, colW, colH;
    private Mod hoverMod;
    private long hoverSince;
    // settings popup geometry (recomputed every frame)
    private int spX, spY, spW, spH, spSetTop, spSetBot;
    private float spScroll, spScrollT;

    boolean isTyping() { return searching || binding != null; }

    Gui() { super(Component.literal("PrettyClient")); }

    private List<Mod> mods(int col) {
        List<Mod> out = new ArrayList<>();
        String q = query.toLowerCase();
        for (Cat c : GROUPS[col]) {
            for (Mod m : MODS) {
                if (m.cat != c) continue;
                if (q.isEmpty() || m.name.toLowerCase().contains(q)) out.add(m);
            }
        }
        return out;
    }

    private void layout() {
        int gap = 7;
        colW = Mth.clamp((width - 20 - gap * 4) / 5, 70, 108);
        int total = colW * 5 + gap * 4;
        int x = (width - total) / 2;
        for (int i = 0; i < 5; i++) colX[i] = x + i * (colW + gap);
        colH = Math.min(height - 78, 300);
        colY = Math.max(8, (height - 40 - colH) / 2);
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        long now = System.nanoTime();
        float dt = Math.min((now - last) / 1e9f, 0.05f);
        last = now;
        if (closing) open = Math.max(0f, open - dt * 5f);
        else open = Math.min(1f, open + dt * 3.5f);
        float e = ease(open);
        int acc = accent(0f);
        layout();

        if (minecraft.level == null) {
            for (Mod m : MODS) m.anim = Ui.approach(m.anim, m.enabled ? 1f : 0f, dt, 12f);
        }

        // blurred + darkened world behind the glass
        if (e > 0.02f) renderBlurredBackground();
        g.fill(0, 0, width, height, alpha(0x000000, 0.28f * e));

        Mod newHover = null;
        for (int col = 0; col < 5; col++) {
            float ce = ease(e * 1.5f - col * 0.10f);
            if (ce <= 0.01f) continue;
            int x = colX[col];
            int y = colY + (int) ((1f - ce) * 18f);
            drawColumn(g, col, x, y, ce, mx, my, dt, acc);
        }
        // hover detection (after drawing so scroll offsets are current)
        for (int col = 0; col < 5; col++) {
            List<Mod> list = mods(col);
            for (int i = 0; i < list.size(); i++) {
                int y = colY + 26 + i * 14 - Math.round(scroll[col]);
                if (y < colY + 24 || y > colY + colH - 14) continue;
                if (mx >= colX[col] && mx <= colX[col] + colW && my >= y && my < y + 14 && !inPopup(mx, my)) newHover = list.get(i);
            }
        }
        if (newHover != hoverMod) { hoverMod = newHover; hoverSince = System.currentTimeMillis(); }

        drawSearch(g, mx, my, dt, e, acc);
        drawBottom(g, mx, my, dt, e, acc);
        if (sel != null) drawPopup(g, mx, my, dt, e, acc);
        drawTooltip(g, mx, my, e, acc);
    }

    private boolean inPopup(double mx, double my) {
        return sel != null && setAnim > 0.5f && mx >= spX && mx <= spX + spW && my >= spY && my <= spY + spH;
    }

    // ------------------------------------------------------------ column
    private void drawColumn(GuiGraphics g, int col, int x, int y, float e, int mx, int my, float dt, int acc) {
        // glass body
        rr(g, x - 1, y - 1, colW + 2, colH + 2, 11, alpha(0xFFFFFF, 0.10f * e));
        rr(g, x, y, colW, colH, 10, alpha(0x1A211D, 0.62f * e));
        g.fillGradient(x + 3, y + 3, x + colW - 3, y + 30, alpha(0xFFFFFF, 0.06f * e), alpha(0xFFFFFF, 0.0f));

        Ui.d(g, TITLES[col], x + 10, y + 8, alpha(0xFFFFFF, e), false);
        drawIcon(g, col, x + colW - 16, y + 8, alpha(0xE6EFEA, e));

        List<Mod> list = mods(col);
        int viewTop = y + 26, viewBot = y + colH - 6;
        int total = list.size() * 14;
        float maxS = Math.max(0, total - (viewBot - viewTop));
        scrollT[col] = Mth.clamp(scrollT[col], 0f, maxS);
        scroll[col] = Ui.approach(scroll[col], scrollT[col], dt, 14f);

        g.enableScissor(x, viewTop, x + colW, viewBot);
        for (int i = 0; i < list.size(); i++) {
            Mod m = list.get(i);
            int ry = viewTop + i * 14 - Math.round(scroll[col]);
            if (ry + 14 < viewTop || ry > viewBot) continue;
            boolean over = mx >= x && mx <= x + colW && my >= Math.max(ry, viewTop) && my < Math.min(ry + 14, viewBot)
                && !inPopup(mx, my) && dragging == null;
            m.hov = Ui.approach(m.hov, over ? 1f : 0f, dt, 14f);
            if (m == sel) rr(g, x + 4, ry, colW - 8, 13, 5, alpha(acc, 0.20f * e));
            else if (m.hov > 0.02f) rr(g, x + 4, ry, colW - 8, 13, 5, alpha(0xFFFFFF, 0.06f * m.hov * e));
            float lit = Math.max(m.anim, m.hov * 0.55f);
            String label = binding == m ? "нажми клавишу..." : m.name;
            Ui.d(g, label, x + 10 + (int) (m.hov * 1.5f), ry + 3, alpha(mix(0x8E9A93, 0xFFFFFF, lit), e), false);
            int rightEdge = x + colW - 10;
            {
                // vertical dots
                int dx = rightEdge - 1;
                int dc = alpha(mix(0x8E9A93, 0xFFFFFF, Math.max(m.anim, m.hov)), e);
                g.fill(dx, ry + 3, dx + 2, ry + 5, dc);
                g.fill(dx, ry + 6, dx + 2, ry + 8, dc);
                g.fill(dx, ry + 9, dx + 2, ry + 11, dc);
            }
            if (m.anim > 0.02f) drawCheck(g, rightEdge - 12, ry + 4, alpha(0xFFFFFF, e * m.anim));
        }
        g.disableScissor();

        // fade at the bottom of the column, like the mock-up
        g.fillGradient(x + 2, y + colH - 22, x + colW - 2, y + colH - 8, alpha(0x1A211D, 0f), alpha(0x1A211D, 0.55f * e));
        if (maxS > 0) {
            int bh = Math.max(10, (int) ((viewBot - viewTop) * (viewBot - viewTop) / (float) total));
            int by = viewTop + (int) ((viewBot - viewTop - bh) * (scroll[col] / maxS));
            rr(g, x + colW - 4, by, 2, bh, 1, alpha(0xFFFFFF, 0.25f * e));
        }
    }

    private static void drawCheck(GuiGraphics g, int x, int y, int c) {
        g.fill(x, y + 3, x + 1, y + 4, c);
        g.fill(x + 1, y + 4, x + 2, y + 5, c);
        g.fill(x + 2, y + 3, x + 3, y + 4, c);
        g.fill(x + 3, y + 2, x + 4, y + 3, c);
        g.fill(x + 4, y + 1, x + 5, y + 2, c);
        g.fill(x + 5, y, x + 6, y + 1, c);
    }

    private static void drawIcon(GuiGraphics g, int col, int x, int y, int c) {
        switch (col) {
            case 0 -> { // sword
                for (int i = 0; i < 8; i++) g.fill(x + 1 + i, y + 7 - i, x + 3 + i, y + 8 - i, c);
                g.fill(x, y + 6, x + 3, y + 7, c);
            }
            case 1 -> { // grid / boots
                g.fill(x, y + 1, x + 10, y + 2, c);
                g.fill(x, y + 4, x + 10, y + 5, c);
                g.fill(x, y + 7, x + 10, y + 8, c);
                for (int i = 0; i < 3; i++) g.fill(x + 1 + i * 4, y, x + 2 + i * 4, y + 9, c);
            }
            case 2 -> { // picture frame
                g.fill(x, y, x + 10, y + 1, c);
                g.fill(x, y + 8, x + 10, y + 9, c);
                g.fill(x, y, x + 1, y + 9, c);
                g.fill(x + 9, y, x + 10, y + 9, c);
                g.fill(x + 2, y + 6, x + 4, y + 7, c);
                g.fill(x + 4, y + 4, x + 6, y + 5, c);
                g.fill(x + 6, y + 6, x + 8, y + 7, c);
            }
            default -> { // three dots
                g.fill(x, y + 4, x + 2, y + 6, c);
                g.fill(x + 4, y + 4, x + 6, y + 6, c);
                g.fill(x + 8, y + 4, x + 10, y + 6, c);
            }
        }
    }

    // ------------------------------------------------------------ search / bottom
    private int sfW() { return 120; }
    private int sfX() { return width / 2 - sfW() / 2; }
    private int sfY() { return height - 52; }

    private void drawSearch(GuiGraphics g, int mx, int my, float dt, float e, int acc) {
        int x = sfX(), y = sfY() + (int) ((1f - e) * 10f), w = sfW();
        boolean over = mx >= x && mx <= x + w && my >= y && my <= y + 14;
        searchHov = Ui.approach(searchHov, (over || searching) ? 1f : 0f, dt, 12f);
        rr(g, x, y, w, 14, 7, alpha(mix(0x1A211D, acc, searching ? 0.22f : 0f), (0.55f + 0.2f * searchHov) * e));
        String s = query.isEmpty() && !searching ? "Поиск..."
            : query + (searching && (System.currentTimeMillis() / 500) % 2 == 0 ? "_" : "");
        int col = query.isEmpty() ? 0x9AA5A0 : 0xFFFFFF;
        Ui.center(g, s, x + w / 2, y + 3, alpha(col, e));
    }

    private void drawBottom(GuiGraphics g, int mx, int my, float dt, float e, int acc) {
        // Mods & Packs (bottom-left)
        int sx = 10, sy = height - 26, sw = 82;
        storeHover = mx >= sx && mx <= sx + sw && my >= sy && my <= sy + 16;
        storeHov = Ui.approach(storeHov, storeHover ? 1f : 0f, dt, 14f);
        rr(g, sx, sy, sw, 16, 8, alpha(mix(0x1A211D, acc, 0.18f + 0.3f * storeHov), 0.7f * e));
        Ui.center(g, "Mods & Packs", sx + sw / 2, sy + 4, alpha(mix(0xC4D2CA, 0xFFFFFF, storeHov), e));

        // theme swatches (bottom-right)
        int bx = width - 10 - (HUES.length + 1) * 16;
        for (int i = 0; i < HUES.length + 1; i++) {
            int x = bx + i * 16, y = height - 24;
            boolean rainbow = i == HUES.length;
            int c = rainbow ? accent(0f) : (Color.HSBtoRGB(HUES[i] / 360f, 0.7f, 1f) & 0xFFFFFF);
            boolean cur = theme != null && (rainbow ? !theme.b("Static") : theme.b("Static") && Math.abs(theme.n("Hue") - HUES[i]) < 1);
            if (cur) rr(g, x - 1, y - 1, 14, 14, 7, alpha(0xFFFFFF, 0.85f * e));
            rr(g, x, y, 12, 12, 6, alpha(c, e));
        }
    }

    // ------------------------------------------------------------ settings popup
    private void drawPopup(GuiGraphics g, int mx, int my, float dt, float e, int acc) {
        setAnim = Ui.approach(setAnim, 1f, dt, 12f);
        float pe = e * ease(setAnim);
        int col = -1;
        for (int c = 0; c < 5 && col < 0; c++) for (Cat k : GROUPS[c]) if (k == sel.cat) { col = c; break; }
        if (col < 0) col = 0;
        spW = 124;
        int rowH = 15;
        List<String> lines = sel.desc.isEmpty() ? new ArrayList<>() : Ui.wrap(sel.desc, spW - 16);
        int nl = Math.min(lines.size(), 4);
        int headH = 22 + nl * 10 + (nl > 0 ? 4 : 0) + 16;
        int maxSet = Math.max(0, colH - headH - 8);
        int setH = Math.min(sel.settings.size() * rowH, maxSet);
        spH = headH + setH + 6;
        boolean right = colX[col] + colW + 6 + spW <= width - 6;
        spX = right ? colX[col] + colW + 6 : colX[col] - 6 - spW;
        spY = colY + 4;
        int x = spX + (int) ((1f - ease(setAnim)) * (right ? -8 : 8));
        int y = spY;

        rr(g, x - 1, y - 1, spW + 2, spH + 2, 11, alpha(acc, 0.35f * pe));
        rr(g, x, y, spW, spH, 10, alpha(0x121814, 0.94f * pe));
        Ui.d(g, sel.name, x + 9, y + 8, alpha(acc, pe), false);
        g.fill(x + 8, y + 19, x + spW - 8, y + 20, alpha(acc, 0.3f * pe));
        for (int i = 0; i < nl; i++) Ui.d(g, lines.get(i), x + 9, y + 24 + i * 10, alpha(0x9DB8A8, pe), false);
        int by = y + 22 + nl * 10 + (nl > 0 ? 4 : 0);
        String bind = binding == sel ? "нажми клавишу..." : "Бинд: " + (sel.key >= 0 ? keyName(sel.key) : "нет");
        rr(g, x + 8, by, spW - 16, 13, 4, alpha(0x1B2620, pe));
        Ui.d(g, bind, x + 12, by + 3, alpha(0xC4D2CA, pe), false);

        spSetTop = by + 17;
        spSetBot = spSetTop + setH;
        if (sel.settings.isEmpty()) {
            Ui.d(g, "Нет настроек", x + 9, spSetTop + 1, alpha(0x647A6D, pe), false);
            spH = headH + 16;
            return;
        }
        int total = sel.settings.size() * rowH;
        spScrollT = Mth.clamp(spScrollT, 0f, Math.max(0, total - setH));
        spScroll = Ui.approach(spScroll, spScrollT, dt, 14f);
        g.enableScissor(x, spSetTop, x + spW, spSetBot);
        int sy = spSetTop - Math.round(spScroll);
        for (Setting s : sel.settings) {
            if (sy + rowH >= spSetTop && sy <= spSetBot) drawSetting(g, s, x + 8, sy, spW - 16, pe, acc, dt);
            sy += rowH;
        }
        g.disableScissor();
    }

    private void drawSetting(GuiGraphics g, Setting s, int x, int y, int w, float e, int acc, float dt) {
        rr(g, x, y, w, 13, 4, alpha(0x1B2620, e));
        if (s instanceof Bool b) {
            Ui.d(g, b.name, x + 4, y + 3, alpha(0xC4D2CA, e), false);
            rr(g, x + w - 18, y + 3, 14, 7, 3, alpha(mix(0x2A3A31, acc, b.v ? 1f : 0f), e));
            rr(g, x + w - 17 + (b.v ? 7 : 0), y + 4, 5, 5, 2, alpha(0xFFFFFF, e));
        } else if (s instanceof Num n) {
            if (Double.isNaN(n.shown)) n.shown = n.v;
            n.shown += (n.v - n.shown) * Math.min(1f, dt * 16f);
            double f = (n.shown - n.min) / (n.max - n.min);
            rr(g, x, y, Math.max(4, (int) (w * f)), 13, 4, alpha(mix(0x1B2B22, acc, 0.4f), e));
            String val = n.labels != null && (int) n.v >= 0 && (int) n.v < n.labels.length ? n.labels[(int) n.v]
                : n.step >= 1 ? String.valueOf((int) n.v) : String.format("%.2f", n.v);
            Ui.d(g, n.name, x + 4, y + 3, alpha(0xF0FFF6, e), false);
            Ui.d(g, val, x + w - 4 - Ui.w(val), y + 3, alpha(0xF0FFF6, e), false);
        }
    }

    private void drawTooltip(GuiGraphics g, int mx, int my, float e, int acc) {
        long held = System.currentTimeMillis() - hoverSince;
        if (hoverMod == null || hoverMod.desc.isEmpty() || held < 350 || closing || hoverMod == sel) return;
        float fade = ease((held - 350) / 160f);
        List<String> lines = Ui.wrap(hoverMod.desc, 170);
        int tw = Ui.w(hoverMod.name);
        for (String l : lines) tw = Math.max(tw, Ui.w(l));
        tw += 14;
        int th = 18 + lines.size() * 10 + 4;
        int tx = Math.min(mx + 12, width - tw - 4);
        int ty = Math.min(my + 14, height - th - 4);
        g.pose().pushPose();
        g.pose().translate(0, 0, 400);
        rr(g, tx - 1, ty - 1, tw + 2, th + 2, 6, alpha(acc, 0.45f * fade));
        rr(g, tx, ty, tw, th, 5, alpha(0x0A100D, 0.97f * fade));
        Ui.d(g, hoverMod.name, tx + 7, ty + 5, alpha(acc, fade), false);
        for (int i = 0; i < lines.size(); i++) Ui.d(g, lines.get(i), tx + 7, ty + 18 + i * 10, alpha(0xD5E2DA, fade), false);
        g.pose().popPose();
    }

    private static String keyName(int key) {
        return InputConstants.getKey(key, 0).getDisplayName().getString();
    }

    // ------------------------------------------------------------ input
    private int colAt(double mx, double my) {
        for (int c = 0; c < 5; c++) if (mx >= colX[c] && mx <= colX[c] + colW && my >= colY && my <= colY + colH) return c;
        return -1;
    }

    private Mod modAt(int col, double my) {
        List<Mod> list = mods(col);
        if (my < colY + 26 || my > colY + colH - 6) return null;
        int idx = (int) ((my - (colY + 26) + Math.round(scroll[col])) / 14);
        return idx >= 0 && idx < list.size() ? list.get(idx) : null;
    }

    private void setSlider(double mx) {
        if (dragging == null) return;
        double f = Mth.clamp((mx - dragX) / dragW, 0, 1);
        double v = dragging.min + f * (dragging.max - dragging.min);
        v = Math.round(v / dragging.step) * dragging.step;
        dragging.v = Mth.clamp(v, dragging.min, dragging.max);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int btn) {
        boolean wasSearch = searching;
        searching = false;
        if (binding != null) { binding = null; return true; }

        // popup first
        if (sel != null && inPopup(mx, my)) {
            int by = spY + 22 + Math.min(Ui.wrap(sel.desc, spW - 16).size(), 4) * 10;
            if (!sel.desc.isEmpty()) by += 4;
            if (my >= by && my <= by + 13 && btn == 0) { binding = sel; return true; }
            if (my >= spSetTop && my <= spSetBot) {
                int idx = (int) ((my - spSetTop + Math.round(spScroll)) / 15);
                if (idx >= 0 && idx < sel.settings.size()) {
                    Setting s = sel.settings.get(idx);
                    if (s instanceof Bool b) { b.v = !b.v; saveConfig(); }
                    else if (s instanceof Num n) { dragging = n; dragX = spX + 8; dragW = spW - 16; setSlider(mx); }
                }
            }
            return true;
        }

        // search field
        if (mx >= sfX() && mx <= sfX() + sfW() && my >= sfY() && my <= sfY() + 14) { searching = true; return true; }
        // store
        if (mx >= 10 && mx <= 92 && my >= height - 26 && my <= height - 10) { minecraft.setScreen(new ModsScreen(this)); return true; }
        // themes
        int bx = width - 10 - (HUES.length + 1) * 16;
        for (int i = 0; i < HUES.length + 1; i++) {
            int x = bx + i * 16, y = height - 24;
            if (mx < x || mx > x + 12 || my < y || my > y + 12 || theme == null) continue;
            Bool st = null;
            Num hue = null;
            for (Setting s : theme.settings) {
                if (s instanceof Bool b && b.name.equals("Static")) st = b;
                if (s instanceof Num n && n.name.equals("Hue")) hue = n;
            }
            if (st != null && hue != null) {
                if (i == HUES.length) st.v = false;
                else { st.v = true; hue.v = HUES[i]; }
                saveConfig();
            }
            return true;
        }

        int col = colAt(mx, my);
        if (col >= 0) {
            Mod m = modAt(col, my);
            if (m != null) {
                boolean dots = mx >= colX[col] + colW - 16;
                if (btn == 0 && !dots) { m.toggle(); }
                else if (btn == 2) { binding = m; return true; }
                if (btn == 1 || (btn == 0 && dots)) {
                    if (sel != m) { sel = m; setAnim = 0f; spScroll = 0; spScrollT = 0; }
                    else sel = null;
                }
                return true;
            }
        }
        if (btn == 0 && sel != null) sel = null;
        if (wasSearch) return true;
        return super.mouseClicked(mx, my, btn);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int btn, double dx, double dy) {
        if (dragging != null) { setSlider(mx); return true; }
        return super.mouseDragged(mx, my, btn, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int btn) {
        if (dragging != null) saveConfig();
        dragging = null;
        return super.mouseReleased(mx, my, btn);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double sx, double sy) {
        if (inPopup(mx, my)) { spScrollT -= (float) (sy * 20.0); return true; }
        int col = colAt(mx, my);
        if (col >= 0) scrollT[col] -= (float) (sy * 28.0);
        return true;
    }

    @Override
    public boolean charTyped(char c, int mods) {
        if (searching && query.length() < 20 && c >= 32) {
            query += c;
            for (int i = 0; i < 5; i++) { scrollT[i] = 0; scroll[i] = 0; }
            return true;
        }
        return super.charTyped(c, mods);
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (binding != null) {
            if (key == GLFW.GLFW_KEY_ESCAPE || key == GLFW.GLFW_KEY_DELETE || key == GLFW.GLFW_KEY_BACKSPACE) binding.key = -1;
            else binding.key = key;
            binding = null;
            saveConfig();
            return true;
        }
        if (key == GLFW.GLFW_KEY_RIGHT_SHIFT) { onClose(); return true; }
        if (searching) {
            if (key == GLFW.GLFW_KEY_BACKSPACE && !query.isEmpty()) { query = query.substring(0, query.length() - 1); return true; }
            if (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_ESCAPE) { searching = false; return true; }
        }
        if (key == GLFW.GLFW_KEY_ESCAPE && sel != null) { sel = null; return true; }
        return super.keyPressed(key, scan, mods);
    }

    /** Close with a short fade-out instead of vanishing instantly. */
    @Override
    public void onClose() { closing = true; }

    @Override
    public void tick() {
        if (closing && open <= 0f) minecraft.setScreen(null);
    }

    @Override
    public void removed() { saveConfig(); }

    @Override
    public boolean isPauseScreen() { return false; }
}
