package com.pretty.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.core.component.DataComponents;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/** Public bridge for mixins (the client classes themselves are package-private). */
public final class Hooks {
    private Hooks() {}

    /** True when NoRender is enabled and the given option is switched on. */
    public static boolean noRender(String option) {
        PrettyClient.Mod m = PrettyClient.find("NoRender");
        return m != null && m.enabled && m.b(option);
    }

    /**
     * SafeWalk: same edge check as vanilla sneaking, but without sneaking. Returns the (possibly shortened)
     * movement, or null when SafeWalk does not apply.
     */
    public static Vec3 safeWalk(Player p, Vec3 v) {
        PrettyClient.Mod m = PrettyClient.find("SafeWalk");
        if (m == null || !m.enabled) return null;
        Minecraft mc = Minecraft.getInstance();
        if (p != mc.player || !p.onGround() || v.y > 0 || p.getAbilities().flying) return null;
        if (m.b("Only with blocks") && !(p.getMainHandItem().getItem() instanceof BlockItem)) return null;
        double x = v.x, z = v.z, step = 0.05, drop = 0.6;
        AABB bb = p.getBoundingBox();
        while (x != 0 && p.level().noCollision(p, bb.move(x, -drop, 0))) x = Math.abs(x) <= step ? 0 : x - Math.copySign(step, x);
        while (z != 0 && p.level().noCollision(p, bb.move(0, -drop, z))) z = Math.abs(z) <= step ? 0 : z - Math.copySign(step, z);
        while (x != 0 && z != 0 && p.level().noCollision(p, bb.move(x, -drop, z))) {
            x = Math.abs(x) <= step ? 0 : x - Math.copySign(step, x);
            z = Math.abs(z) <= step ? 0 : z - Math.copySign(step, z);
        }
        return new Vec3(x, v.y, z);
    }

    // ------------------------------------------------------------------ SkyChanger
    static int hsv(float h, float s, float v) {
        h = h - (float) Math.floor(h);
        float c = v * s, x = c * (1f - Math.abs((h * 6f) % 2f - 1f)), m = v - c, r, g, b;
        int i = (int) (h * 6f);
        switch (i) {
            case 0 -> { r = c; g = x; b = 0; }
            case 1 -> { r = x; g = c; b = 0; }
            case 2 -> { r = 0; g = c; b = x; }
            case 3 -> { r = 0; g = x; b = c; }
            case 4 -> { r = x; g = 0; b = c; }
            default -> { r = c; g = 0; b = x; }
        }
        return ((int) ((r + m) * 255f) << 16) | ((int) ((g + m) * 255f) << 8) | (int) ((b + m) * 255f);
    }

    /** Tinted sky or cloud colour, or null when SkyChanger is off. Keeps the day/night brightness of the original colour. */
    public static Vec3 skyColor(Vec3 orig, boolean cloud) {
        PrettyClient.Mod m = PrettyClient.find("SkyChanger");
        if (m == null || !m.enabled || orig == null || !m.b(cloud ? "Cloud color" : "Sky color")) return null;
        float hue = (float) m.n("Hue");
        if (m.b("Rainbow")) hue += (System.currentTimeMillis() % 3600000L) / 1000f * (float) m.n("Speed") * 0.03f;
        int rgb = hsv(hue, (float) m.n("Saturation"), 1f);
        double light = m.b("Keep day/night") ? Math.max(orig.x, Math.max(orig.y, orig.z)) : m.n("Brightness");
        double k = m.n("Alpha");
        double r = (rgb >> 16 & 255) / 255.0 * light, g = (rgb >> 8 & 255) / 255.0 * light, b = (rgb & 255) / 255.0 * light;
        return new Vec3(orig.x + (r - orig.x) * k, orig.y + (g - orig.y) * k, orig.z + (b - orig.z) * k);
    }

    /** Fixed time of day when SkyChanger has "Fixed time" on, otherwise the server time. */
    public static long dayTime(long orig) {
        PrettyClient.Mod m = PrettyClient.find("SkyChanger");
        if (m == null || !m.enabled || !m.b("Fixed time")) return orig;
        return (long) m.n("Time");
    }

    /** Hands: gradient buffer source for the first-person arm, or the original one when the module is off. */
    public static MultiBufferSource handBuffer(MultiBufferSource src) {
        PrettyClient.Mod m = PrettyClient.find("Hands");
        if (m == null || !m.enabled || src == null) return src;
        return new HandGradient.Source(src, m);
    }

    // ------------------------------------------------------------------ CustomHand / ItemShader
    /** The stack of the item that is being drawn in first person right now (set by the mixin). */
    public static ItemStack curStack = ItemStack.EMPTY;

    static final String[] CATS = {"Swords", "Tools", "Totems", "Food", "Blocks", "Other"};

    static int itemCategory(ItemStack s) {
        if (s.is(Items.TOTEM_OF_UNDYING)) return 2;
        if (s.is(ItemTags.SWORDS)) return 0;
        if (s.is(ItemTags.PICKAXES) || s.is(ItemTags.AXES) || s.is(ItemTags.SHOVELS) || s.is(ItemTags.HOES)) return 1;
        if (s.has(DataComponents.FOOD)) return 3;
        if (s.getItem() instanceof BlockItem) return 4;
        return 5;
    }

    private static boolean handEnabled(PrettyClient.Mod m, InteractionHand hand) {
        return m.b(hand == InteractionHand.MAIN_HAND ? "Main hand" : "Off hand");
    }

    private static float side(InteractionHand hand) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return 1f;
        HumanoidArm arm = hand == InteractionHand.MAIN_HAND ? mc.player.getMainArm() : mc.player.getMainArm().getOpposite();
        return arm == HumanoidArm.RIGHT ? 1f : -1f;
    }

    /**
     * CustomHand, held item: called right before the item is drawn, after the vanilla swing / equip transforms,
     * so the hit animation plays on top of your pose and the arm is not touched. Applies to EVERY item.
     * Axes: X right, Y up, Z forward (negative = away from you).
     */
    public static void customItem(PoseStack ps, InteractionHand hand, ItemStack stack) {
        try {
            PrettyClient.Mod m = PrettyClient.find("CustomHand");
            if (m == null || !m.enabled || !handEnabled(m, hand)) return;
            float side = side(hand);
            double x = m.n("X"), y = m.n("Y"), z = m.n("Z");
            float rx = (float) m.n("Rot X"), ry = (float) m.n("Rot Y"), rz = (float) m.n("Rot Z");
            double sc = m.n("Scale");
            if (m.b("Lying pose")) {
                x -= 0.04; y -= 0.06; z += 0.05;
                rx += -8f; ry += -12f; rz += 62f;
            }
            ps.translate(x * side, y, z);
            int sm = (int) m.n("Swing mode");
            if (sm > 0 && hand == InteractionHand.MAIN_HAND && curSwing > 0f && curSwing < 1f) {
                double pw = m.n("Swing power");
                float sv = (float) Math.sin(curSwing * Math.PI);
                switch (sm) {
                    case 1 -> {
                        ps.mulPose(Axis.XP.rotationDegrees((float) (-62 * pw * sv)));
                        ps.mulPose(Axis.ZP.rotationDegrees((float) (14 * pw * sv) * side));
                        ps.translate(0, 0, -0.04 * pw * sv);
                    }
                    case 2 -> {
                        ps.translate(0, 0.02 * pw * sv, -0.32 * pw * sv);
                        ps.mulPose(Axis.XP.rotationDegrees((float) (-8 * pw * sv)));
                    }
                    default -> {
                        ps.mulPose(Axis.ZP.rotationDegrees((float) (-48 * pw * sv) * side));
                        ps.mulPose(Axis.XP.rotationDegrees((float) (-34 * pw * sv)));
                    }
                }
            }
            ps.mulPose(Axis.XP.rotationDegrees(rx));
            ps.mulPose(Axis.YP.rotationDegrees(ry * side));
            ps.mulPose(Axis.ZP.rotationDegrees(rz * side));
            ps.scale((float) sc, (float) sc, (float) sc);
        } catch (RuntimeException ignored) {
        }
    }

    /** CustomHand, empty arm: own offset and size, independent from the item settings. */
    public static void customArm(PoseStack ps, InteractionHand hand) {
        try {
            PrettyClient.Mod m = PrettyClient.find("CustomHand");
            if (m == null || !m.enabled || !handEnabled(m, hand)) return;
            float side = side(hand);
            ps.translate(m.n("Arm X") * side, m.n("Arm Y"), m.n("Arm Z"));
            float sc = (float) m.n("Arm scale");
            ps.scale(sc, sc, sc);
        } catch (RuntimeException ignored) {
        }
    }

    /** Swing progress (0..1) of the item being drawn; used by our own swing animation. */
    public static float curSwing;

    /**
     * CustomHand: eases the swing progress. With "Swing mode" > 0 the vanilla swing movement is switched off
     * for held items (returns 0) and customItem() plays our own swing around the item instead.
     */
    public static float swing(float t) {
        PrettyClient.Mod m = PrettyClient.find("CustomHand");
        if (m == null || !m.enabled) { curSwing = 0f; return t; }
        float e = t;
        double k = m.n("Swing smoothing");
        if (t > 0f && t < 1f && k > 0) {
            float ee = t * t * (3f - 2f * t);
            e = (float) (t + (ee - t) * k);
        }
        curSwing = e;
        Minecraft mc = Minecraft.getInstance();
        if ((int) m.n("Swing mode") > 0 && mc.player != null && !mc.player.getMainHandItem().isEmpty()) return 0f;
        return e;
    }

    // ------------------------------------------------------------------ silent rotation (KillAura)
    public static boolean silent;
    public static float sYaw, sPitch;
    private static float rYaw, rPitch;
    private static boolean swapped;

    /** Called at the start of LocalPlayer.sendPosition: the server gets the aura rotation, your camera is untouched. */
    public static void silentPre(net.minecraft.client.player.LocalPlayer p) {
        if (!silent) return;
        rYaw = p.getYRot();
        rPitch = p.getXRot();
        p.setYRot(sYaw);
        p.setXRot(sPitch);
        swapped = true;
    }

    public static void silentPost(net.minecraft.client.player.LocalPlayer p) {
        if (!swapped) return;
        p.setYRot(rYaw);
        p.setXRot(rPitch);
        swapped = false;
    }

    // ------------------------------------------------------------------ Jesus
    /** Called from LivingEntity.canStandOnFluid: the local player may stand on water (and lava if enabled). */
    public static boolean jesus(Object self, net.minecraft.world.level.material.FluidState fluid) {
        Minecraft mc = Minecraft.getInstance();
        if (self != mc.player || mc.player == null) return false;
        PrettyClient.Mod m = PrettyClient.find("Jesus");
        if (m == null || !m.enabled || mc.player.isShiftKeyDown()) return false;
        if (fluid.is(net.minecraft.tags.FluidTags.WATER)) return true;
        return m.b("Lava") && fluid.is(net.minecraft.tags.FluidTags.LAVA);
    }

    /** ItemShader: buffer source that tints the held item (per item type), or the original one when off. */
    public static MultiBufferSource itemBuffer(MultiBufferSource src) {
        PrettyClient.Mod m = PrettyClient.find("ItemShader");
        if (m == null || !m.enabled || src == null) return src;
        return new HandGradient.ItemSource(src, m);
    }

    // ------------------------------------------------------------------ SkyParticles colour
    /** RGB colour picked in SkyChanger (hue, saturation, rainbow); soft pink when SkyChanger is off. */
    static int skyRgb() {
        PrettyClient.Mod m = PrettyClient.find("SkyChanger");
        if (m == null || !m.enabled || !m.b("Sky color")) return 0xFF7AC8;
        float hue = (float) m.n("Hue");
        if (m.b("Rainbow")) hue += (System.currentTimeMillis() % 3600000L) / 1000f * (float) m.n("Speed") * 0.03f;
        return hsv(hue, (float) m.n("Saturation"), 1f);
    }

    // ------------------------------------------------------------------ ChunkFade
    private static final java.util.Map<Long, Long> SEEN = new java.util.HashMap<>();
    private static Object seenLevel;

    private static long secKey(int sx, int sy, int sz) {
        return ((long) (sx & 0x3FFFFFF) << 38) | ((long) (sz & 0x3FFFFFF) << 12) | (sy & 0xFFF);
    }

    /** Vertical offset (<= 0) for a chunk section: it rises from below the first time it is drawn. */
    public static float chunkRise(float x, float y, float z) {
        if (cbCrowd) return 0f;
        PrettyClient.Mod m = PrettyClient.find("ChunkFade");
        if (m == null || !m.enabled) return 0f;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.gameRenderer == null) return 0f;
        if (seenLevel != mc.level) { SEEN.clear(); seenLevel = mc.level; }
        Vec3 cam = mc.gameRenderer.getMainCamera().getPosition();
        int sx = Math.floorDiv((int) Math.round(x + cam.x), 16);
        int sy = Math.floorDiv((int) Math.round(y + cam.y), 16);
        int sz = Math.floorDiv((int) Math.round(z + cam.z), 16);
        long key = secKey(sx, sy, sz);
        long now = System.nanoTime();
        Long t0 = SEEN.get(key);
        if (t0 == null) { SEEN.put(key, now); t0 = now; }
        double dur = Math.max(0.1, m.n("Duration")) * 1e9;
        double p = (now - t0) / dur;
        if (p >= 1.0) return 0f;
        double inv = 1.0 - p;
        double ease = 1.0 - inv * inv * inv;
        return (float) (-m.n("Depth") * (1.0 - ease));
    }

    /** Forgets sections far from the player so the table does not grow forever. */
    static void chunkPrune(Minecraft mc) {
        if (SEEN.isEmpty() || mc.player == null) return;
        int px = Math.floorDiv((int) mc.player.getX(), 16), pz = Math.floorDiv((int) mc.player.getZ(), 16);
        int r = mc.options.getEffectiveRenderDistance() + 3;
        SEEN.keySet().removeIf(k -> {
            int sx = (int) (k >> 38), sz = (int) ((k >> 12) & 0x3FFFFFF);
            if (sx >= 0x2000000) sx -= 0x4000000;
            if (sz >= 0x2000000) sz -= 0x4000000;
            return Math.abs(sx - px) > r || Math.abs(sz - pz) > r;
        });
    }

    // ------------------------------------------------------------------ CrowdBoost
    private static final java.util.Set<Integer> CB_ALLOWED = new java.util.HashSet<>();
    private static final java.util.Map<Integer, Integer> CB_HID = new java.util.HashMap<>();
    private static boolean cbOn, cbCrowd, cbItems, cbCap, cbArmor, cbLite, cbNames, cbHeld, cbSound;
    private static double cbFarSq = 56 * 56, cbItemSq = 32 * 32, cbArmorSq = 24 * 24, cbNameSq = 20 * 20;
    private static int cbSndBudget = 14, cbSndSpent, cbPhase;
    private static final double CB_PART_SQ = 24 * 24;
    private static int cbBudget = 60, cbSpent;

    /** True while a crowd is around and "Lite HUD" is on: decorative HUD effects are skipped. */
    public static boolean liteHud() { return cbOn && cbCrowd && cbLite; }

    /** Once per client tick: counts players around you and decides who is still drawn in full. */
    public static void crowdTick(Minecraft mc, PrettyClient.Mod m) {
        cbOn = true;
        cbItems = m.b("Cull items");
        cbCap = m.b("Particle cap");
        cbArmor = m.b("Hide far armor");
        cbLite = m.b("Lite HUD");
        cbNames = m.b("Hide far nametags");
        cbHeld = m.b("Hide far held items");
        cbSound = m.b("Sound cap");
        cbSndBudget = (int) m.n("Sounds per tick");
        cbSndSpent = 0;
        cbPhase++;
        double nr = m.n("Name range");
        cbNameSq = nr * nr;
        double far = m.n("Far range"), ir = m.n("Item range"), ar = m.n("Armor range");
        cbFarSq = far * far;
        cbItemSq = ir * ir;
        cbArmorSq = ar * ar;
        cbBudget = (int) m.n("Particles per tick");
        cbSpent = 0;
        CB_ALLOWED.clear();
        if (!cbCrowd) CB_HID.clear();
        if (mc.level == null || mc.player == null) {
            cbCrowd = false;
            crowdSettings(mc, false);
            return;
        }
        final net.minecraft.client.player.LocalPlayer self = mc.player;
        java.util.List<net.minecraft.client.player.AbstractClientPlayer> near = new java.util.ArrayList<>();
        for (net.minecraft.client.player.AbstractClientPlayer p : mc.level.players()) {
            if (p != self && p.distanceToSqr(self) <= cbFarSq) near.add(p);
        }
        cbCrowd = near.size() >= (int) m.n("Crowd at");
        if (cbCrowd) {
            near.sort(java.util.Comparator.comparingDouble(p -> p.distanceToSqr(self)));
            int max = (int) m.n("Max players");
            boolean occl = m.b("Hide behind walls");
            for (int i = 0; i < near.size(); i++) {
                net.minecraft.client.player.AbstractClientPlayer p = near.get(i);
                double d2 = p.distanceToSqr(self);
                boolean keep = i < max || d2 < 100;
                if (keep && occl && d2 > 144) {
                    int n = CB_HID.getOrDefault(p.getId(), 0);
                    if ((cbPhase + p.getId()) % 3 == 0) {          // staggered: every player is tested only every 3rd tick
                        n = seenFrom(mc, self, p) ? 0 : n + 1;
                        CB_HID.put(p.getId(), n);
                    }
                    if (n >= 2) keep = false;   // hidden behind blocks for 2 tests in a row (~6 ticks)
                } else {
                    CB_HID.remove(p.getId());
                }
                if (keep) CB_ALLOWED.add(p.getId());
            }
            if (mc.crosshairPickEntity != null) CB_ALLOWED.add(mc.crosshairPickEntity.getId());
        }
        crowdSettings(mc, cbCrowd && m.b("Auto settings"));
    }

    /** True when at least one of a few points on the player can be seen from your eyes (glass and plants do not block). */
    private static boolean seenFrom(Minecraft mc, net.minecraft.client.player.LocalPlayer self,
                                    net.minecraft.client.player.AbstractClientPlayer p) {
        Vec3 eye = self.getEyePosition();
        double[][] pts = {{0, 0.2, 0}, {0, 0.9, 0}, {0, 1.6, 0}, {0.35, 1.6, 0}, {-0.35, 1.6, 0}};
        for (double[] o : pts) {
            Vec3 to = new Vec3(p.getX() + o[0], p.getY() + o[1], p.getZ() + o[2]);
            net.minecraft.world.phys.BlockHitResult r = mc.level.clip(new net.minecraft.world.level.ClipContext(
                eye, to, net.minecraft.world.level.ClipContext.Block.VISUAL,
                net.minecraft.world.level.ClipContext.Fluid.NONE, self));
            if (r.getType() == net.minecraft.world.phys.HitResult.Type.MISS) return true;
        }
        return false;
    }

    private static void crowdSettings(Minecraft mc, boolean on) {
        if (on) {
            PrettyClient.force("cb_shadow", mc.options.entityShadows(), false);
            if (mc.options.particles().get() == net.minecraft.server.level.ParticleStatus.ALL)
                PrettyClient.force("cb_part", mc.options.particles(), net.minecraft.server.level.ParticleStatus.DECREASED);
            PrettyClient.force("cb_cloud", mc.options.cloudStatus(), net.minecraft.client.CloudStatus.OFF);
        } else {
            PrettyClient.restore("cb_shadow");
            PrettyClient.restore("cb_part");
            PrettyClient.restore("cb_cloud");
        }
    }

    public static void crowdOff() {
        CB_HID.clear();
        cbOn = false;
        cbCrowd = false;
        CB_ALLOWED.clear();
        crowdSettings(Minecraft.getInstance(), false);
    }

    /** True = do not render this entity this frame. */
    public static boolean cullEntity(net.minecraft.world.entity.Entity e) {
        if (!cbOn) return false;
        if (e instanceof net.minecraft.client.player.AbstractClientPlayer) {
            return cbCrowd && e != Minecraft.getInstance().player && !CB_ALLOWED.contains(e.getId());
        }
        if (cbItems && (e instanceof net.minecraft.world.entity.item.ItemEntity
            || e instanceof net.minecraft.world.entity.ExperienceOrb)) {
            net.minecraft.client.player.LocalPlayer p = Minecraft.getInstance().player;
            return p != null && e.distanceToSqr(p) > cbItemSq;
        }
        return false;
    }

    private static boolean optOn;
    private static double optBeSq = 48 * 48, optPartSq = 24 * 24;

    /** Called by the Optimize module every tick. */
    public static void setOpt(boolean on, double beRange, double particleRange) {
        optOn = on;
        optBeSq = beRange * beRange;
        optPartSq = particleRange * particleRange;
    }

    public static boolean cullBlockEntity(net.minecraft.world.level.block.entity.BlockEntity be) {
        if (!optOn) return false;
        Vec3 cam = Minecraft.getInstance().gameRenderer.getMainCamera().getPosition();
        return be.getBlockPos().distToCenterSqr(cam) > optBeSq;
    }

    public static boolean allowParticle(net.minecraft.client.particle.Particle p) {
        boolean crowd = cbOn && cbCap && cbCrowd;
        if (!crowd && !optOn) return true;
        if (crowd && ++cbSpent > cbBudget) return false;
        double lim = crowd ? (optOn ? Math.min(CB_PART_SQ, optPartSq) : CB_PART_SQ) : optPartSq;
        Vec3 cam = Minecraft.getInstance().gameRenderer.getMainCamera().getPosition();
        return p.getBoundingBox().getCenter().distanceToSqr(cam) <= lim;
    }

    public static boolean hideArmor(double distSq) {
        return cbOn && cbCrowd && cbArmor && distSq > cbArmorSq;
    }

    /** Held items of far players (a second model render per hand) are skipped in a crowd. */
    public static boolean hideHeld(double distSq) {
        return cbOn && cbCrowd && cbHeld && distSq > cbArmorSq;
    }

    /** Name tags (text + background quad per player) of far players are skipped in a crowd. */
    public static boolean hideNameTag(double distSq) {
        return cbOn && cbCrowd && cbNames && distSq > cbNameSq;
    }

    /**
     * Sound budget in a crowd: 20-30 players produce hundreds of hit / hurt / step sounds a second and every one
     * of them costs a mixer voice. UI sounds, music and anything within 6 blocks of you always play.
     */
    public static boolean allowSound(net.minecraft.client.resources.sounds.SoundInstance s) {
        if (!(cbOn && cbCrowd && cbSound)) return true;
        if (s.isRelative() || s.getAttenuation() == net.minecraft.client.resources.sounds.SoundInstance.Attenuation.NONE) return true;
        net.minecraft.sounds.SoundSource src = s.getSource();
        if (src != net.minecraft.sounds.SoundSource.PLAYERS && src != net.minecraft.sounds.SoundSource.BLOCKS
            && src != net.minecraft.sounds.SoundSource.HOSTILE && src != net.minecraft.sounds.SoundSource.NEUTRAL) return true;
        net.minecraft.client.player.LocalPlayer p = Minecraft.getInstance().player;
        if (p == null) return true;
        if (p.distanceToSqr(s.getX(), s.getY(), s.getZ()) < 36) return true;
        return ++cbSndSpent <= cbSndBudget;
    }
}
