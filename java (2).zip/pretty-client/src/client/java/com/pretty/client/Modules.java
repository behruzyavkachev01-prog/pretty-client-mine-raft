package com.pretty.client;

import static com.pretty.client.PrettyClient.*;

import java.util.function.Predicate;
import org.lwjgl.glfw.GLFW;
import net.minecraft.client.CloudStatus;
import net.minecraft.client.GraphicsStatus;
import net.minecraft.client.Minecraft;
import net.minecraft.server.level.ParticleStatus;
import net.minecraft.client.gui.screens.DeathScreen;
import net.minecraft.client.gui.screens.inventory.ContainerScreen;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/** Every module lives here. Add new ones inside register(). */
final class Modules {
    private Modules() {}

    // shared per-module state
    static boolean gapEating;
    static int gapTimeout, gapCd;
    static int gapPrev = -1, eatPrev = -1, toolPrev = -1, scafPrev = -1;
    static boolean eagling, pearlMidDown;

    // =====================================================================
    //  Helpers
    // =====================================================================
    static Vec3 moveDir(Minecraft mc) {
        double fwd = (mc.options.keyUp.isDown() ? 1 : 0) - (mc.options.keyDown.isDown() ? 1 : 0);
        double str = (mc.options.keyLeft.isDown() ? 1 : 0) - (mc.options.keyRight.isDown() ? 1 : 0);
        if (fwd == 0 && str == 0) return Vec3.ZERO;
        double yaw = mc.player.getYRot() * Mth.DEG_TO_RAD;
        double sin = Math.sin(yaw), cos = Math.cos(yaw);
        double x = -sin * fwd + cos * str;
        double z = cos * fwd + sin * str;
        double len = Math.sqrt(x * x + z * z);
        return new Vec3(x / len, 0, z / len);
    }

    static void jump(Player p, double h) {
        Vec3 v = p.getDeltaMovement();
        p.setDeltaMovement(v.x, h, v.z);
    }

    static int findHotbar(Player p, Predicate<ItemStack> f) {
        for (int i = 0; i < 9; i++) if (f.test(p.getInventory().getItem(i))) return i;
        return -1;
    }

    /** Target filter shared by KillAura / TriggerBot / AimAssist / AutoClicker (uses Players/Mobs/Animals/Invisible/Teams). */
    static boolean validTarget(Minecraft mc, Mod m, Entity e) {
        if (e == mc.player || !(e instanceof LivingEntity le) || !le.isAlive()) return false;
        if (!m.b("Invisible") && e.isInvisible()) return false;
        if (m.b("Teams") && e.isAlliedTo(mc.player)) return false;
        if (e instanceof Player && on("AntiBot") && (mc.getConnection() == null
            || mc.getConnection().getPlayerInfo(e.getUUID()) == null)) return false;
        return (e instanceof Player && m.b("Players"))
            || (e instanceof Monster && m.b("Mobs"))
            || (e instanceof Animal && m.b("Animals"));
    }

    /** True when there is no floor a bit ahead of the player (ledge). */
    static boolean edgeAhead(Minecraft mc, double ahead) {
        Player p = mc.player;
        Vec3 d = moveDir(mc);
        if (d.lengthSqr() == 0) return false;
        double px = p.getX() + d.x * ahead, pz = p.getZ() + d.z * ahead;
        AABB box = new AABB(px - 0.12, p.getY() - 0.5, pz - 0.12, px + 0.12, p.getY() - 0.02, pz + 0.12);
        return mc.level.noCollision(box);
    }

    static boolean badFood(ItemStack s) {
        return s.is(Items.ROTTEN_FLESH) || s.is(Items.SPIDER_EYE) || s.is(Items.PUFFERFISH)
            || s.is(Items.POISONOUS_POTATO) || s.is(Items.CHORUS_FRUIT)
            || s.is(Items.GOLDEN_APPLE) || s.is(Items.ENCHANTED_GOLDEN_APPLE);
    }

    /** Smoothly turns the camera toward an entity (max degrees per tick). */
    static void face(Minecraft mc, Entity e, float maxStep) {
        Player p = mc.player;
        Vec3 t = e.position().add(0, e.getBbHeight() * 0.6, 0).subtract(p.getEyePosition());
        float yawT = (float) (Math.toDegrees(Math.atan2(t.z, t.x)) - 90.0);
        float pitchT = (float) -Math.toDegrees(Math.atan2(t.y, Math.sqrt(t.x * t.x + t.z * t.z)));
        float dy = Mth.wrapDegrees(yawT - p.getYRot());
        float dp = pitchT - p.getXRot();
        p.setYRot(p.getYRot() + Mth.clamp(dy, -maxStep, maxStep));
        p.setXRot(Mth.clamp(p.getXRot() + Mth.clamp(dp, -maxStep, maxStep), -90f, 90f));
    }

    static LivingEntity auraTarget;
    static int auraAim, auraReady, auraDelay = -1;

    static boolean auraOk(Minecraft mc, Mod m, LivingEntity e, double aimRange, double fov) {
        Player p = mc.player;
        if (!validTarget(mc, m, e) || p.distanceTo(e) > aimRange) return false;
        if (!m.b("Walls") && !p.hasLineOfSight(e)) return false;
        return fov >= 360 || Math.abs(Mth.wrapDegrees(aimAngles(p, e)[0] - p.getYRot())) <= fov / 2;
    }

    /** Yaw / pitch that point the eyes at the body of the target (nearest height inside the hitbox). */
    static float[] aimAngles(Player p, LivingEntity e) {
        Vec3 eye = p.getEyePosition();
        double h = e.getBbHeight();
        Vec3 t = new Vec3(e.getX(), Mth.clamp(eye.y, e.getY() + 0.15 * h, e.getY() + 0.9 * h), e.getZ()).subtract(eye);
        float yaw = (float) (Math.toDegrees(Math.atan2(t.z, t.x)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(t.y, Math.sqrt(t.x * t.x + t.z * t.z)));
        return new float[] {yaw, Mth.clamp(pitch, -90f, 90f)};
    }

    static boolean rayHits(Player p, LivingEntity e, float yaw, float pitch, double range) {
        double yr = Math.toRadians(yaw), pr = Math.toRadians(pitch);
        Vec3 look = new Vec3(-Math.sin(yr) * Math.cos(pr), -Math.sin(pr), Math.cos(yr) * Math.cos(pr));
        Vec3 eye = p.getEyePosition();
        AABB box = e.getBoundingBox().inflate(0.05);
        return box.contains(eye) || box.clip(eye, eye.add(look.scale(range + 0.3))).isPresent();
    }

    /** Rounds a rotation step to the mouse sensitivity grid, so it looks like a real mouse movement. */
    static float gcdFix(Minecraft mc, float prev, float next) {
        double f = mc.options.sensitivity().get() * 0.6 + 0.2;
        double gcd = f * f * f * 8.0 * 0.15;
        return (float) (prev + Math.round((next - prev) / gcd) * gcd);
    }

    static void setReach(Minecraft mc, double v) {
        if (mc.player == null) return;
        AttributeInstance a = mc.player.getAttribute(Attributes.ENTITY_INTERACTION_RANGE);
        if (a != null) a.setBaseValue(v);
    }

    // =====================================================================
    //  Registration
    // =====================================================================
    static void register() {
        combat();
        movement();
        player();
        render();
        hud();
        visual();
        perf();
        Modules2.register();
        ServerHelper.register();
        AuctionHelper.register();
    }

    // ------------------------------------------------------------------ COMBAT
    static void combat() {
        add(new Mod("KillAura", Cat.COMBAT)
            .with(new Num("Range", 2.5, 6, 3.0, 0.1), new Num("Aim range", 3, 8, 4.5, 0.1),
                new Bool("Players", true), new Bool("Mobs", true), new Bool("Animals", false),
                new Bool("Invisible", true), new Bool("Teams", true),
                new Num("Sort", 0, 2, 0, 1), new Num("FOV", 30, 360, 360, 10), new Bool("Walls", false),
                new Bool("Sticky", true), new Num("Rotation", 0, 3, 1, 1), new Num("Rotate speed", 5, 90, 35, 5),
                new Num("Cooldown", 0.5, 1.0, 0.93, 0.01), new Num("Random delay", 0, 3, 1, 1),
                new Bool("Only crits", false), new Num("Crit wait", 0, 30, 12, 1))
            .tick((mc, m) -> {
                Player p = mc.player;
                if (mc.gameMode == null) { Hooks.silent = false; return; }
                double atk = m.n("Range"), aim = Math.max(atk, m.n("Aim range"));
                int sort = (int) m.n("Sort");
                double fov = m.n("FOV");

                LivingEntity cur = auraTarget;
                if (cur != null && !(m.b("Sticky") && auraOk(mc, m, cur, aim, fov))) cur = null;
                if (cur == null) {
                    double bestV = Double.MAX_VALUE;
                    for (Entity e : mc.level.entitiesForRendering()) {
                        if (!validTarget(mc, m, e)) continue;
                        LivingEntity le = (LivingEntity) e;
                        if (!auraOk(mc, m, le, aim, fov)) continue;
                        double v = sort == 1 ? le.getHealth()
                            : sort == 2 ? Math.abs(Mth.wrapDegrees(aimAngles(p, le)[0] - p.getYRot())) : p.distanceTo(le);
                        if (v < bestV) { bestV = v; cur = le; }
                    }
                }
                if (cur != auraTarget) { auraTarget = cur; auraAim = 0; Hooks.silent = false; }
                if (cur == null) { Hooks.silent = false; auraReady = 0; auraDelay = -1; return; }

                // rotation: 0 off, 1 smooth (camera), 2 snap (camera), 3 silent (only the packets)
                int mode = (int) m.n("Rotation");
                float useYaw = p.getYRot(), usePitch = p.getXRot();
                if (mode > 0) {
                    float[] ang = aimAngles(p, cur);
                    float baseYaw = Hooks.silent ? Hooks.sYaw : p.getYRot();
                    float basePitch = Hooks.silent ? Hooks.sPitch : p.getXRot();
                    float dy = Mth.wrapDegrees(ang[0] - baseYaw), dp = ang[1] - basePitch;
                    float ny, np;
                    if (mode == 2) {
                        ny = baseYaw + dy;
                        np = basePitch + dp;
                    } else {
                        float sp = (float) m.n("Rotate speed") * (0.85f + p.getRandom().nextFloat() * 0.3f);
                        ny = baseYaw + Mth.clamp(dy * 0.55f, -sp, sp);
                        np = basePitch + Mth.clamp(dp * 0.55f, -sp * 0.6f, sp * 0.6f);
                    }
                    ny = gcdFix(mc, baseYaw, ny);
                    np = Mth.clamp(gcdFix(mc, basePitch, np), -90f, 90f);
                    if (mode == 3) {
                        Hooks.sYaw = ny;
                        Hooks.sPitch = np;
                        Hooks.silent = true;
                    } else {
                        p.setYRot(ny);
                        p.setXRot(np);
                        Hooks.silent = false;
                    }
                    useYaw = ny;
                    usePitch = np;
                } else {
                    Hooks.silent = false;
                }

                // the hit only counts when the ray from the (server-side) rotation really crosses the hitbox
                boolean aimed = mode == 0 || rayHits(p, cur, useYaw, usePitch, atk);
                auraAim = aimed ? auraAim + 1 : 0;
                double dist = Math.sqrt(cur.getBoundingBox().distanceToSqr(p.getEyePosition()));

                if (p.getAttackStrengthScale(0.5f) < m.n("Cooldown")) { auraReady = 0; auraDelay = -1; return; }
                auraReady++;
                if (auraDelay < 0) auraDelay = (int) (p.getRandom().nextFloat() * (m.n("Random delay") + 1));
                if (auraDelay > 0) { auraDelay--; return; }
                if (dist > atk || !aimed) return;
                if (mode > 0 && auraAim < 2) return;   // the rotation packet must reach the server first
                if (m.b("Only crits")) {
                    boolean crit = p.fallDistance > 0f && !p.onGround() && !p.onClimbable() && !p.isInWater() && !p.isPassenger();
                    if (!crit && auraReady < (int) m.n("Crit wait")) return;
                }
                mc.gameMode.attack(p, cur);
                p.swing(InteractionHand.MAIN_HAND);
                auraDelay = -1;
            })
            .off((mc, m) -> { Hooks.silent = false; auraTarget = null; auraAim = 0; auraReady = 0; auraDelay = -1; }));

        add(new Mod("TriggerBot", Cat.COMBAT)
            .with(new Bool("Players", true), new Bool("Mobs", true), new Bool("Animals", false),
                new Bool("Invisible", true), new Bool("Teams", true))
            .tick((mc, m) -> {
                Player p = mc.player;
                Entity t = mc.crosshairPickEntity;
                if (mc.gameMode == null || t == null || !validTarget(mc, m, t)) return;
                if (p.getAttackStrengthScale(0.5f) >= 1f) {
                    mc.gameMode.attack(p, t);
                    p.swing(InteractionHand.MAIN_HAND);
                }
            }));

        add(new Mod("AutoTotem", Cat.COMBAT)
            .with(new Num("Health", 1, 36, 36, 1), new Num("Delay", 0, 10, 0, 1))
            .tick((mc, m) -> {
                Player p = mc.player;
                if (mc.gameMode == null || ticks % ((int) m.n("Delay") + 1) != 0) return;
                if (p.getHealth() + p.getAbsorptionAmount() > m.n("Health")) return;
                if (p.getOffhandItem().is(Items.TOTEM_OF_UNDYING)) return;
                AbstractContainerMenu menu = p.inventoryMenu;
                for (int i = 9; i <= 44; i++) {
                    if (menu.getSlot(i).getItem().is(Items.TOTEM_OF_UNDYING)) {
                        mc.gameMode.handleInventoryMouseClick(menu.containerId, i, 40, ClickType.SWAP, p);
                        break;
                    }
                }
            }));

        add(new Mod("AutoGap", Cat.COMBAT)
            .with(new Num("Health", 2, 19, 10, 1))
            .tick((mc, m) -> {
                Player p = mc.player;
                if (gapEating) {
                    // keep the use key held until the apple is completely eaten
                    gapTimeout++;
                    mc.options.keyUse.setDown(true);
                    boolean done = (gapTimeout > 5 && !p.isUsingItem()) || gapTimeout > 70;
                    if (done) {
                        mc.options.keyUse.setDown(false);
                        if (gapPrev >= 0) p.getInventory().selected = gapPrev;
                        gapPrev = -1;
                        gapEating = false;
                        gapCd = 4;
                    }
                    return;
                }
                if (gapCd > 0) { gapCd--; return; }
                if (p.getHealth() > m.n("Health")) return;
                int s = findHotbar(p, is -> is.is(Items.ENCHANTED_GOLDEN_APPLE) || is.is(Items.GOLDEN_APPLE));
                if (s < 0) return;
                gapPrev = p.getInventory().selected;
                p.getInventory().selected = s;
                gapEating = true;
                gapTimeout = 0;
                mc.options.keyUse.setDown(true);
            })
            .off((mc, m) -> {
                if (mc.player != null && (gapEating || gapPrev >= 0)) {
                    mc.options.keyUse.setDown(false);
                    if (gapPrev >= 0) mc.player.getInventory().selected = gapPrev;
                }
                gapPrev = -1;
                gapEating = false;
            }));

        add(new Mod("AutoArmor", Cat.COMBAT).tick((mc, m) -> {
            Player p = mc.player;
            if (mc.gameMode == null || ticks % 4 != 0) return;
            EquipmentSlot[] order = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
            AbstractContainerMenu menu = p.inventoryMenu;
            for (EquipmentSlot es : order) {
                if (!p.getItemBySlot(es).isEmpty()) continue;
                for (int i = 9; i <= 44; i++) {
                    ItemStack st = menu.getSlot(i).getItem();
                    if (st.isEmpty() || st.is(Items.ELYTRA) || !st.has(DataComponents.ATTRIBUTE_MODIFIERS)) continue;
                    var eq = st.get(DataComponents.EQUIPPABLE);
                    if (eq != null && eq.slot() == es) {
                        mc.gameMode.handleInventoryMouseClick(menu.containerId, i, 0, ClickType.QUICK_MOVE, p);
                        return;
                    }
                }
            }
        }));

        add(new Mod("CrystalBreaker", Cat.COMBAT)
            .with(new Num("Range", 2, 6, 4.5, 0.1), new Num("Delay", 0, 10, 1, 1))
            .tick((mc, m) -> {
                Player p = mc.player;
                if (mc.gameMode == null || ticks % ((int) m.n("Delay") + 1) != 0) return;
                for (Entity e : mc.level.entitiesForRendering()) {
                    if (e.getType() == EntityType.END_CRYSTAL && p.distanceTo(e) <= m.n("Range")) {
                        mc.gameMode.attack(p, e);
                        p.swing(InteractionHand.MAIN_HAND);
                        return;
                    }
                }
            }));

        add(new Mod("AimAssist", Cat.COMBAT)
            .with(new Num("Range", 2, 8, 5, 0.1), new Num("Speed", 1, 40, 10, 1), new Num("FOV", 20, 360, 110, 5),
                new Bool("Players", true), new Bool("Mobs", false), new Bool("Animals", false),
                new Bool("Invisible", true), new Bool("Teams", true), new Bool("Only attacking", true))
            .tick((mc, m) -> {
                Player p = mc.player;
                if (mc.screen != null) return;
                if (m.b("Only attacking") && !mc.options.keyAttack.isDown()) return;
                Vec3 eye = p.getEyePosition();
                float bestYaw = 0, bestPitch = 0, bestAng = Float.MAX_VALUE;
                boolean found = false;
                for (Entity e : mc.level.entitiesForRendering()) {
                    if (!validTarget(mc, m, e) || p.distanceTo(e) > m.n("Range")) continue;
                    Vec3 t = e.position().add(0, e.getBbHeight() * 0.6, 0).subtract(eye);
                    float yawT = (float) (Math.toDegrees(Math.atan2(t.z, t.x)) - 90.0);
                    float pitchT = (float) -Math.toDegrees(Math.atan2(t.y, Math.sqrt(t.x * t.x + t.z * t.z)));
                    float dy = Mth.wrapDegrees(yawT - p.getYRot());
                    float dp = pitchT - p.getXRot();
                    if (Math.abs(dy) > m.n("FOV") / 2.0) continue;
                    float ang = Math.abs(dy) + Math.abs(dp);
                    if (ang < bestAng) { bestAng = ang; bestYaw = dy; bestPitch = dp; found = true; }
                }
                if (!found) return;
                float sp = (float) m.n("Speed");
                p.setYRot(p.getYRot() + Mth.clamp(bestYaw, -sp, sp));
                p.setXRot(Mth.clamp(p.getXRot() + Mth.clamp(bestPitch, -sp, sp), -90f, 90f));
            }));

        add(new Mod("AutoClicker", Cat.COMBAT)
            .with(new Num("CPS", 1, 20, 10, 1), new Bool("Players", true), new Bool("Mobs", true),
                new Bool("Animals", true), new Bool("Invisible", true), new Bool("Teams", false))
            .tick((mc, m) -> {
                Player p = mc.player;
                Entity t = mc.crosshairPickEntity;
                if (mc.gameMode == null || mc.screen != null || !mc.options.keyAttack.isDown()) return;
                if (t == null || !validTarget(mc, m, t)) return;
                m.acc += m.n("CPS") / 20.0;
                if (m.acc >= 1) {
                    m.acc -= 1;
                    mc.gameMode.attack(p, t);
                    p.swing(InteractionHand.MAIN_HAND);
                }
            }));

        add(new Mod("WTap", Cat.COMBAT));        // logic in the attack callback
        add(new Mod("AutoWeapon", Cat.COMBAT));  // logic in the attack callback

        add(new Mod("Reach", Cat.COMBAT)
            .with(new Num("Range", 3, 6, 4.5, 0.1))
            .tick((mc, m) -> setReach(mc, m.n("Range")))
            .off((mc, m) -> setReach(mc, 3.0)));

        add(new Mod("Velocity", Cat.COMBAT)
            .with(new Num("Horizontal", 0, 100, 0, 5), new Num("Vertical", 0, 100, 0, 5))
            .tick((mc, m) -> {
                Player p = mc.player;
                if (p.hurtTime == 9) {
                    Vec3 v = p.getDeltaMovement();
                    double h = m.n("Horizontal") / 100.0, vv = m.n("Vertical") / 100.0;
                    p.setDeltaMovement(v.x * h, v.y * vv, v.z * h);
                }
            }));

        add(new Mod("TrueSight", Cat.COMBAT).tick((mc, m) -> {
            for (Player pl : mc.level.players()) if (pl != mc.player && pl.isInvisible()) pl.setInvisible(false);
        }));
    }

    // ---------------------------------------------------------------- MOVEMENT
    static void movement() {
        add(new Mod("Sprint", Cat.MOVEMENT).tick((mc, m) -> {
            Player p = mc.player;
            if (mc.options.keyUp.isDown() && !p.horizontalCollision && !p.isUsingItem()) p.setSprinting(true);
        }));

        add(new Mod("Speed", Cat.MOVEMENT).with(new Num("Speed", 0.1, 1.0, 0.32, 0.01)).tick((mc, m) -> {
            Player p = mc.player;
            if (!p.onGround()) return;
            Vec3 d = moveDir(mc);
            if (d.lengthSqr() == 0) return;
            double s = m.n("Speed");
            p.setDeltaMovement(d.x * s, p.getDeltaMovement().y, d.z * s);
        }));

        add(new Mod("Bhop", Cat.MOVEMENT).with(new Num("Speed", 0.1, 1.0, 0.35, 0.01)).tick((mc, m) -> {
            Player p = mc.player;
            Vec3 d = moveDir(mc);
            if (d.lengthSqr() == 0 || p.isInWater() || p.isInLava()) return;
            if (p.onGround()) jump(p, 0.42);
            double s = m.n("Speed");
            p.setDeltaMovement(d.x * s, p.getDeltaMovement().y, d.z * s);
        }));

        add(new Mod("Fly", Cat.MOVEMENT).with(new Num("Speed", 0.1, 3.0, 0.6, 0.1)).tick((mc, m) -> {
            Player p = mc.player;
            double s = m.n("Speed");
            Vec3 d = moveDir(mc);
            double y = 0;
            if (mc.options.keyJump.isDown()) y += s;
            if (mc.options.keyShift.isDown()) y -= s;
            p.setDeltaMovement(d.x * s, y, d.z * s);
            p.fallDistance = 0;
        }));

        add(new Mod("ElytraFly", Cat.MOVEMENT).with(new Num("Speed", 0.5, 4.0, 1.6, 0.1)).tick((mc, m) -> {
            Player p = mc.player;
            if (!p.isFallFlying()) return;
            if (mc.options.keyUp.isDown()) p.setDeltaMovement(p.getLookAngle().scale(m.n("Speed")));
            else if (mc.options.keyShift.isDown()) p.setDeltaMovement(Vec3.ZERO);
        }));

        add(new Mod("HighJump", Cat.MOVEMENT).with(new Num("Height", 0.42, 2.0, 0.8, 0.02)).tick((mc, m) -> {
            Player p = mc.player;
            if (p.onGround() && mc.options.keyJump.isDown()) jump(p, m.n("Height"));
        }));

        add(new Mod("Step", Cat.MOVEMENT).with(new Num("Height", 1, 3, 1.5, 0.5)).tick((mc, m) -> {
            AttributeInstance attr = mc.player.getAttribute(Attributes.STEP_HEIGHT);
            if (attr != null) attr.setBaseValue(m.n("Height"));
        }).off((mc, m) -> {
            if (mc.player == null) return;
            AttributeInstance attr = mc.player.getAttribute(Attributes.STEP_HEIGHT);
            if (attr != null) attr.setBaseValue(0.6);
        }));

        add(new Mod("Spider", Cat.MOVEMENT).tick((mc, m) -> {
            Player p = mc.player;
            if (p.horizontalCollision) {
                Vec3 v = p.getDeltaMovement();
                p.setDeltaMovement(v.x, 0.22, v.z);
            }
        }));

        add(new Mod("Glide", Cat.MOVEMENT).with(new Num("Fall speed", 0.02, 0.3, 0.06, 0.01)).tick((mc, m) -> {
            Player p = mc.player;
            Vec3 v = p.getDeltaMovement();
            double fs = m.n("Fall speed");
            if (!p.onGround() && !p.isFallFlying() && !p.isInWater() && v.y < -fs) {
                p.setDeltaMovement(v.x, -fs, v.z);
                p.fallDistance = 0;
            }
        }));

        // Jesus: logic is in LivingEntityMixin (canStandOnFluid), Shift sinks you
        add(new Mod("Jesus", Cat.MOVEMENT).with(new Bool("Lava", false)));

        add(new Mod("NoFall", Cat.MOVEMENT).with(new Num("Distance", 0.5, 8, 1.5, 0.5)).tick((mc, m) -> {
            Player p = mc.player;
            if (mc.getConnection() == null || p.onGround() || p.isFallFlying() || p.getAbilities().flying
                || p.isInWater() || p.isInLava() || p.isPassenger()) return;
            if (p.fallDistance > m.n("Distance") && p.getDeltaMovement().y < 0) {
                mc.getConnection().send(new ServerboundMovePlayerPacket.StatusOnly(true, p.horizontalCollision));
                p.fallDistance = 0;
            }
        }));

        add(new Mod("AutoJump", Cat.MOVEMENT).tick((mc, m) -> {
            Player p = mc.player;
            if (p.onGround() && p.horizontalCollision && moveDir(mc).lengthSqr() > 0) jump(p, 0.42);
        }));

        add(new Mod("AutoWalk", Cat.MOVEMENT)
            .tick((mc, m) -> mc.options.keyUp.setDown(true))
            .off((mc, m) -> mc.options.keyUp.setDown(false)));

        add(new Mod("Sneak", Cat.MOVEMENT)
            .tick((mc, m) -> mc.options.keyShift.setDown(true))
            .off((mc, m) -> mc.options.keyShift.setDown(false)));

        add(new Mod("Scaffold", Cat.MOVEMENT)
            .with(new Bool("Switch", true))
            .tick((mc, m) -> {
                var p = mc.player;
                if (mc.gameMode == null) return;
                BlockPos pos = BlockPos.containing(p.getX(), Math.floor(p.getY()) - 1, p.getZ());
                var here = mc.level.getBlockState(pos);
                if (!(here.isAir() || here.canBeReplaced())) return;
                int cur = p.getInventory().selected;
                if (!(p.getInventory().getItem(cur).getItem() instanceof BlockItem)) {
                    if (!m.b("Switch")) return;
                    int s = findHotbar(p, is -> is.getItem() instanceof BlockItem);
                    if (s < 0) return;
                    if (scafPrev < 0) scafPrev = cur;
                    p.getInventory().selected = s;
                }
                for (Direction d : Direction.values()) {
                    BlockPos n = pos.relative(d);
                    var ns = mc.level.getBlockState(n);
                    if (ns.isAir() || ns.canBeReplaced() || !ns.getFluidState().isEmpty()) continue;
                    Direction face = d.getOpposite();
                    Vec3 hit = Vec3.atCenterOf(n).add(face.getStepX() * 0.5, face.getStepY() * 0.5, face.getStepZ() * 0.5);
                    mc.gameMode.useItemOn(p, InteractionHand.MAIN_HAND, new BlockHitResult(hit, face, n, false));
                    p.swing(InteractionHand.MAIN_HAND);
                    break;
                }
            })
            .off((mc, m) -> {
                if (scafPrev >= 0 && mc.player != null) mc.player.getInventory().selected = scafPrev;
                scafPrev = -1;
            }));

        add(new Mod("Parkour", Cat.MOVEMENT).tick((mc, m) -> {
            Player p = mc.player;
            if (p.onGround() && !p.isShiftKeyDown() && edgeAhead(mc, 0.35)) jump(p, 0.42);
        }));

        add(new Mod("Eagle", Cat.MOVEMENT)
            .tick((mc, m) -> {
                Player p = mc.player;
                boolean edge = p.onGround() && edgeAhead(mc, 0.3);
                if (edge) { mc.options.keyShift.setDown(true); eagling = true; }
                else if (eagling) { mc.options.keyShift.setDown(false); eagling = false; }
            })
            .off((mc, m) -> { if (eagling) mc.options.keyShift.setDown(false); eagling = false; }));
    }

    // ------------------------------------------------------------------ PLAYER
    static void player() {
        add(new Mod("AutoRespawn", Cat.PLAYER).tick((mc, m) -> {
            if (mc.screen instanceof DeathScreen) mc.player.respawn();
        }));

        add(new Mod("AntiAFK", Cat.PLAYER).tick((mc, m) -> {
            Player p = mc.player;
            if (ticks % 200 == 0) p.setYRot(p.getYRot() + 8f);
            if (ticks % 200 == 100) p.setYRot(p.getYRot() - 8f);
            if (ticks % 400 == 0 && p.onGround()) jump(p, 0.42);
        }));

        add(new Mod("AutoEat", Cat.PLAYER)
            .with(new Num("Hunger", 1, 19, 14, 1))
            .tick((mc, m) -> {
                Player p = mc.player;
                if (p.getFoodData().getFoodLevel() <= m.n("Hunger")) {
                    if (eatPrev < 0) {
                        int s = findHotbar(p, is -> is.get(DataComponents.FOOD) != null && !badFood(is));
                        if (s < 0) return;
                        eatPrev = p.getInventory().selected;
                        p.getInventory().selected = s;
                    }
                    mc.options.keyUse.setDown(true);
                } else if (eatPrev >= 0) {
                    mc.options.keyUse.setDown(false);
                    p.getInventory().selected = eatPrev;
                    eatPrev = -1;
                }
            })
            .off((mc, m) -> {
                if (eatPrev >= 0 && mc.player != null) {
                    mc.options.keyUse.setDown(false);
                    mc.player.getInventory().selected = eatPrev;
                }
                eatPrev = -1;
            }));

        add(new Mod("AutoTool", Cat.PLAYER)
            .tick((mc, m) -> {
                Player p = mc.player;
                if (mc.screen == null && mc.options.keyAttack.isDown()
                    && mc.hitResult instanceof BlockHitResult bhr && bhr.getType() == HitResult.Type.BLOCK) {
                    var state = mc.level.getBlockState(bhr.getBlockPos());
                    int best = -1;
                    float bs = p.getInventory().getItem(p.getInventory().selected).getDestroySpeed(state);
                    for (int i = 0; i < 9; i++) {
                        float sp = p.getInventory().getItem(i).getDestroySpeed(state);
                        if (sp > bs + 0.01f) { bs = sp; best = i; }
                    }
                    if (best >= 0) {
                        if (toolPrev < 0) toolPrev = p.getInventory().selected;
                        p.getInventory().selected = best;
                    }
                } else if (toolPrev >= 0) {
                    p.getInventory().selected = toolPrev;
                    toolPrev = -1;
                }
            })
            .off((mc, m) -> {
                if (toolPrev >= 0 && mc.player != null) mc.player.getInventory().selected = toolPrev;
                toolPrev = -1;
            }));

        add(new Mod("ChestStealer", Cat.PLAYER)
            .with(new Num("Items per tick", 1, 9, 2, 1))
            .tick((mc, m) -> {
                if (mc.gameMode == null || !(mc.screen instanceof ContainerScreen cs)) return;
                var menu = cs.getMenu();
                int rows = menu.getRowCount(), moved = 0, cap = (int) m.n("Items per tick");
                for (int i = 0; i < rows * 9 && moved < cap; i++) {
                    if (menu.getSlot(i).getItem().isEmpty()) continue;
                    mc.gameMode.handleInventoryMouseClick(menu.containerId, i, 0, ClickType.QUICK_MOVE, mc.player);
                    moved++;
                }
            }));

        add(new Mod("MiddleClickPearl", Cat.PLAYER).tick((mc, m) -> {
            if (mc.gameMode == null) return;
            boolean mid = mc.screen == null
                && GLFW.glfwGetMouseButton(mc.getWindow().getWindow(), GLFW.GLFW_MOUSE_BUTTON_MIDDLE) == GLFW.GLFW_PRESS;
            if (mid && !pearlMidDown) ServerHelper.use(mc, st -> st.is(Items.ENDER_PEARL), "Жемчуг", true);   // same code path as UsePearl
            pearlMidDown = mid;
        }));
    }

    // ------------------------------------------------------------------ RENDER
    static void render() {
        add(new Mod("Fullbright", Cat.RENDER).tick((mc, m) ->
            mc.player.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 400, 0, false, false, false))
        ).off((mc, m) -> {
            if (mc.player != null) mc.player.removeEffect(MobEffects.NIGHT_VISION);
        }));

        add(new Mod("ESP", Cat.RENDER).with(new Bool("Players", true), new Bool("Mobs", true),
            new Bool("Animals", false), new Bool("Crystals", true), new Bool("Fill", true),
            new Bool("Health color", true), new Num("Range", 16, 256, 128, 8)));

        add(new Mod("Tracers", Cat.RENDER).with(new Bool("Players", true), new Bool("Mobs", false),
            new Bool("Animals", false), new Num("Range", 16, 256, 128, 8)));

        add(new Mod("StorageESP", Cat.RENDER).with(
            new Bool("Chests", true), new Bool("Shulkers", true), new Bool("Barrels", true),
            new Bool("Ender", true), new Bool("Hoppers", false), new Bool("Furnaces", false),
            new Bool("Dispensers", false), new Bool("Spawners", true),
            new Bool("Labels", true), new Bool("Distance", true), new Bool("Fill", true),
            new Num("Label size", 0.5, 3, 1, 0.1), new Num("Range", 16, 128, 64, 8)).def());

        add(new Mod("Nametags", Cat.RENDER).with(new Bool("Health", true), new Bool("Distance", true),
            new Num("Size", 0.5, 3, 1, 0.1), new Num("Range", 8, 128, 64, 8)));

        add(new Mod("ItemESP", Cat.RENDER).with(new Bool("Labels", true), new Bool("Fill", true),
            new Num("Range", 8, 96, 48, 4)));

        add(new Mod("OreESP", Cat.RENDER).with(
            new Bool("Diamond", true), new Bool("Ancient Debris", true), new Bool("Emerald", true),
            new Bool("Gold", true), new Bool("Iron", false), new Bool("Copper", false),
            new Bool("Lapis", false), new Bool("Redstone", false), new Bool("Coal", false),
            new Bool("Labels", true), new Bool("Fill", true), new Num("Range", 8, 32, 16, 1)));

        add(new Mod("Trajectories", Cat.RENDER));
        add(new Mod("Breadcrumbs", Cat.RENDER).with(new Num("Length", 50, 600, 200, 10)));
        add(new Mod("ChunkBorders", Cat.RENDER));
        add(new Mod("BlockHighlight", Cat.RENDER).with(new Bool("Fill", true), new Num("Fill opacity", 0.01, 0.4, 0.06, 0.01),
            new Num("Line opacity", 0.1, 1.0, 0.7, 0.05)));
        add(new Mod("BlockESP", Cat.RENDER).with(new Bool("Fill", true), new Bool("Label", true), new Bool("Pulse", true),
            new Num("Range", 4, 20, 6, 1)).def()
            .d("Подсвечивает блок, на который смотришь: пульсирующая рамка, залитая грань и подпись с названием блока и расстоянием."));
        add(new Mod("DamageIndicator", Cat.RENDER).with(new Num("Range", 8, 64, 32, 4))
            .d("Над существами всплывают числа урона и лечения, когда у них меняется здоровье."));

        add(new Mod("Hitboxes", Cat.RENDER)
            .tick((mc, m) -> mc.getEntityRenderDispatcher().setRenderHitBoxes(true))
            .off((mc, m) -> mc.getEntityRenderDispatcher().setRenderHitBoxes(false)));
    }

    // --------------------------------------------------------------------- HUD
    static void hud() {
        add(new Mod("Watermark", Cat.HUD).def());
        add(new Mod("ModuleList", Cat.HUD));
        add(new Mod("Notifications", Cat.HUD).def());
        add(new Mod("TargetHUD", Cat.HUD).def());
        add(new Mod("ComboCounter", Cat.HUD).def());
        add(new Mod("Coords", Cat.HUD));
        add(new Mod("Radar", Cat.HUD).with(new Num("Range", 16, 128, 48, 4), new Num("Size", 60, 140, 84, 4),
            new Bool("Players", true), new Bool("Mobs", true), new Bool("Animals", false)));
        add(new Mod("ArmorStatus", Cat.HUD).with(new Bool("Percent", true), new Bool("Target armor", true)).def()
            .d("Броня справа от хотбара: иконки, полоска и проценты прочности. Ещё показывает броню цели, которую бьёшь."));
        add(new Mod("Keystrokes", Cat.HUD));
        add(new Mod("PotionHUD", Cat.HUD));
        add(new Mod("Info", Cat.HUD));
    }

    // ------------------------------------------------------------------ VISUAL
    static void visual() {
        add(new Mod("Trail", Cat.VISUAL).tick((mc, m) -> {
            Player p = mc.player;
            if (p.getDeltaMovement().horizontalDistanceSqr() < 0.0004) return;
            for (int i = 0; i < 2; i++) {
                mc.level.addParticle(ParticleTypes.END_ROD,
                    p.getX() + (Math.random() - 0.5) * 0.4, p.getY() + 0.1, p.getZ() + (Math.random() - 0.5) * 0.4,
                    0, 0.02, 0);
            }
        }));

        add(new Mod("Halo", Cat.VISUAL).tick((mc, m) -> {
            Player p = mc.player;
            double base = ticks * 0.35;
            for (int i = 0; i < 3; i++) {
                double a = base + i * (Math.PI * 2 / 3);
                mc.level.addParticle(ParticleTypes.END_ROD,
                    p.getX() + Math.cos(a) * 0.4, p.getY() + p.getBbHeight() + 0.25, p.getZ() + Math.sin(a) * 0.4,
                    0, 0, 0);
            }
        }));

        add(new Mod("Wings", Cat.VISUAL).tick((mc, m) -> {
            Player p = mc.player;
            double yaw = Math.toRadians(p.yBodyRot);
            double bx = Math.sin(yaw), bz = -Math.cos(yaw);
            double rx = -Math.cos(yaw), rz = -Math.sin(yaw);
            double flap = Math.sin(ticks * 0.15) * 0.06;
            for (int side = -1; side <= 1; side += 2) {
                for (int i = 1; i <= 5; i++) {
                    double dist = 0.12 + i * 0.13;
                    double y = p.getY() + 1.35 - i * 0.07 + flap * i;
                    double back = 0.25 + i * 0.03;
                    mc.level.addParticle(ParticleTypes.END_ROD,
                        p.getX() + bx * back + rx * side * dist, y, p.getZ() + bz * back + rz * side * dist,
                        0, 0, 0);
                }
            }
        }));

        add(new Mod("HitEffects", Cat.VISUAL).def());
        add(new Mod("CritParticles", Cat.VISUAL));

        add(new Mod("Aura", Cat.VISUAL).tick((mc, m) -> {
            Player p = mc.player;
            double base = ticks * 0.22;
            for (int i = 0; i < 4; i++) {
                double a = base + i * (Math.PI / 2);
                mc.level.addParticle(ParticleTypes.SOUL_FIRE_FLAME,
                    p.getX() + Math.cos(a) * 0.9, p.getY() + 0.15, p.getZ() + Math.sin(a) * 0.9, 0, 0.01, 0);
            }
        }));

        add(new Mod("Snow", Cat.VISUAL).with(new Num("Amount", 1, 20, 6, 1)).tick((mc, m) -> {
            Player p = mc.player;
            for (int i = 0; i < (int) m.n("Amount"); i++) {
                mc.level.addParticle(ParticleTypes.SNOWFLAKE,
                    p.getX() + (Math.random() - 0.5) * 16, p.getY() + 2 + Math.random() * 5, p.getZ() + (Math.random() - 0.5) * 16,
                    0, -0.05, 0);
            }
        }));

        add(new Mod("Fireflies", Cat.VISUAL).tick((mc, m) -> {
            Player p = mc.player;
            if (ticks % 2 != 0) return;
            mc.level.addParticle(ParticleTypes.GLOW,
                p.getX() + (Math.random() - 0.5) * 12, p.getY() + Math.random() * 3, p.getZ() + (Math.random() - 0.5) * 12,
                (Math.random() - 0.5) * 0.02, (Math.random() - 0.5) * 0.02, (Math.random() - 0.5) * 0.02);
        }));

        add(new Mod("ShaderHands", Cat.VISUAL).with(new Num("Intensity", 0.1, 1.0, 0.6, 0.05),
            new Num("Speed", 0.2, 4.0, 1.0, 0.1), new Num("Size", 0.5, 2.0, 1.0, 0.1),
            new Bool("Rainbow", true), new Bool("Shimmer", true), new Bool("Both hands", true),
            new Num("Style", 0, 2, 0, 1), new Num("Layers", 6, 20, 12, 1)));
        add(new Mod("Sparkle", Cat.VISUAL).tick((mc, m) -> {
            Player p = mc.player;
            mc.level.addParticle(ParticleTypes.FIREWORK,
                p.getX() + (Math.random() - 0.5) * 1.2, p.getY() + Math.random() * 2, p.getZ() + (Math.random() - 0.5) * 1.2,
                0, 0, 0);
        }));

        add(new Mod("FlameTrail", Cat.VISUAL).tick((mc, m) -> {
            Player p = mc.player;
            if (p.getDeltaMovement().horizontalDistanceSqr() < 0.0004) return;
            mc.level.addParticle(ParticleTypes.FLAME, p.getX(), p.getY() + 0.05, p.getZ(), 0, 0.01, 0);
        }));

        add(new Mod("PortalSwirl", Cat.VISUAL).tick((mc, m) -> {
            Player p = mc.player;
            for (int i = 0; i < 3; i++) {
                double a = ticks * 0.3 + i * 2.09;
                mc.level.addParticle(ParticleTypes.PORTAL,
                    p.getX() + Math.cos(a) * 0.7, p.getY() + 1.0 + Math.sin(ticks * 0.1) * 0.6, p.getZ() + Math.sin(a) * 0.7,
                    0, 0, 0);
            }
        }));

        add(new Mod("HeartTrail", Cat.VISUAL).tick((mc, m) -> {
            Player p = mc.player;
            if (ticks % 6 == 0 && p.getDeltaMovement().horizontalDistanceSqr() > 0.0004)
                mc.level.addParticle(ParticleTypes.HEART, p.getX(), p.getY() + 0.3, p.getZ(), 0, 0.05, 0);
        }));

        add(new Mod("Tornado", Cat.VISUAL).tick((mc, m) -> {
            Player p = mc.player;
            for (int i = 0; i < 4; i++) {
                double h = (ticks * 0.08 + i * 0.6) % 2.4;
                double r = 0.3 + h * 0.35, a = ticks * 0.5 + i * 2.1 + h * 3;
                mc.level.addParticle(ParticleTypes.CLOUD,
                    p.getX() + Math.cos(a) * r, p.getY() + h, p.getZ() + Math.sin(a) * r, 0, 0, 0);
            }
        }));

        theme = add(new Mod("Theme", Cat.VISUAL).with(new Num("Cycle sec", 1, 20, 6, 0.5),
            new Num("Saturation", 0.1, 1, 0.7, 0.05), new Bool("Static", true), new Num("Hue", 0, 360, 145, 5)));
    }

    // ------------------------------------------------------------- PERFORMANCE
    static void perf() {
        add(new Mod("FastGraphics", Cat.PERF)
            .tick((mc, m) -> force("gfx", mc.options.graphicsMode(), GraphicsStatus.FAST))
            .off((mc, m) -> restore("gfx")));

        add(new Mod("LowParticles", Cat.PERF)
            .tick((mc, m) -> force("part", mc.options.particles(), ParticleStatus.DECREASED))
            .off((mc, m) -> restore("part")));

        add(new Mod("NoClouds", Cat.PERF)
            .tick((mc, m) -> force("cloud", mc.options.cloudStatus(), CloudStatus.OFF))
            .off((mc, m) -> restore("cloud")));

        add(new Mod("NoShadows", Cat.PERF)
            .tick((mc, m) -> force("shadow", mc.options.entityShadows(), false))
            .off((mc, m) -> restore("shadow")));

        add(new Mod("NoAO", Cat.PERF)
            .tick((mc, m) -> force("ao", mc.options.ambientOcclusion(), false))
            .off((mc, m) -> restore("ao")));

        add(new Mod("NoBobbing", Cat.PERF)
            .tick((mc, m) -> force("bob", mc.options.bobView(), false))
            .off((mc, m) -> restore("bob")));

        add(new Mod("NoFovEffects", Cat.PERF)
            .tick((mc, m) -> force("fovfx", mc.options.fovEffectScale(), 0.0))
            .off((mc, m) -> restore("fovfx")));

        add(new Mod("RenderDist", Cat.PERF).with(new Num("Chunks", 2, 32, 8, 1))
            .tick((mc, m) -> force("rd", mc.options.renderDistance(), (int) m.n("Chunks")))
            .off((mc, m) -> restore("rd")));

        add(new Mod("SimDist", Cat.PERF).with(new Num("Chunks", 5, 32, 6, 1))
            .tick((mc, m) -> force("sd", mc.options.simulationDistance(), (int) m.n("Chunks")))
            .off((mc, m) -> restore("sd")));

        add(new Mod("EntityDist", Cat.PERF).with(new Num("Scale", 0.5, 5, 0.75, 0.25))
            .tick((mc, m) -> force("eds", mc.options.entityDistanceScaling(), m.n("Scale")))
            .off((mc, m) -> restore("eds")));

        add(new Mod("UnlockFPS", Cat.PERF)
            .tick((mc, m) -> {
                force("fps", mc.options.framerateLimit(), 260);
                force("vsync", mc.options.enableVsync(), false);
            })
            .off((mc, m) -> { restore("fps"); restore("vsync"); }));

        // Sharper / brighter picture (the heavy part, real 2x rendering, is the RenderScale / QDAA mod in Mods & Packs)
        add(new Mod("Quality", Cat.VISUAL)
            .with(new Bool("Bright", true), new Num("Mipmaps", 0, 4, 4, 1), new Num("Biome blend", 0, 7, 5, 1))
            .tick((mc, m) -> {
                if (m.b("Bright")) force("q_gamma", mc.options.gamma(), 1.0); else restore("q_gamma");
                force("q_mip", mc.options.mipmapLevels(), (int) m.n("Mipmaps"));
                force("q_blend", mc.options.biomeBlendRadius(), (int) m.n("Biome blend"));
            })
            .off((mc, m) -> { restore("q_gamma"); restore("q_mip"); restore("q_blend"); }));

        // One switch for general FPS (see Optimizer.java)
        add(new Mod("Optimize", Cat.PERF).def()
            .with(new Num("Level", 1, 3, 2, 1), new Bool("Adaptive", true), new Num("Target FPS", 40, 240, 90, 10),
                new Num("Min chunks", 4, 16, 8, 1),
                new Num("Block entity range", 16, 128, 48, 8), new Num("Particle range", 8, 64, 24, 4),
                new Num("Background FPS", 5, 60, 15, 5))
            .tick(Optimizer::tick)
            .off((mc, m) -> Optimizer.off()));

        // Crowd mode for warps / arenas with 20-30 players: draws only the nearest players in full.
        add(new Mod("CrowdBoost", Cat.PERF).def()
            .with(new Num("Crowd at", 3, 30, 8, 1), new Num("Max players", 3, 40, 12, 1), new Num("Far range", 16, 128, 56, 4),
                new Bool("Hide far armor", true), new Bool("Hide far held items", true), new Num("Armor range", 8, 64, 24, 2),
                new Bool("Hide far nametags", true), new Num("Name range", 8, 64, 20, 2),
                new Bool("Sound cap", true), new Num("Sounds per tick", 4, 40, 14, 2),
                new Bool("Cull items", true), new Num("Item range", 8, 64, 32, 4),
                new Bool("Particle cap", true), new Num("Particles per tick", 10, 200, 60, 10),
                new Bool("Auto settings", true), new Bool("Lite HUD", true), new Bool("Hide behind walls", true))
            .tick(Hooks::crowdTick)
            .off((mc, m) -> Hooks.crowdOff()));
    }
}
