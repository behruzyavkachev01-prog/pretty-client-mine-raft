package com.pretty.client;

import static com.pretty.client.Modules.*;
import static com.pretty.client.PrettyClient.*;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import org.lwjgl.glfw.GLFW;

/** Second batch of modules (kept apart from Modules.java so both files stay readable). */
final class Modules2 {
    private Modules2() {}

    static boolean airJumpDown;

    static void register() {
        combat();
        movement();
        player();
        render();
        hud();
        perf();
        Modules3.register();
    }

    // ------------------------------------------------------------------ COMBAT
    static void combat() {
        add(new Mod("Criticals", Cat.COMBAT).with(new Bool("Only standing", true), new Bool("Only full charge", true),
            new Num("Cooldown ms", 0, 1000, 350, 50)));            // logic in the attack callback
        add(new Mod("AntiBot", Cat.COMBAT));              // filter in Modules.validTarget
        add(new Mod("HitSounds", Cat.COMBAT).with(new Num("Volume", 0.1, 2.0, 0.8, 0.1)));

        add(new Mod("TargetStrafe", Cat.COMBAT)
            .with(new Num("Range", 2, 6, 3.5, 0.1), new Num("Speed", 0.1, 0.6, 0.26, 0.01))
            .tick((mc, m) -> {
                Player p = mc.player;
                var t = target;
                if (t == null || !t.isAlive() || p.distanceTo(t) > m.n("Range") + 2) return;
                if (moveDir(mc).lengthSqr() == 0) return;
                Vec3 to = t.position().subtract(p.position());
                double len = Math.sqrt(to.x * to.x + to.z * to.z);
                if (len < 0.01) return;
                // move along the tangent around the target and keep the ring distance
                double tx = -to.z / len, tz = to.x / len;
                double radial = (len - m.n("Range")) * 0.5;
                double s = m.n("Speed");
                double vx = tx * s + (to.x / len) * Math.max(-s, Math.min(s, radial));
                double vz = tz * s + (to.z / len) * Math.max(-s, Math.min(s, radial));
                Vec3 v = p.getDeltaMovement();
                p.setDeltaMovement(vx, v.y, vz);
            }));
    }

    // ---------------------------------------------------------------- MOVEMENT
    static void movement() {
        add(new Mod("CreativeFly", Cat.MOVEMENT).with(new Num("Speed", 0.05, 1.0, 0.1, 0.01))
            .tick((mc, m) -> {
                Player p = mc.player;
                p.getAbilities().mayfly = true;
                p.getAbilities().setFlyingSpeed((float) m.n("Speed"));
            })
            .off((mc, m) -> {
                if (mc.player == null || mc.gameMode == null) return;
                mc.player.getAbilities().setFlyingSpeed(0.05f);
                mc.gameMode.getPlayerMode().updatePlayerAbilities(mc.player.getAbilities());
            }));

        add(new Mod("Strafe", Cat.MOVEMENT).with(new Num("Speed", 0.1, 1.0, 0.28, 0.01)).tick((mc, m) -> {
            Player p = mc.player;
            if (p.onGround() || p.isInWater() || p.isInLava()) return;
            Vec3 d = moveDir(mc);
            if (d.lengthSqr() == 0) return;
            Vec3 v = p.getDeltaMovement();
            double s = Math.max(m.n("Speed"), v.horizontalDistance());
            p.setDeltaMovement(d.x * s, v.y, d.z * s);
        }));

        add(new Mod("AirJump", Cat.MOVEMENT).tick((mc, m) -> {
            Player p = mc.player;
            boolean j = mc.options.keyJump.isDown();
            if (j && !airJumpDown && !p.onGround() && !p.isInWater() && !p.isInLava()) jump(p, 0.42);
            airJumpDown = j;
        }));

        add(new Mod("LongJump", Cat.MOVEMENT).with(new Num("Boost", 0.2, 1.5, 0.6, 0.05)).tick((mc, m) -> {
            Player p = mc.player;
            if (!p.onGround() || !mc.options.keyJump.isDown()) return;
            Vec3 d = moveDir(mc);
            if (d.lengthSqr() == 0) return;
            double b = m.n("Boost");
            p.setDeltaMovement(d.x * b, 0.5, d.z * b);
        }));

        add(new Mod("ReverseStep", Cat.MOVEMENT).with(new Num("Height", 1, 4, 2, 0.5)).tick((mc, m) -> {
            Player p = mc.player;
            if (p.onGround() || p.isInWater() || p.isInLava() || p.isFallFlying()) return;
            Vec3 v = p.getDeltaMovement();
            if (v.y >= 0) return;
            if (!mc.level.noCollision(p.getBoundingBox().move(0, -m.n("Height"), 0)))
                p.setDeltaMovement(v.x, -0.9, v.z);
        }));

        add(new Mod("FastLadder", Cat.MOVEMENT).with(new Num("Speed", 0.12, 0.6, 0.3, 0.01)).tick((mc, m) -> {
            Player p = mc.player;
            if (p.onClimbable() && p.horizontalCollision && mc.options.keyUp.isDown()) {
                Vec3 v = p.getDeltaMovement();
                p.setDeltaMovement(v.x, m.n("Speed"), v.z);
            }
        }));

        add(new Mod("Dolphin", Cat.MOVEMENT).with(new Num("Speed", 0.05, 0.6, 0.2, 0.01)).tick((mc, m) -> {
            Player p = mc.player;
            if (!p.isInWater()) return;
            Vec3 d = moveDir(mc);
            if (d.lengthSqr() == 0) return;
            double s = m.n("Speed");
            p.setDeltaMovement(d.x * s, p.getDeltaMovement().y, d.z * s);
        }));

        add(new Mod("AntiVoid", Cat.MOVEMENT).tick((mc, m) -> {
            Player p = mc.player;
            if (!p.onGround() && p.getY() < mc.level.getMinY() + 4 && p.getDeltaMovement().y < 0)
                jump(p, 1.0);
        }));
    }

    // ------------------------------------------------------------------ PLAYER
    static void player() {
        // needs pretty.accesswidener (Minecraft.rightClickDelay)
        add(new Mod("FastPlace", Cat.PLAYER).tick((mc, m) -> mc.rightClickDelay = 0));

        // needs pretty.accesswidener (MultiPlayerGameMode.destroyDelay)
        add(new Mod("FastBreak", Cat.PLAYER).tick((mc, m) -> {
            if (mc.gameMode != null) mc.gameMode.destroyDelay = 0;
        }));

        // needs pretty.accesswidener (LivingEntity.noJumpDelay)
        add(new Mod("NoJumpDelay", Cat.PLAYER).tick((mc, m) -> mc.player.noJumpDelay = 0));

        add(new Mod("AutoMine", Cat.PLAYER)
            .tick((mc, m) -> { if (mc.screen == null) mc.options.keyAttack.setDown(true); })
            .off((mc, m) -> mc.options.keyAttack.setDown(false)));

        add(new Mod("InventoryMove", Cat.PLAYER).tick((mc, m) -> {
            if (!(mc.screen instanceof AbstractContainerScreen<?>)) return;
            long win = mc.getWindow().getWindow();
            mc.options.keyUp.setDown(InputConstants.isKeyDown(win, GLFW.GLFW_KEY_W));
            mc.options.keyDown.setDown(InputConstants.isKeyDown(win, GLFW.GLFW_KEY_S));
            mc.options.keyLeft.setDown(InputConstants.isKeyDown(win, GLFW.GLFW_KEY_A));
            mc.options.keyRight.setDown(InputConstants.isKeyDown(win, GLFW.GLFW_KEY_D));
            mc.options.keyJump.setDown(InputConstants.isKeyDown(win, GLFW.GLFW_KEY_SPACE));
        }));

        add(new Mod("AutoLog", Cat.PLAYER).with(new Num("Health", 1, 19, 6, 1)).tick((mc, m) -> {
            Player p = mc.player;
            if (mc.getConnection() == null) return;
            if (p.getHealth() + p.getAbsorptionAmount() <= m.n("Health")) {
                m.enabled = false;
                mc.getConnection().getConnection().disconnect(Component.literal("AutoLog: low health"));
            }
        }));
    }

    // ------------------------------------------------------------------ RENDER
    static void render() {
        add(new Mod("ProjectileESP", Cat.RENDER).with(new Bool("Fill", true), new Num("Range", 16, 128, 64, 8)));

        add(new Mod("LightLevel", Cat.RENDER).with(new Num("Range", 4, 16, 9, 1), new Bool("Night spawns", true)));

        add(new Mod("FovChanger", Cat.RENDER).with(new Num("FOV", 30, 110, 95, 1))
            .tick((mc, m) -> { if (!zooming) force("fovc", mc.options.fov(), (int) m.n("FOV")); })
            .off((mc, m) -> restore("fovc")));
    }

    // --------------------------------------------------------------------- HUD
    static void hud() {
        add(new Mod("Compass", Cat.HUD));
        add(new Mod("FrameGraph", Cat.HUD).with(new Num("Samples", 60, 240, 120, 10)));
        add(new Mod("CPS", Cat.HUD));
        add(new Mod("ItemCounter", Cat.HUD));
        add(new Mod("ServerInfo", Cat.HUD));
        add(new Mod("InventoryHUD", Cat.HUD));
    }

    // ------------------------------------------------------------- PERFORMANCE
    static void perf() {
        add(new Mod("NoScreenEffects", Cat.PERF)
            .tick((mc, m) -> force("sfx", mc.options.screenEffectScale(), 0.0))
            .off((mc, m) -> restore("sfx")));

        add(new Mod("NoMenuBlur", Cat.PERF)
            .tick((mc, m) -> force("blur", mc.options.menuBackgroundBlurriness(), 0))
            .off((mc, m) -> restore("blur")));
    }
}
