package com.pretty.client;

import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/**
 * "Hands" module: the first-person arm is drawn as a flat, unlit shape with an animated vertical two-colour gradient.
 * Every buffer the arm renderer asks for is swapped for the POSITION_COLOR debug-quads buffer; the colour of each
 * vertex is computed from its height on screen.
 */
final class HandGradient {
    private HandGradient() {}

    static final class Source implements MultiBufferSource {
        private final MultiBufferSource inner;
        private final int c1, c2, alpha;
        private final float speed, t;

        Source(MultiBufferSource inner, PrettyClient.Mod m) {
            this.inner = inner;
            this.t = (System.currentTimeMillis() % 1000000L) / 1000f;
            float shift = m.b("Rainbow") ? t * 0.08f : 0f;
            float sat = (float) m.n("Saturation");
            this.c1 = Hooks.hsv((float) m.n("Hue 1") + shift, sat, 1f);
            this.c2 = Hooks.hsv((float) m.n("Hue 2") + shift, sat, 1f);
            this.speed = (float) m.n("Gradient speed");
            this.alpha = (int) (Math.max(0.05, Math.min(1.0, m.n("Alpha"))) * 255);
        }

        @Override
        public VertexConsumer getBuffer(RenderType type) {
            return new Consumer(inner.getBuffer(RenderType.debugQuads()), this);
        }
    }

    static final class Consumer implements VertexConsumer {
        private final VertexConsumer out;
        private final Source s;
        private float y;

        Consumer(VertexConsumer out, Source s) { this.out = out; this.s = s; }

        @Override
        public VertexConsumer addVertex(float x, float y, float z) {
            this.y = y;
            out.addVertex(x, y, z);
            return this;
        }

        @Override
        public VertexConsumer setColor(int r, int g, int b, int a) {
            float u = y * 1.6f + s.t * s.speed * 0.5f;
            float f = u - (float) Math.floor(u);
            f = 1f - Math.abs(2f * f - 1f);
            int rr = (int) ((s.c1 >> 16 & 255) * (1f - f) + (s.c2 >> 16 & 255) * f);
            int gg = (int) ((s.c1 >> 8 & 255) * (1f - f) + (s.c2 >> 8 & 255) * f);
            int bb = (int) ((s.c1 & 255) * (1f - f) + (s.c2 & 255) * f);
            out.setColor(rr, gg, bb, s.alpha);
            return this;
        }

        @Override public VertexConsumer setUv(float u, float v) { return this; }
        @Override public VertexConsumer setUv1(int u, int v) { return this; }
        @Override public VertexConsumer setUv2(int u, int v) { return this; }
        @Override public VertexConsumer setNormal(float x, float y, float z) { return this; }
    }

    /** ItemShader: tints the textures of the held item with an animated two-colour gradient (texture stays visible). */
    static final class ItemSource implements MultiBufferSource {
        private final MultiBufferSource inner;
        private final PrettyClient.Mod m;
        private final float t, sat, speed, strength, h1, h2;
        private final boolean rainbow;

        ItemSource(MultiBufferSource inner, PrettyClient.Mod m) {
            this.inner = inner;
            this.m = m;
            this.t = (System.currentTimeMillis() % 1000000L) / 1000f;
            this.rainbow = m.b("Rainbow");
            this.sat = (float) m.n("Saturation");
            this.speed = (float) m.n("Gradient speed");
            this.strength = (float) m.n("Strength");
            this.h1 = (float) m.n("Hue 1");
            this.h2 = (float) m.n("Hue 2");
        }

        @Override
        public VertexConsumer getBuffer(RenderType type) {
            VertexConsumer vc = inner.getBuffer(type);
            ItemStack s = Hooks.curStack;
            if (s == null || s.isEmpty() || s.is(Items.FILLED_MAP)) return vc;
            String name = Hooks.CATS[Hooks.itemCategory(s)];
            if (!m.b(name)) return vc;
            float shift = (float) m.n(name + " hue shift") + (rainbow ? t * 0.08f : 0f);
            return new Tint(vc, Hooks.hsv(h1 + shift, sat, 1f), Hooks.hsv(h2 + shift, sat, 1f), speed, t, strength);
        }
    }

    static final class Tint implements VertexConsumer {
        private final VertexConsumer out;
        private final int c1, c2;
        private final float speed, t, k;
        private float y;

        Tint(VertexConsumer out, int c1, int c2, float speed, float t, float k) {
            this.out = out; this.c1 = c1; this.c2 = c2; this.speed = speed; this.t = t; this.k = k;
        }

        @Override
        public VertexConsumer addVertex(float x, float y, float z) {
            this.y = y;
            out.addVertex(x, y, z);
            return this;
        }

        @Override
        public VertexConsumer setColor(int r, int g, int b, int a) {
            float u = y * 1.6f + t * speed * 0.5f;
            float f = u - (float) Math.floor(u);
            f = 1f - Math.abs(2f * f - 1f);
            float gr = ((c1 >> 16 & 255) * (1f - f) + (c2 >> 16 & 255) * f) / 255f;
            float gg = ((c1 >> 8 & 255) * (1f - f) + (c2 >> 8 & 255) * f) / 255f;
            float gb = ((c1 & 255) * (1f - f) + (c2 & 255) * f) / 255f;
            float boost = 1.35f;
            int rr = Math.min(255, (int) (r * (1f - k + k * gr * boost)));
            int gg2 = Math.min(255, (int) (g * (1f - k + k * gg * boost)));
            int bb = Math.min(255, (int) (b * (1f - k + k * gb * boost)));
            out.setColor(rr, gg2, bb, a);
            return this;
        }

        @Override public VertexConsumer setUv(float u, float v) { out.setUv(u, v); return this; }
        @Override public VertexConsumer setUv1(int u, int v) { out.setUv1(u, v); return this; }
        @Override public VertexConsumer setUv2(int u, int v) { out.setUv2(u, v); return this; }
        @Override public VertexConsumer setNormal(float x, float y, float z) { out.setNormal(x, y, z); return this; }
    }
}
