package com.pretty.client.mixin;

import com.pretty.client.Hooks;
import net.minecraft.client.player.LocalPlayer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** KillAura silent rotation: the rotation packet carries the aura angles, the camera stays where you look. */
@Mixin(LocalPlayer.class)
public class LocalPlayerMixin {
    @Inject(method = "sendPosition", at = @At("HEAD"))
    private void pretty$sendPre(CallbackInfo ci) {
        Hooks.silentPre((LocalPlayer) (Object) this);
    }

    @Inject(method = "sendPosition", at = @At("RETURN"))
    private void pretty$sendPost(CallbackInfo ci) {
        Hooks.silentPost((LocalPlayer) (Object) this);
    }
}
