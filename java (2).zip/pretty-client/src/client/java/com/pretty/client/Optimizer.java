package com.pretty.client;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;

/**
 * "Optimize" module: one switch for general FPS.
 * Level 1 = light (fast graphics, no clouds / shadows, no biome blend, no FOV effects),
 * Level 2 = balanced (+ fewer particles, no AO, unlocked FPS), Level 3 = max (+ turns the decorative visuals off).
 * Adaptive: every second the FPS is checked; when it stays under Target FPS the render distance drops one chunk at a time
 * (down to Min chunks) and it climbs back to your own value when there is plenty of headroom.
 */
final class Optimizer {
    private Optimizer() {}

    private static final String[] ON1 = {"FastGraphics", "NoClouds", "NoShadows", "NoFovEffects"};
    private static final String[] ON2 = {"LowParticles", "NoAO", "UnlockFPS"};
    private static final String[] OFF3 = {"ChunkFade", "SkyParticles", "ShaderHands", "ItemShader"};

    private static final List<String> turnedOn = new ArrayList<>();
    private static final List<String> turnedOff = new ArrayList<>();
    private static int level = -1, ticks, low, high, cool, origRd = -1, curRd;

    private static void undoModules() {
        for (String n : turnedOn) { PrettyClient.Mod x = PrettyClient.find(n); if (x != null && x.enabled) x.toggle(); }
        for (String n : turnedOff) { PrettyClient.Mod x = PrettyClient.find(n); if (x != null && !x.enabled) x.toggle(); }
        turnedOn.clear();
        turnedOff.clear();
    }

    private static void on(String[] names) {
        for (String n : names) {
            PrettyClient.Mod x = PrettyClient.find(n);
            if (x != null && !x.enabled) { x.toggle(); turnedOn.add(n); }
        }
    }

    private static void apply(int lv) {
        undoModules();
        on(ON1);
        if (lv >= 2) on(ON2);
        if (lv >= 3) {
            for (String n : OFF3) {
                PrettyClient.Mod x = PrettyClient.find(n);
                if (x != null && x.enabled) { x.toggle(); turnedOff.add(n); }
            }
        }
    }

    static void tick(Minecraft mc, PrettyClient.Mod m) {
        int lv = Math.max(1, Math.min(3, (int) m.n("Level")));
        if (lv != level) { level = lv; apply(lv); }
        Hooks.setOpt(true, m.n("Block entity range"), m.n("Particle range"));
        // biome blend: Quality (Visual) owns this option when it is on, otherwise Optimize drops it to 0
        PrettyClient.Mod q = PrettyClient.find("Quality");
        if (q != null && q.enabled) PrettyClient.restore("opt_blend");
        else PrettyClient.force("opt_blend", mc.options.biomeBlendRadius(), 0);
        if (!mc.isWindowActive()) {
            PrettyClient.force("opt_bg", mc.options.framerateLimit(), Math.min(mc.options.framerateLimit().get(), (int) m.n("Background FPS")));
        } else {
            PrettyClient.restore("opt_bg");
        }
        if (!m.b("Adaptive") || mc.level == null) return;
        if (origRd < 0) { origRd = mc.options.renderDistance().get(); curRd = origRd; }
        if (++ticks % 20 != 0) return;
        int fps = mc.getFps(), target = (int) m.n("Target FPS"), minC = (int) m.n("Min chunks");
        if (cool > 0) { cool--; return; }
        if (fps < target) { low++; high = 0; }
        else if (fps > target + 30) { high++; low = 0; }
        else { low = 0; high = 0; }
        if (low >= 3 && curRd > minC) {
            curRd--; low = 0; cool = 6;
            PrettyClient.force("opt_rd", mc.options.renderDistance(), curRd);
        } else if (high >= 10 && curRd < origRd) {
            curRd++; high = 0; cool = 6;
            PrettyClient.force("opt_rd", mc.options.renderDistance(), curRd);
        }
    }

    static void off() {
        Hooks.setOpt(false, 0, 0);
        PrettyClient.restore("opt_bg");
        PrettyClient.restore("opt_rd");
        PrettyClient.restore("opt_blend");
        undoModules();
        level = -1; ticks = 0; low = 0; high = 0; cool = 0; origRd = -1;
    }
}
