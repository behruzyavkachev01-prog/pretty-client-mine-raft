package com.pretty.client.mixin;

import com.mojang.blaze3d.vertex.PoseStack;
import com.pretty.client.Hooks;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.ItemInHandRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * First-person hands and held items:
 *  - Hands: gradient on the empty arm
 *  - ItemShader: colour tint on held items (per item type)
 *  - CustomHand: moves / rotates / scales the held ITEM (inside the swing, so the hit animation stays intact)
 *    and, separately, the empty ARM; also eases the swing animation.
 * Injection targets are full descriptors; if one does not match, that part just does nothing (defaultRequire 0) and
 * the compiler prints a "Cannot find target method" warning.
 */
@Mixin(ItemInHandRenderer.class)
public class ItemInHandRendererMixin {
    private static final String ITEM = "Lnet/minecraft/client/renderer/ItemInHandRenderer;renderItem("
        + "Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/world/item/ItemStack;"
        + "Lnet/minecraft/world/item/ItemDisplayContext;ZLcom/mojang/blaze3d/vertex/PoseStack;"
        + "Lnet/minecraft/client/renderer/MultiBufferSource;I)V";
    private static final String ARM = "Lnet/minecraft/client/renderer/ItemInHandRenderer;renderPlayerArm("
        + "Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;IFF"
        + "Lnet/minecraft/world/entity/HumanoidArm;)V";

    @ModifyVariable(method = "renderPlayerArm", at = @At("HEAD"), argsOnly = true)
    private MultiBufferSource pretty$hands(MultiBufferSource src) {
        return Hooks.handBuffer(src);
    }

    /** ItemShader: wraps the buffer source used for the held item (reads Hooks.curStack lazily). */
    @ModifyVariable(method = "renderArmWithItem", at = @At("HEAD"), argsOnly = true)
    private MultiBufferSource pretty$items(MultiBufferSource src) {
        return Hooks.itemBuffer(src);
    }

    /** Smoother swing animation. Ordinal 2 = swingProgress (floats: partialTicks, pitch, swingProgress, equipProgress). */
    @ModifyVariable(method = "renderArmWithItem", at = @At("HEAD"), argsOnly = true, ordinal = 2)
    private float pretty$swing(float t) {
        return Hooks.swing(t);
    }

    @Inject(method = "renderArmWithItem", at = @At("HEAD"))
    private void pretty$begin(AbstractClientPlayer player, float pt, float pitch, InteractionHand hand,
                              float swing, ItemStack stack, float equip, PoseStack ps,
                              MultiBufferSource buf, int light, CallbackInfo ci) {
        Hooks.curStack = stack;
    }

    // ---- held item: transform right before the item is drawn, i.e. AFTER the vanilla swing / equip transforms
    @Inject(method = "renderArmWithItem", at = @At(value = "INVOKE", target = ITEM))
    private void pretty$itemPre(AbstractClientPlayer player, float pt, float pitch, InteractionHand hand,
                                float swing, ItemStack stack, float equip, PoseStack ps,
                                MultiBufferSource buf, int light, CallbackInfo ci) {
        ps.pushPose();
        Hooks.customItem(ps, hand, stack);
    }

    @Inject(method = "renderArmWithItem", at = @At(value = "INVOKE", target = ITEM, shift = At.Shift.AFTER))
    private void pretty$itemPost(AbstractClientPlayer player, float pt, float pitch, InteractionHand hand,
                                 float swing, ItemStack stack, float equip, PoseStack ps,
                                 MultiBufferSource buf, int light, CallbackInfo ci) {
        ps.popPose();
    }

    // ---- empty arm: its own transform, independent from the item
    @Inject(method = "renderArmWithItem", at = @At(value = "INVOKE", target = ARM))
    private void pretty$armPre(AbstractClientPlayer player, float pt, float pitch, InteractionHand hand,
                               float swing, ItemStack stack, float equip, PoseStack ps,
                               MultiBufferSource buf, int light, CallbackInfo ci) {
        ps.pushPose();
        Hooks.customArm(ps, hand);
    }

    @Inject(method = "renderArmWithItem", at = @At(value = "INVOKE", target = ARM, shift = At.Shift.AFTER))
    private void pretty$armPost(AbstractClientPlayer player, float pt, float pitch, InteractionHand hand,
                                float swing, ItemStack stack, float equip, PoseStack ps,
                                MultiBufferSource buf, int light, CallbackInfo ci) {
        ps.popPose();
    }
}
