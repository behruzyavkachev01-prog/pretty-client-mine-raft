package com.pretty.client;

import static com.pretty.client.PrettyClient.*;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.IOException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.security.MessageDigest;
import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.Stream;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.server.packs.repository.PackRepository;
import net.minecraft.util.Mth;

/**
 * "Mods & Packs": one-click install of optimization mods (Sodium, Lithium, ...) and nice resource packs
 * (Faithful, ...). Files come from the official Modrinth API for Minecraft 1.21.4 and are checked against the
 * SHA-512 hash Modrinth publishes before they are saved into .minecraft/mods or .minecraft/resourcepacks.
 */
final class ModsScreen extends Screen {

    // =====================================================================
    //  Catalogue
    // =====================================================================
    static final class Item {
        final String name, desc, slug, modId, query;
        final boolean pack;
        /** Name of a pack zip bundled inside this mod (assets/pretty/packs/NAME), or null for Modrinth items. */
        String local;
        volatile String status = "";
        volatile boolean busy, fresh;
        boolean shader;

        Item(String name, String desc, String slug, String modId, String query, boolean pack) {
            this.name = name; this.desc = desc; this.slug = slug; this.modId = modId; this.query = query; this.pack = pack;
        }
    }

    static Item mod(String name, String desc, String slug, String modId) {
        return new Item(name, desc, slug, modId, name, false);
    }

    /** A shader pack (needs Iris): goes to .minecraft/shaderpacks. */
    static Item shader(String name, String desc, String slug) {
        Item it = new Item(name, desc, slug, null, name, true);
        it.shader = true;
        return it;
    }

    static Item pack(String name, String desc, String slug) {
        return new Item(name, desc, slug, null, name, true);
    }

    /** A pack found by search: Modrinth's best result for the query is downloaded (the status shows which file). */
    static Item packQ(String name, String desc, String query) {
        String slug = "q-" + query.toLowerCase().replaceAll("[^a-z0-9]+", "-").replaceAll("^-|-$", "");
        return new Item(name, desc + " (поиск «" + query + "» на Modrinth)", slug, null, query, true);
    }

    /** A pack that ships inside the mod: Install copies it into .minecraft/resourcepacks. */
    static Item bundled(String name, String desc, String file) {
        Item it = new Item(name, desc, "local-" + file, null, name, true);
        it.local = file;
        return it;
    }

    static final List<Item> MODS_L = List.of(
        mod("Sodium", "Главный мод оптимизации: переписывает рендер, FPS вырастает в разы.", "sodium", "sodium"),
        mod("Lithium", "Оптимизирует логику игры: мобы, физика, генерация мира.", "lithium", "lithium"),
        mod("FerriteCore", "Сильно уменьшает потребление оперативной памяти.", "ferrite-core", "ferritecore"),
        mod("ImmediatelyFast", "Ускоряет отрисовку интерфейса, текста и предметов.", "immediatelyfast", "immediatelyfast"),
        mod("Entity Culling", "Не рисует существ за стенами: больше FPS на серверах.", "entityculling", "entityculling"),
        mod("ModernFix", "Быстрая загрузка игры и меньше памяти.", "modernfix", "modernfix"),
        mod("Krypton", "Ускоряет сетевой стек: меньше лагов на серверах.", "krypton", "krypton"),
        mod("Sodium Extra", "Доп. настройки для Sodium: облака, анимации, частицы, FPS-счётчик.", "sodium-extra", "sodium-extra"),
        mod("Reese's Sodium Options", "Удобное меню настроек видео для Sodium.", "reeses-sodium-options", "reeses-sodium-options"),
        mod("More Culling", "Ещё больше отсечения невидимого: плавнее FPS в городах и базах.", "moreculling", "moreculling"),
        mod("Noisium", "Ускоряет генерацию мира: меньше подлагов при беге по новым чанкам.", "noisium", "noisium"),
        mod("ScalableLux", "Быстрый движок освещения: меньше лагов при подгрузке чанков.", "scalablelux", "scalablelux"),
        mod("Dynamic FPS", "Снижает нагрузку, когда окно игры не в фокусе.", "dynamic-fps", "dynamic_fps"),
        mod("Iris Shaders", "Поддержка шейдеров, работает вместе с Sodium.", "iris", "iris"),
        mod("Continuity", "Связанные текстуры (стекло, книжные полки) для красивых ресурспаков.", "continuity", "continuity"),
        mod("LambDynamicLights", "Динамическое освещение: факел в руке светит вокруг.", "lambdynamiclights", "lambdynlights"),
        mod("Skin Layers 3D", "Объёмные слои скина: шапки, куртки и рукава выглядят 3D.", "skinlayers3d", "skinlayers3d"),
        mod("Not Enough Animations", "Плавные анимации игрока и от третьего лица.", "not-enough-animations", "notenoughanimations"),
        mod("AppleSkin", "Показывает сытость и насыщение еды прямо на панели голода.", "appleskin", "appleskin"),
        mod("Mouse Tweaks", "Удобное перетаскивание и раскладка предметов в инвентаре.", "mouse-tweaks", "mousetweaks"),
        mod("No Chat Reports", "Отключает подпись чата и отчёты: больше приватности.", "no-chat-reports", "nochatreports"),
        mod("Mod Menu", "Список установленных модов прямо в меню игры.", "modmenu", "modmenu"),
        mod("Xaero's Minimap", "Мини-карта с вейпоинтами, мобами и игроками. Заменяет встроенную.", "xaeros-minimap", "xaerominimap"),
        mod("Xaero's World Map", "Большая карта мира, работает вместе с мини-картой Xaero.", "xaeros-world-map", "xaeroworldmap"),
        mod("RenderScale", "Рендер в большем разрешении (1.5x-2x), потом сжатие: картинка как в 2K, очень чёткая. Тяжело для видеокарты.", "Va8PJBFX", "renderscale"),
        mod("QDAA", "Быстрое сглаживание: игра рисуется в 2x разрешении и сжимается. Убирает лесенки.", "qdaa", "qdaa"));

    /** The first nine entries are what "Install optimization pack" installs. */
    static final int OPT_COUNT = 9;

    static final List<Item> PACKS_L = List.of(
        bundled("KeySounds Template", "Шаблон звуков клавиатуры и мыши: замени файлы внутри zip своими записями (Aula, Gravastar). Инструкция в README внутри.", "pretty_keysounds.zip"),
        pack("FunTime", "Ресурспак FunTime. Клиент ищет его на Modrinth по названию.", "funtime"),
        pack("Faithful 32x", "Классический стиль игры в чётком разрешении 32x. Самый популярный ресурспак.", "faithful-32x"),
        pack("Faithful 64x", "То же самое, но ещё детальнее: 64x для мощных ПК.", "faithful-64x"),
        pack("Stay True", "Ванильный стиль с аккуратными улучшениями, ближе всего к оригиналу.", "stay-true"),
        pack("Mizuno's 16 Craft", "Мягкая яркая 16x-палитра: уютный и красивый вид мира.", "mizunos-16-craft"),
        pack("Faithless", "Тёмный контрастный стиль, популярный у PvP-игроков.", "faithless"),
        pack("Dramatic Skys", "Красивое небо: закаты, звёзды, облака. Отлично с SkyChanger.", "dramatic-skys"),
        pack("Cubic Sun & Moon", "Квадратные солнце и луна в стиле классики.", "cubic-sun-moon"),
        pack("Fast Better Grass", "Объёмная трава без потери FPS.", "fast-better-grass"),
        pack("Default Dark Mode", "Тёмный интерфейс игры: приятно для глаз.", "default-dark-mode"),
        pack("Bare Bones", "Максимально простой стиль: чистые цвета и хороший FPS.", "bare-bones"),
        pack("Better Leaves", "Пышная листва: деревья выглядят объёмнее.", "better-leaves"),
        pack("Low Fire", "Огонь на экране ниже и не закрывает обзор.", "low-fire"),
        pack("Fresh Animations", "Плавные анимации мобов. Нужны моды Entity Model Features и Entity Texture Features.", "fresh-animations"),
        packQ("Pastel", "Мягкие пастельные цвета, спокойный вид мира для чила.", "pastel"),
        packQ("Cozy", "Уютные тёплые текстуры.", "cozy vanilla"),
        packQ("Cartoon", "Мультяшный яркий стиль.", "cartoon"),
        packQ("Soft Clouds", "Мягкие красивые облака и небо.", "clouds"),
        packQ("Sunset Sky", "Красивое небо, закаты.", "sky"),
        packQ("Better Water", "Чистая приятная вода.", "clear water"),
        packQ("Rain", "Красивый дождь и погода.", "rain"),
        packQ("Dark GUI", "Тёмный интерфейс.", "dark gui"),
        packQ("Minimalist", "Минималистичный лёгкий стиль, хорошо читается.", "minimalist"),
        packQ("Low Res 8x", "Лёгкие текстуры 8x для слабых ПК: меньше нагрузка на память.", "low resolution 8x"),
        packQ("Fast Leaves", "Простая листва без лишних полигонов: больше FPS в лесу.", "fast leaves"),
        packQ("Less Particles", "Меньше и тише частицы: легче для игры и глаз.", "less particles"),
        packQ("Fast Glass", "Простое стекло без тяжёлых эффектов.", "clear glass"),
        packQ("Vanilla Smooth", "Ванильные текстуры, сглаженные и приятные.", "vanilla smooth"));

    /** PvP section: packs that change tools, totems, armor, enchant glint and fire for fighting. */
    static final List<Item> PVP_L = List.of(
        bundled("Mini Tools", "Мечи, кирки, топоры и лопаты в руке становятся маленькими. Встроенный пак.", "pretty_mini_tools.zip"),
        bundled("Mini Totem", "Тотем бессмертия в руке и во второй руке маленький. Встроенный пак.", "pretty_mini_totem.zip"),
        bundled("PvP Glint", "Голубой блеск зачарования на мечах и броне: чётко видно чары. Встроенный пак.", "pretty_pvp_glint.zip"),
        pack("FunTime", "Ресурспак FunTime. Клиент ищет его на Modrinth по названию.", "funtime"),
        pack("Short Swords", "Короткие мечи: меньше перекрывают экран в бою (поиск на Modrinth).", "short-swords"),
        pack("Faithless", "Тёмный контрастный стиль, популярный у PvP-игроков.", "faithless"),
        pack("Bare Bones", "Простые чистые цвета и высокий FPS: удобно читать бой.", "bare-bones"),
        pack("Low Fire", "Огонь на экране ниже и не закрывает обзор в драке.", "low-fire"),
        packQ("Low Shield", "Щит ниже и меньше, не закрывает обзор.", "low shield"),
        packQ("Small Totems", "Маленькие тотемы в руке.", "small totem"),
        packQ("Enchant Glint", "Цветной блеск зачарования: чётко видно чары на броне и оружии.", "enchantment glint"),
        packQ("PvP Armor", "Читаемая броня для боя: удобно различать материал и чары.", "pvp armor"),
        packQ("PvP Swords", "Мечи для PvP: чёткие, лёгкие по обзору.", "pvp swords"),
        packQ("Blue Fire", "Голубой огонь, ниже и аккуратнее.", "blue fire"),
        packQ("Clean Crosshair", "Чистый прицел и интерфейс.", "crosshair"),
        packQ("Particles Lite", "Меньше частиц в драке: больше FPS.", "pvp particles"),
        packQ("Low Crystals", "Кристаллы энда ниже и проще.", "end crystal"),
        packQ("Hit Colors", "Заметная подсветка урона.", "damage tint"),
        packQ("Fast PvP", "Паки для плавного PvP с высоким FPS.", "pvp fps"));

    static final List<Item> SHADERS_L = List.of(
        shader("Complementary Reimagined", "Самый популярный шейдер: яркая чёткая картинка и хороший FPS.", "complementary-reimagined"),
        shader("Complementary Unbound", "Тот же автор, ярче и насыщеннее, чуть тяжелее.", "complementary-unbound"),
        shader("BSL Shaders", "Классика: красивый свет, вода и небо.", "bsl-shaders"),
        shader("Solas Shader", "Яркие насыщенные цвета, средняя нагрузка.", "solas-shader"),
        shader("MakeUp Ultra Fast", "Очень лёгкий шейдер: красиво и почти без потери FPS. Для слабых ПК.", "makeup-ultra-fast-shader"),
        shader("Photon", "Современный шейдер с мягким светом и отражениями.", "photon-shader"),
        shader("Rethinking Voxels", "Реалистичный свет и тени, нужна мощная видеокарта.", "rethinking-voxels"),
        shader("Miniature Shader", "Мягкий мультяшный стиль, лёгкий.", "miniature-shader"),
        shader("Sildur's Vibrant", "Яркие цвета, несколько вариантов нагрузки.", "sildurs-vibrant-shaders"),
        shader("Sildur's Enhanced Default", "Почти ванильный вид, но чётче и ярче. Очень лёгкий.", "sildurs-enhanced-default"));

    // =====================================================================
    //  Installing (Modrinth)
    // =====================================================================
    static final String API = "https://api.modrinth.com/v2";
    static final String FABRIC_API_ID = "P7dR8mSH";
    static final String MC_VERSION = "1.21.4";
    static final HttpClient HTTP = HttpClient.newBuilder()
        .followRedirects(HttpClient.Redirect.NORMAL).connectTimeout(Duration.ofSeconds(12)).build();
    static final ExecutorService EX = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "pretty-downloads");
        t.setDaemon(true);
        return t;
    });
    static final Map<String, String> RECORD = new HashMap<>();
    static boolean recordLoaded;

    static Path modsDir() { return FabricLoader.getInstance().getGameDir().resolve("mods"); }
    static Path packsDir() { return FabricLoader.getInstance().getGameDir().resolve("resourcepacks"); }
    static Path shadersDir() { return FabricLoader.getInstance().getGameDir().resolve("shaderpacks"); }
    static Path dirOf(Item it) { return it.shader ? shadersDir() : it.pack ? packsDir() : modsDir(); }
    static Path recordPath() { return FabricLoader.getInstance().getConfigDir().resolve("prettyclient-installed.txt"); }

    static synchronized void loadRecord() {
        if (recordLoaded) return;
        recordLoaded = true;
        try {
            Path p = recordPath();
            if (!Files.exists(p)) return;
            for (String line : Files.readAllLines(p)) {
                int i = line.indexOf('|');
                if (i > 0) RECORD.put(line.substring(0, i), line.substring(i + 1));
            }
        } catch (IOException | RuntimeException ignored) {
        }
    }

    static synchronized void record(String slug, String file) {
        RECORD.put(slug, file);
        try {
            StringBuilder sb = new StringBuilder();
            for (var e : RECORD.entrySet()) sb.append(e.getKey()).append('|').append(e.getValue()).append('\n');
            Files.writeString(recordPath(), sb.toString());
        } catch (IOException | RuntimeException ignored) {
        }
    }

    static boolean installed(Item it) {
        loadRecord();
        if (!it.pack && it.modId != null && FabricLoader.getInstance().isModLoaded(it.modId)) return true;
        String f = RECORD.get(it.slug);
        return f != null && Files.exists(dirOf(it).resolve(f));
    }

    static boolean packEnabled(Item it) {
        String f = RECORD.get(it.slug);
        if (f == null) return false;
        return Minecraft.getInstance().getResourcePackRepository().getSelectedIds().contains("file/" + f);
    }

    static String enc(String s) { return URLEncoder.encode(s, StandardCharsets.UTF_8); }

    static JsonElement getJson(String url) throws IOException, InterruptedException {
        HttpRequest r = HttpRequest.newBuilder(URI.create(url))
            .header("User-Agent", "PrettyClient/1.1 (minecraft fabric client)")
            .timeout(Duration.ofSeconds(20)).GET().build();
        HttpResponse<String> resp = HTTP.send(r, HttpResponse.BodyHandlers.ofString());
        if (resp.statusCode() == 404) return null;
        if (resp.statusCode() != 200) throw new IOException("HTTP " + resp.statusCode());
        return JsonParser.parseString(resp.body());
    }

    static JsonArray versions(String id, boolean pack) throws IOException, InterruptedException {
        String url = API + "/project/" + enc(id) + "/version?game_versions=" + enc("[\"" + MC_VERSION + "\"]")
            + (pack ? "" : "&loaders=" + enc("[\"fabric\"]"));
        JsonElement e = getJson(url);
        return e == null ? null : e.getAsJsonArray();
    }

    static String search(String q, boolean pack, boolean shader) throws IOException, InterruptedException {
        String facets = "[[\"project_type:" + (shader ? "shader" : pack ? "resourcepack" : "mod") + "\"],[\"versions:" + MC_VERSION + "\"]]";
        JsonElement e = getJson(API + "/search?query=" + enc(q) + "&limit=1&facets=" + enc(facets));
        if (e == null) return null;
        JsonArray hits = e.getAsJsonObject().getAsJsonArray("hits");
        if (hits.isEmpty()) return null;
        return hits.get(0).getAsJsonObject().get("slug").getAsString();
    }

    /** True if a jar of the same mod (same file-name prefix) is already in the folder: avoids duplicate-mod crashes. */
    static boolean alreadyHas(Path dir, String fname) {
        String lower = fname.toLowerCase(Locale.ROOT);
        int cut = lower.length();
        for (char c : new char[] {'-', '_'}) {
            int i = lower.indexOf(c);
            if (i > 0) cut = Math.min(cut, i);
        }
        String prefix = lower.substring(0, cut);
        try (Stream<Path> s = Files.list(dir)) {
            return s.anyMatch(p -> {
                String n = p.getFileName().toString().toLowerCase(Locale.ROOT);
                return n.equals(lower) || n.startsWith(prefix + "-") || n.startsWith(prefix + "_");
            });
        } catch (IOException e) {
            return false;
        }
    }

    static String sha512(byte[] data) throws Exception {
        byte[] d = MessageDigest.getInstance("SHA-512").digest(data);
        StringBuilder sb = new StringBuilder();
        for (byte b : d) sb.append(String.format("%02x", b));
        return sb.toString();
    }

    /** Downloads the newest 1.21.4 build of a project (plus its required dependencies). Returns the file name. */
    static String fetch(String id, String query, boolean pack, Path dir, Set<String> seen, int depth, Item top)
        throws Exception {
        top.status = depth == 0 ? "Поиск..." : "Зависимость...";
        JsonArray vs = versions(id, pack);
        if ((vs == null || vs.isEmpty()) && query != null) {
            String slug = search(query, pack, top.shader);
            if (slug != null) vs = versions(slug, pack);
        }
        if (vs == null || vs.isEmpty()) throw new IOException("нет версии для " + MC_VERSION);

        JsonObject v = vs.get(0).getAsJsonObject();
        for (JsonElement el : vs) {
            JsonObject o = el.getAsJsonObject();
            if ("release".equals(o.get("version_type").getAsString())) { v = o; break; }
        }

        if (!pack && depth < 2 && v.has("dependencies")) {
            for (JsonElement el : v.getAsJsonArray("dependencies")) {
                JsonObject o = el.getAsJsonObject();
                if (!"required".equals(o.get("dependency_type").getAsString())) continue;
                if (!o.has("project_id") || o.get("project_id").isJsonNull()) continue;
                String pid = o.get("project_id").getAsString();
                if (FABRIC_API_ID.equals(pid) || !seen.add(pid)) continue;
                fetch(pid, null, false, dir, seen, depth + 1, top);
            }
        }

        JsonArray files = v.getAsJsonArray("files");
        JsonObject f = files.get(0).getAsJsonObject();
        for (JsonElement el : files) {
            JsonObject o = el.getAsJsonObject();
            if (o.has("primary") && o.get("primary").getAsBoolean()) { f = o; break; }
        }
        String fname = f.get("filename").getAsString();
        Path base = dir.toAbsolutePath().normalize();
        Path target = base.resolve(fname).normalize();
        if (!target.startsWith(base)) throw new IOException("bad file name");
        Files.createDirectories(base);

        if (Files.exists(target) || (!pack && alreadyHas(base, fname))) return fname;

        top.status = "Загрузка " + fname;
        HttpRequest r = HttpRequest.newBuilder(URI.create(f.get("url").getAsString()))
            .header("User-Agent", "PrettyClient/1.1 (minecraft fabric client)")
            .timeout(Duration.ofMinutes(5)).GET().build();
        HttpResponse<byte[]> resp = HTTP.send(r, HttpResponse.BodyHandlers.ofByteArray());
        if (resp.statusCode() != 200) throw new IOException("HTTP " + resp.statusCode());
        byte[] data = resp.body();
        JsonObject hashes = f.getAsJsonObject("hashes");
        if (hashes != null && hashes.has("sha512") && !sha512(data).equalsIgnoreCase(hashes.get("sha512").getAsString()))
            throw new IOException("хеш не совпал, файл отброшен");
        Path tmp = base.resolve(fname + ".part");
        Files.write(tmp, data);
        Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING);
        return fname;
    }

    static void install(Item it) {
        if (it.busy || installed(it)) return;
        if (!it.pack && it.local == null && FabricLoader.getInstance().isDevelopmentEnvironment()) {
            // Jars from Modrinth use release (intermediary) names; in runClient they are not remapped and crash the game.
            it.status = "runClient: см. build.gradle";
            return;
        }
        it.busy = true;
        it.status = "В очереди...";
        EX.submit(() -> {
            try {
                String fname;
                if (it.local != null) {
                    it.status = "Копирую...";
                    Files.createDirectories(packsDir());
                    try (var in = ModsScreen.class.getResourceAsStream("/assets/pretty/packs/" + it.local)) {
                        if (in == null) throw new IOException("пак не найден в моде");
                        Files.copy(in, packsDir().resolve(it.local), StandardCopyOption.REPLACE_EXISTING);
                    }
                    fname = it.local;
                } else {
                    Set<String> seen = new HashSet<>();
                    fname = fetch(it.slug, it.query, it.pack, dirOf(it), seen, 0, it);
                }
                record(it.slug, fname);
                it.fresh = true;
                it.status = it.pack ? "Скачано: " + shortName(fname) : "Установлено, нужен перезапуск";
                if (it.pack && !it.shader) Minecraft.getInstance().execute(() -> Minecraft.getInstance().getResourcePackRepository().reload());
            } catch (Exception e) {
                String m = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
                it.status = "Ошибка: " + (m.length() > 40 ? m.substring(0, 40) : m);
            } finally {
                it.busy = false;
            }
        });
    }

    static String shortName(String f) {
        if (f == null) return "";
        String n = f.endsWith(".zip") ? f.substring(0, f.length() - 4) : f;
        return n.length() > 22 ? n.substring(0, 22) : n;
    }

    static void enablePack(Item it) {
        Minecraft mc = Minecraft.getInstance();
        String f = RECORD.get(it.slug);
        if (f == null) return;
        try {
            PackRepository repo = mc.getResourcePackRepository();
            repo.reload();
            String id = "file/" + f;
            if (!repo.getAvailableIds().contains(id)) { it.status = "Не найден, перезапусти игру"; return; }
            List<String> selected = new ArrayList<>(repo.getSelectedIds());
            if (!selected.contains(id)) selected.add(id);
            repo.setSelected(selected);
            mc.options.updateResourcePacks(repo);
            it.status = "Включено";
        } catch (RuntimeException e) {
            it.status = "Включи в Options > Resource Packs";
        }
    }

    // =====================================================================
    //  Screen
    // =====================================================================
    private static final int K_TAB = 0, K_ITEM = 1, K_ALL = 2, K_FOLDER = 3, K_BACK = 4;

    record Hit(int x, int y, int w, int h, int kind, Item item, int idx) {
        boolean in(double px, double py) { return px >= x && px <= x + w && py >= y && py <= y + h; }
    }

    private final Screen parent;
    private final List<Hit> hits = new ArrayList<>();
    private int tab;
    private float tabAnim, open, scroll, scrollT;
    private final Map<Object, Float> hov = new HashMap<>();
    private long last = System.nanoTime();
    private int listTop, listBot;

    ModsScreen(Screen parent) {
        super(Component.literal("Mods & Packs"));
        this.parent = parent;
        loadRecord();
    }

    private float hv(Object key, boolean on, float dt) {
        float v = Ui.approach(hov.getOrDefault(key, 0f), on ? 1f : 0f, dt, 14f);
        hov.put(key, v);
        return v;
    }

    private void button(GuiGraphics g, int x, int y, int w, int h, String label, boolean hovered, Object key,
                        float dt, float e, int acc, boolean enabled) {
        float hvv = hv(key, hovered && enabled, dt);
        int base = enabled ? mix(0x111A15, acc, 0.20f) : 0x101613;
        rr(g, x, y, w, h, 4, alpha(mix(base, acc, hvv * 0.35f), e));
        int tc = enabled ? mix(0xC4D2CA, 0xFFFFFF, hvv) : 0x647A6D;
        Ui.d(g, label, x + w / 2 - Ui.w(label) / 2, y + (h - 8) / 2, alpha(tc, e), false);
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        long now = System.nanoTime();
        float dt = Math.min((now - last) / 1e9f, 0.05f);
        last = now;
        open = Math.min(1f, open + dt * 4f);
        float e = ease(open);
        int acc = accent(0f);
        hits.clear();
        tabAnim = Ui.approach(tabAnim, tab, dt, 12f);

        g.fill(0, 0, width, height, alpha(0x000000, 0.6f * e));

        int ww = Math.min(width - 16, 430), wh = Math.min(height - 16, 262);
        int wx = (width - ww) / 2, wy = (height - wh) / 2 + (int) ((1f - e) * 14f);
        rr(g, wx - 1, wy - 1, ww + 2, wh + 2, 7, alpha(acc, 0.35f * e));
        rr(g, wx, wy, ww, wh, 6, alpha(0x090F0C, 0.97f * e));

        // header + tabs
        Ui.dt(g, "Mods & Packs", wx + 12, wy + 9, alpha(acc, e), false);
        String note = "Minecraft " + MC_VERSION + "  |  Modrinth";
        Ui.d(g, note, wx + ww - 12 - Ui.w(note), wy + 10, alpha(0x647A6D, e), false);

        String[] tabs = {"Mods", "Resource packs", "PvP", "Shaders"};
        int tx = wx + 12, ty = wy + 28;
        int[] tw = {Ui.w(tabs[0]) + 20, Ui.w(tabs[1]) + 20, Ui.w(tabs[2]) + 20, Ui.w(tabs[3]) + 20};
        int[] tpos = {tx, tx + tw[0] + 6, tx + tw[0] + tw[1] + 12, tx + tw[0] + tw[1] + tw[2] + 18};
        for (int i = 0; i < 4; i++) {
            boolean hovered = mx >= tpos[i] && mx <= tpos[i] + tw[i] && my >= ty && my <= ty + 16;
            float a = Mth.clamp(1f - Math.abs(tabAnim - i), 0f, 1f);
            float h = hv("tab" + i, hovered, dt);
            rr(g, tpos[i], ty, tw[i], 16, 4, alpha(mix(mix(0x0F1712, 0x141F19, h), mix(0x111A15, acc, 0.3f), a), e));
            Ui.d(g, tabs[i], tpos[i] + 10, ty + 4, alpha(mix(0xA9BDB2, 0xFFFFFF, Math.max(a, h * 0.6f)), e), false);
            hits.add(new Hit(tpos[i], ty, tw[i], 16, K_TAB, null, i));
        }

        // list
        List<Item> items = tab == 0 ? MODS_L : tab == 1 ? PACKS_L : tab == 2 ? PVP_L : SHADERS_L;
        listTop = wy + 52;
        listBot = wy + wh - 34;
        int rowH = 40, gap = 4;
        int rx = wx + 12, rw = ww - 24;
        int content = items.size() * (rowH + gap);
        scrollT = Mth.clamp(scrollT, 0f, Math.max(0, content - (listBot - listTop)));
        scroll = Ui.approach(scroll, scrollT, dt, 14f);

        g.enableScissor(wx, listTop, wx + ww, listBot);
        for (int i = 0; i < items.size(); i++) {
            Item it = items.get(i);
            int y = listTop + i * (rowH + gap) - Math.round(scroll);
            if (y + rowH < listTop || y > listBot) continue;
            boolean inst = installed(it);
            boolean rowHover = mx >= rx && mx <= rx + rw && my >= Math.max(y, listTop) && my <= Math.min(y + rowH, listBot);
            float h = hv(it, rowHover, dt);
            rr(g, rx, y, rw, rowH, 5, alpha(mix(mix(0x101813, 0x151F19, h), acc, inst ? 0.06f : 0f), 0.98f * e));
            if (inst) rr(g, rx, y + 6, 2, rowH - 12, 1, alpha(acc, e));

            int bw = 74;
            Ui.dt(g, it.name, rx + 10, y + 5, alpha(0xFFFFFF, e), false);
            String st = it.status;
            if (!st.isEmpty()) {
                int col = st.startsWith("Ошибка") ? 0xFF7A7A : (it.busy ? 0xFFD98A : acc);
                Ui.d(g, st, rx + rw - bw - 16 - Ui.w(st), y + 6, alpha(col, e), false);
            }
            List<String> lines = Ui.wrap(it.desc, rw - bw - 34);
            for (int k = 0; k < Math.min(2, lines.size()); k++) {
                Ui.d(g, lines.get(k), rx + 10, y + 18 + k * 10, alpha(0x7C9A8A, e), false);
            }

            String label;
            boolean enabled;
            if (it.busy) { label = "..."; enabled = false; }
            else if (!it.pack) { label = inst ? "Installed" : "Install"; enabled = !inst; }
            else if (it.shader) { label = inst ? "Installed" : "Download"; enabled = !inst; }
            else if (!inst) { label = it.local != null ? "Install" : "Download"; enabled = true; }
            else if (packEnabled(it)) { label = "Enabled"; enabled = false; }
            else { label = "Enable"; enabled = true; }
            int bx = rx + rw - bw - 8, by = y + rowH / 2 - 8;
            boolean bh = mx >= bx && mx <= bx + bw && my >= Math.max(by, listTop) && my <= Math.min(by + 16, listBot);
            button(g, bx, by, bw, 16, label, bh, "b" + it.slug, dt, e, acc, enabled);
            if (enabled && by + 16 > listTop && by < listBot) hits.add(new Hit(bx, by, bw, 16, K_ITEM, it, 0));
        }
        g.disableScissor();

        // bottom bar
        int by = wy + wh - 26;
        int bx = wx + 12;
        if (tab == 0) {
            String all = "Install optimization pack";
            int w = Ui.w(all) + 24;
            button(g, bx, by, w, 18, all, mx >= bx && mx <= bx + w && my >= by && my <= by + 18, "all", dt, e, acc, true);
            hits.add(new Hit(bx, by, w, 18, K_ALL, null, 0));
            bx += w + 6;
        }
        String folder = "Open folder";
        int fw = Ui.w(folder) + 24;
        button(g, bx, by, fw, 18, folder, mx >= bx && mx <= bx + fw && my >= by && my <= by + 18, "folder", dt, e, acc, true);
        hits.add(new Hit(bx, by, fw, 18, K_FOLDER, null, 0));

        String back = "Back";
        int bw2 = Ui.w(back) + 30;
        int bbx = wx + ww - 12 - bw2;
        button(g, bbx, by, bw2, 18, back, mx >= bbx && mx <= bbx + bw2 && my >= by && my <= by + 18, "back", dt, e, acc, true);
        hits.add(new Hit(bbx, by, bw2, 18, K_BACK, null, 0));

        String hint = tab == 0 ? "Моды заработают после перезапуска игры"
            : tab == 1 ? "После скачивания нажми Enable" : tab == 2 ? "Install, потом Enable"
            : "Нужен Iris. Выбор: Настройки > Видео > Шейдеры";
        Ui.d(g, hint, wx + ww - 12 - Ui.w(hint), wy + 32, alpha(0x4C5F54, e), false);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int btn) {
        if (btn == 0) {
            for (Hit h : hits) {
                if (!h.in(mx, my)) continue;
                switch (h.kind()) {
                    case K_TAB -> { tab = h.idx(); scrollT = 0; scroll = 0; }
                    case K_ITEM -> {
                        if (my < listTop || my > listBot) continue;
                        Item it = h.item();
                        if (!installed(it)) install(it);
                        else if (it.pack) enablePack(it);
                    }
                    case K_ALL -> {
                        for (int i = 0; i < OPT_COUNT; i++) install(MODS_L.get(i));
                    }
                    case K_FOLDER -> {
                        try {
                            Path dir = tab == 0 ? modsDir() : tab == 3 ? shadersDir() : packsDir();
                            Files.createDirectories(dir);
                            Util.getPlatform().openUri(dir.toUri());
                        } catch (IOException | RuntimeException ignored) {
                        }
                    }
                    default -> onClose();
                }
                return true;
            }
        }
        return super.mouseClicked(mx, my, btn);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double sx, double sy) {
        scrollT -= (float) (sy * 30.0);
        return true;
    }

    @Override
    public void onClose() {
        minecraft.setScreen(parent);
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
