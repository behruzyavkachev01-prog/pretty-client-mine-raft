package com.pretty.client.mixin;

import com.pretty.client.Hooks;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.entity.EntityRenderDispatcher;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** CrowdBoost: in a crowd only the nearest players (and far items) are rendered. */
@Mixin(EntityRenderDispatcher.class)
public class EntityRenderDispatcherMixin {
    @Inject(method = "shouldRender(Lnet/minecraft/world/entity/Entity;Lnet/minecraft/client/renderer/culling/Frustum;DDD)Z",
        at = @At("HEAD"), cancellable = true)
    private void pretty$cull(Entity e, Frustum f, double x, double y, double z, CallbackInfoReturnable<Boolean> cir) {
        if (Hooks.cullEntity(e)) cir.setReturnValue(false);
    }
}
