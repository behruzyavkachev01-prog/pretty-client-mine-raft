package com.pretty.client;

import com.mojang.blaze3d.platform.InputConstants;
import java.awt.Color;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.OptionInstance;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.ItemTags;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import org.lwjgl.glfw.GLFW;

/**
 * PrettyClient core: settings, module registry, config, events, draw helpers.
 * Modules: Modules.java | World ESP: WorldRender.java | HUD: Hud.java | ClickGUI: Gui.java
 * Fabric, Minecraft 1.21.4 (Mojang mappings). Right Shift = ClickGUI. C = zoom.
 */
public class PrettyClient implements ClientModInitializer {

    static long lastCritAt;

    // =====================================================================
    //  Settings and modules
    // =====================================================================
    static abstract class Setting {
        final String name;
        Setting(String name) { this.name = name; }
    }

    static final class Bool extends Setting {
        boolean v;
        Bool(String name, boolean v) { super(name); this.v = v; }
    }

    static final class Num extends Setting {
        final double min, max, step;
        double v;
        double shown = Double.NaN;
        String[] labels;   // optional: shown instead of the number (index = value)
        Num(String name, double min, double max, double v, double step) {
            super(name); this.min = min; this.max = max; this.v = v; this.step = step;
        }
        Num labels(String... l) { this.labels = l; return this; }
    }

    enum Cat {
        COMBAT("Combat"), MOVEMENT("Movement"), PLAYER("Player"), RENDER("Render"),
        HUD("HUD"), VISUAL("Visual"), PERF("Performance"), OTHER("Other");
        final String label;
        boolean collapsed;
        Cat(String label) { this.label = label; }
    }

    interface Tick { void run(Minecraft mc, Mod m); }

    static final class Mod {
        final String name;
        final Cat cat;
        final List<Setting> settings = new ArrayList<>();
        boolean enabled, expanded;
        float anim, expandAnim, hov;
        String desc = "";
        int key = -1;
        boolean keyWasDown;
        double acc;
        boolean action;
        Tick tickFn, offFn, startFn;

        Mod(String name, Cat cat) { this.name = name; this.cat = cat; }

        Mod with(Setting... s) { settings.addAll(List.of(s)); return this; }
        Mod tick(Tick t) { tickFn = t; return this; }
        Mod off(Tick t) { offFn = t; return this; }
        Mod start(Tick t) { startFn = t; return this; }
        Mod def() { enabled = true; anim = 1f; return this; }
        Mod d(String text) { desc = text; return this; }
        /** One-shot button: a key press runs startFn, the module never stays enabled. */
        Mod action() { action = true; return this; }

        void toggle() {
            if (action) {
                try { if (startFn != null) startFn.run(Minecraft.getInstance(), this); }
                catch (Throwable t) { System.err.println("[PrettyClient] " + name + ": " + t); }
                return;
            }
            enabled = !enabled;
            Minecraft mc = Minecraft.getInstance();
            try {
                if (enabled && startFn != null) startFn.run(mc, this);
                if (!enabled && offFn != null) offFn.run(mc, this);
            } catch (Throwable t) {
                System.err.println("[PrettyClient] " + name + ": " + t);
            }
            if (cat != Cat.HUD && on("Notifications")) NOTES.add(new Note(name, enabled, System.currentTimeMillis()));
            saveConfig();
        }

        boolean b(String n) {
            for (Setting s : settings) if (s instanceof Bool x && x.name.equals(n)) return x.v;
            return false;
        }

        double n(String n) {
            for (Setting s : settings) if (s instanceof Num x && x.name.equals(n)) return x.v;
            return 0;
        }
    }

    record Note(String text, boolean on, long at) {}

    static final List<Mod> MODS = new ArrayList<>();
    static final Map<String, Mod> BY_NAME = new HashMap<>();
    static final List<Note> NOTES = new ArrayList<>();

    static Mod add(Mod m) { MODS.add(m); BY_NAME.put(m.name, m); return m; }
    /** config/<name> (one helper instead of three copies in AuctionHelper / ServerHelper / BaseFinder). */
    static java.nio.file.Path cfgFile(String name) {
        return net.fabricmc.loader.api.FabricLoader.getInstance().getConfigDir().resolve(name);
    }

    static Mod find(String name) { return BY_NAME.get(name); }
    static boolean on(String name) { Mod m = BY_NAME.get(name); return m != null && m.enabled; }

    // =====================================================================
    //  State
    // =====================================================================
    static KeyMapping guiKey, zoomKey;
    static boolean zooming = false;
    static double fovCur = -1;
    static int savedFov = 70;
    static long joinAt = -1;
    static int ticks = 0;
    static Mod theme;

    // combat / HUD state
    static LivingEntity target;
    static long targetAt;
    static float targetHpAnim = 1f;
    static int combo;
    static long comboAt;
    static double bps;
    static boolean wasAtk, wasUse;
    static final List<Long> CLICKS_L = new ArrayList<>();
    static final List<Long> CLICKS_R = new ArrayList<>();
    static final List<Vec3> CRUMBS = new ArrayList<>();

    // client options touched by Performance modules (restored on disable / exit)
    static final Map<String, Runnable> UNDO = new LinkedHashMap<>();

    static <T> void force(String key, OptionInstance<T> o, T v) {
        if (!UNDO.containsKey(key)) {
            final T old = o.get();
            UNDO.put(key, () -> { if (!o.get().equals(old)) o.set(old); });
        }
        if (!o.get().equals(v)) o.set(v);
    }

    static void restore(String key) {
        Runnable r = UNDO.remove(key);
        if (r != null) r.run();
    }

    // =====================================================================
    //  Entry point
    // =====================================================================
    @Override
    public void onInitializeClient() {
        Modules.register();
        Descs.apply();
        loadConfig();

        String cat = "PrettyClient";
        guiKey = KeyBindingHelper.registerKeyBinding(
            new KeyMapping("Open ClickGUI", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, cat));
        zoomKey = KeyBindingHelper.registerKeyBinding(
            new KeyMapping("Zoom (hold)", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_C, cat));

        ClientLifecycleEvents.CLIENT_STARTED.register(client -> AccountManager.applySaved());
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> joinAt = System.currentTimeMillis());
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> {
            for (Runnable r : new ArrayList<>(UNDO.values())) {
                try { r.run(); } catch (Throwable ignored) { }
            }
            UNDO.clear();
            saveConfig();
        });

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            if (mc.screen != null && mc.screen.getClass() == TitleScreen.class) mc.setScreen(new PrettyTitle());
            while (guiKey.consumeClick()) mc.setScreen(new Gui());
            handleZoom(mc);
            if (mc.player == null || mc.level == null) return;
            ticks++;
            ServerHelper.tick(mc);
            trackStats(mc);
            long win = mc.getWindow().getWindow();
            for (Mod m : MODS) {
                if (m.key >= 0 && mc.screen == null) {
                    boolean down = GLFW.glfwGetKey(win, m.key) == GLFW.GLFW_PRESS;
                    if (down && !m.keyWasDown) m.toggle();
                    m.keyWasDown = down;
                }
                if (m.enabled && m.tickFn != null) {
                    try {
                        m.tickFn.run(mc, m);
                    } catch (Throwable t) {
                        m.enabled = false;
                        System.err.println("[PrettyClient] " + m.name + " crashed and was disabled: " + t);
                    }
                }
            }
        });

        HudRenderCallback.EVENT.register(Hud::render);
        WorldRenderEvents.AFTER_TRANSLUCENT.register(WorldRender::render);

        AttackEntityCallback.EVENT.register((player, level, hand, entity, hit) -> {
            if (!level.isClientSide) return InteractionResult.PASS;
            long now = System.currentTimeMillis();
            if (entity instanceof LivingEntity le) {
                target = le;
                targetAt = now;
                combo++;
                comboAt = now;
            }
            if (on("AutoWeapon") && !player.getMainHandItem().is(ItemTags.SWORDS)) {
                var inv = player.getInventory();
                for (int i = 0; i < 9; i++) {
                    if (inv.getItem(i).is(ItemTags.SWORDS)) { inv.selected = i; break; }
                }
            }
            Mod crM = find("Criticals");
            if (crM != null && crM.enabled && player.onGround() && !player.isInWater() && !player.isInLava()
                && Minecraft.getInstance().getConnection() != null
                && (!crM.b("Only full charge") || player.getAttackStrengthScale(0.5f) >= 0.9f)
                && (!crM.b("Only standing") || player.getDeltaMovement().horizontalDistanceSqr() < 0.0009)
                && now - lastCritAt >= (long) crM.n("Cooldown ms")) {
                lastCritAt = now;
                var conn = Minecraft.getInstance().getConnection();
                double px = player.getX(), py = player.getY(), pz = player.getZ();
                conn.send(new ServerboundMovePlayerPacket.Pos(px, py + 0.0625, pz, false, false));
                conn.send(new ServerboundMovePlayerPacket.Pos(px, py, pz, false, false));
            }
            if (on("HitSounds")) {
                level.playLocalSound(player.getX(), player.getY(), player.getZ(), SoundEvents.EXPERIENCE_ORB_PICKUP,
                    SoundSource.PLAYERS, (float) find("HitSounds").n("Volume"), 1.25f, false);
            }
            if (on("CritSound")) Modules3.critSound(player, entity);
            if (on("WTap")) player.setSprinting(false);
            if (on("ShiftTap")) Modules3.shiftTicks = (int) find("ShiftTap").n("Ticks");
            if (on("HitEffects")) {
                for (int i = 0; i < 18; i++) {
                    level.addParticle(ParticleTypes.END_ROD,
                        entity.getX(), entity.getY() + entity.getBbHeight() * 0.5, entity.getZ(),
                        (Math.random() - 0.5) * 0.35, Math.random() * 0.35, (Math.random() - 0.5) * 0.35);
                }
            }
            if (on("CritParticles")) {
                for (int i = 0; i < 24; i++) {
                    level.addParticle(ParticleTypes.CRIT,
                        entity.getX(), entity.getY() + entity.getBbHeight() * 0.6, entity.getZ(),
                        (Math.random() - 0.5) * 0.8, Math.random() * 0.6, (Math.random() - 0.5) * 0.8);
                }
            }
            return InteractionResult.PASS;
        });
    }

    static void trackStats(Minecraft mc) {
        Player p = mc.player;
        long now = System.currentTimeMillis();

        double sp = Math.hypot(p.getX() - p.xo, p.getZ() - p.zo) * 20.0;
        bps += (sp - bps) * 0.2;

        boolean a = mc.options.keyAttack.isDown();
        if (a && !wasAtk) CLICKS_L.add(now);
        wasAtk = a;
        boolean u = mc.options.keyUse.isDown();
        if (u && !wasUse) CLICKS_R.add(now);
        wasUse = u;
        while (!CLICKS_L.isEmpty() && now - CLICKS_L.get(0) > 1000) CLICKS_L.remove(0);
        while (!CLICKS_R.isEmpty() && now - CLICKS_R.get(0) > 1000) CLICKS_R.remove(0);

        if (p.hurtTime > 0) combo = 0;
        if (combo > 0 && now - comboAt > 3000) combo = 0;

        Mod bc = find("Breadcrumbs");
        if (bc != null && bc.enabled) {
            if (ticks % 2 == 0) CRUMBS.add(p.position());
            int max = (int) bc.n("Length");
            while (CRUMBS.size() > max) CRUMBS.remove(0);
        } else if (!CRUMBS.isEmpty()) {
            CRUMBS.clear();
        }
    }

    static void handleZoom(Minecraft mc) {
        boolean down = zoomKey.isDown() && mc.screen == null && on("Zoom");
        if (down && !zooming) {
            savedFov = mc.options.fov().get();
            fovCur = savedFov;
            zooming = true;
        }
        if (zooming) {
            double target = down ? (find("Zoom") != null ? find("Zoom").n("FOV") : 25) : savedFov;
            fovCur += (target - fovCur) * 0.35;
            mc.options.fov().set((int) Math.round(fovCur));
            if (!down && Math.abs(fovCur - savedFov) < 0.6) {
                mc.options.fov().set(savedFov);
                zooming = false;
            }
        }
    }

    // =====================================================================
    //  Config (config/prettyclient.txt)
    // =====================================================================
    static Path cfgPath() {
        return FabricLoader.getInstance().getConfigDir().resolve("prettyclient.txt");
    }

    static void saveConfig() {
        try {
            StringBuilder sb = new StringBuilder();
            for (Mod m : MODS) {
                sb.append(m.name).append('|').append(m.enabled ? 1 : 0).append('|').append(m.key).append('|');
                boolean first = true;
                for (Setting s : m.settings) {
                    if (!first) sb.append(';');
                    first = false;
                    sb.append(s.name).append('=');
                    if (s instanceof Bool b) sb.append(b.v);
                    else if (s instanceof Num n) sb.append(n.v);
                }
                sb.append('\n');
            }
            Files.writeString(cfgPath(), sb.toString());
        } catch (IOException | RuntimeException ignored) {
        }
    }

    static void loadConfig() {
        try {
            Path p = cfgPath();
            if (!Files.exists(p)) return;
            for (String line : Files.readAllLines(p)) {
                String[] parts = line.split("\\|", -1);
                if (parts.length < 3) continue;
                Mod m = BY_NAME.get(parts[0]);
                if (m == null) continue;
                m.enabled = parts[1].equals("1");
                m.anim = m.enabled ? 1f : 0f;
                try { m.key = Integer.parseInt(parts[2]); } catch (NumberFormatException ignored) { }
                if (parts.length > 3 && !parts[3].isEmpty()) {
                    for (String kv : parts[3].split(";")) {
                        int i = kv.lastIndexOf('=');
                        if (i <= 0) continue;
                        String k = kv.substring(0, i), v = kv.substring(i + 1);
                        for (Setting s : m.settings) {
                            if (!s.name.equals(k)) continue;
                            if (s instanceof Bool b) b.v = v.equals("true");
                            else if (s instanceof Num n) {
                                try { n.v = Mth.clamp(Double.parseDouble(v), n.min, n.max); } catch (NumberFormatException ignored) { }
                            }
                        }
                    }
                }
            }
        } catch (IOException | RuntimeException ignored) {
        }
    }

    // =====================================================================
    //  Draw helpers
    // =====================================================================
    static int alpha(int rgb, float a) {
        return (Mth.clamp((int) (a * 255), 0, 255) << 24) | (rgb & 0xFFFFFF);
    }

    static int accent(float off) {
        float sat = 0.55f;
        double cyc = 6;
        boolean fixed = false;
        float hueFix = 0.75f;
        if (theme != null) {
            sat = (float) theme.n("Saturation");
            cyc = Math.max(1, theme.n("Cycle sec"));
            fixed = theme.b("Static");
            hueFix = (float) (theme.n("Hue") / 360.0);
        }
        long period = (long) (cyc * 1000);
        float hue = fixed ? hueFix + off * 0.15f : (System.currentTimeMillis() % period) / (float) period + off;
        hue = hue % 1f;
        if (hue < 0) hue += 1f;
        return Color.HSBtoRGB(hue, sat, 1f) & 0xFFFFFF;
    }

    static int mix(int a, int b, float t) {
        t = Mth.clamp(t, 0f, 1f);
        int r = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return (r << 16) | (g << 8) | bl;
    }

    static float ease(float t) {
        t = Mth.clamp(t, 0f, 1f);
        float u = 1 - t;
        return 1 - u * u * u;
    }

    static void rr(GuiGraphics g, int x, int y, int w, int h, int r, int color) {
        r = Math.min(r, Math.min(w, h) / 2);
        if (r < 1) { g.fill(x, y, x + w, y + h, color); return; }
        g.fill(x, y + r, x + w, y + h - r, color);
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int inset = r - (int) Math.round(Math.sqrt(r * r - dy * dy));
            g.fill(x + inset, y + i, x + w - inset, y + i + 1, color);
            g.fill(x + inset, y + h - i - 1, x + w - inset, y + h - i, color);
        }
    }
}
