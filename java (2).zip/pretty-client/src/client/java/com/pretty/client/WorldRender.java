package com.pretty.client;

import static com.pretty.client.PrettyClient.*;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.MeshData;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import java.util.ArrayList;
import java.util.List;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.renderer.CoreShaders;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.LightLayer;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.entity.AbstractFurnaceBlockEntity;
import net.minecraft.world.level.block.entity.BarrelBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.block.entity.DispenserBlockEntity;
import net.minecraft.world.level.block.entity.EnderChestBlockEntity;
import net.minecraft.world.level.block.entity.HopperBlockEntity;
import net.minecraft.world.level.block.entity.ShulkerBoxBlockEntity;
import net.minecraft.world.level.block.entity.SpawnerBlockEntity;
import net.minecraft.world.level.block.entity.TrappedChestBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.ChestType;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.status.ChunkStatus;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;

/** Everything drawn in the 3D world (through walls): boxes, lines, filled boxes and floating labels. */
final class WorldRender {
    private WorldRender() {}

    /** Line in camera-relative coordinates. */
    record Ln(float x1, float y1, float z1, float x2, float y2, float z2, int c, int a) {}
    /** Filled box in world coordinates. */
    record Fl(AABB a, int c, float al) {}
    /** Floating text in world coordinates. */
    record Lb(Vec3 p, String t, int c, float sc) {}

    record Store(AABB box, int c, String name) {}
    record Ore(BlockPos pos, int c, String name) {}

    static final List<Store> STORES = new ArrayList<>();
    static final List<Ore> ORES = new ArrayList<>();
    static int storeAt = -100, oreAt = -100;

    static final List<Ln> LN = new ArrayList<>();
    static final List<Fl> FL = new ArrayList<>();
    static final List<Lb> LB = new ArrayList<>();
    static double cx, cy, cz;

    // =====================================================================
    //  Main entry
    // =====================================================================
    static void render(WorldRenderContext ctx) {
        boolean fEsp = on("ESP"), fTr = on("Tracers"), fSt = on("StorageESP"), fIt = on("ItemESP"),
            fOre = on("OreESP"), fNt = on("Nametags"), fTj = on("Trajectories"), fBc = on("Breadcrumbs"),
            fCb = on("ChunkBorders"), fBh = on("BlockHighlight"), fPr = on("ProjectileESP"), fLl = on("LightLevel"),
            fTg = on("TargetEsp"), fHr = on("HitRange"), fCh = on("ChinaHat"),
            fBe = on("BlockESP"), fDm = on("DamageIndicator"), fBf = on("BaseFinder");
        if (!(fBf || fBe || fDm || fTg || fHr || fCh || fEsp || fTr || fSt || fIt || fOre || fNt || fTj || fBc || fCb || fBh || fPr || fLl)) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null || ctx.matrixStack() == null) return;

        PoseStack ps = ctx.matrixStack();
        Vec3 cam = ctx.camera().getPosition();
        cx = cam.x; cy = cam.y; cz = cam.z;
        float pt = mc.getDeltaTracker().getGameTimeDeltaPartialTick(false);
        LN.clear(); FL.clear(); LB.clear();
        extras(mc, pt, fTg, fHr, fCh);
        if (fBe) blockEsp(mc, pt);
        if (fDm) damagePops(mc);
        if (fBf) BaseFinder.render(mc);

        // ---------------------------------------------------------- entities
        if (fEsp || fTr || fIt || fNt || fPr) {
            Mod em = find("ESP"), tm = find("Tracers"), im = find("ItemESP"), nm = find("Nametags"), pm = find("ProjectileESP");
            Vec3 look = new Vec3(ctx.camera().getLookVector());
            Vec3 start = cam.add(look.scale(0.3));
            for (Entity e : mc.level.entitiesForRendering()) {
                if (e == mc.player) continue;
                double dist = mc.player.distanceTo(e);
                boolean pl = e instanceof Player, mob = e instanceof Monster, an = e instanceof Animal;
                boolean cr = e.getType() == EntityType.END_CRYSTAL;
                if (e instanceof LivingEntity le0 && !le0.isAlive()) continue;
                AABB box = ibox(e, pt);

                if (fIt && e instanceof ItemEntity ie && dist <= im.n("Range")) {
                    AABB b = box.inflate(0.05);
                    boxL(b, 0xFFE066);
                    if (im.b("Fill")) FL.add(new Fl(b, 0xFFE066, 0.2f));
                    if (im.b("Labels")) {
                        ItemStack is = ie.getItem();
                        String txt = is.getHoverName().getString() + (is.getCount() > 1 ? " x" + is.getCount() : "");
                        LB.add(new Lb(new Vec3(b.getCenter().x, b.maxY + 0.35, b.getCenter().z), txt, 0xFFE066, 0.8f));
                    }
                }

                if (fPr && e instanceof Projectile && dist <= pm.n("Range") && e.getDeltaMovement().lengthSqr() > 0.004) {
                    int pc = e.getType() == EntityType.ENDER_PEARL ? 0xB266FF : 0xFFB03C;
                    AABB pb = box.inflate(0.1);
                    boxL(pb, pc);
                    if (pm.b("Fill")) FL.add(new Fl(pb, pc, 0.3f));
                }

                if (!(pl || mob || an || cr)) continue;
                int col = pl ? 0x55E6FF : mob ? 0xFF5555 : an ? 0x66FF66 : 0xFF66FF;
                if (pl && em != null && em.b("Health color") && e instanceof LivingEntity le) {
                    col = mix(0xFF3B3B, 0x40FF70, le.getHealth() / Math.max(1f, le.getMaxHealth()));
                }

                if (fEsp && dist <= em.n("Range")
                    && ((pl && em.b("Players")) || (mob && em.b("Mobs")) || (an && em.b("Animals")) || (cr && em.b("Crystals")))) {
                    boxL(box, col);
                    if (em.b("Fill")) FL.add(new Fl(box, col, 0.14f));
                }

                if (fTr && dist <= tm.n("Range") && ((pl && tm.b("Players")) || (mob && tm.b("Mobs")) || (an && tm.b("Animals")))) {
                    Vec3 mid = box.getCenter();
                    line(start.x, start.y, start.z, mid.x, mid.y, mid.z, col);
                }

                if (fNt && pl && dist <= nm.n("Range") && e instanceof LivingEntity le) {
                    StringBuilder sb = new StringBuilder(e.getName().getString());
                    if (nm.b("Health")) {
                        sb.append("  ").append(Math.round((le.getHealth() + le.getAbsorptionAmount()) * 10f) / 10f).append(" HP");
                    }
                    if (nm.b("Distance")) sb.append("  [").append(Math.round(dist)).append("m]");
                    int hc = mix(0xFF3B3B, 0x40FF70, le.getHealth() / Math.max(1f, le.getMaxHealth()));
                    LB.add(new Lb(new Vec3(box.getCenter().x, box.maxY + 0.75, box.getCenter().z), sb.toString(), hc, (float) nm.n("Size")));
                }
            }
        }

        // ------------------------------------------------------- storage ESP
        if (fSt) {
            Mod sm = find("StorageESP");
            if (ticks - storeAt >= 10) { scanStorage(mc, sm); storeAt = ticks; }
            double range = sm.n("Range");
            for (Store s : STORES) {
                Vec3 c = s.box.getCenter();
                double d = c.distanceTo(mc.player.position());
                if (d > range) continue;
                boxL(s.box, s.c);
                if (sm.b("Fill")) FL.add(new Fl(s.box, s.c, 0.2f));
                if (sm.b("Labels")) {
                    String txt = sm.b("Distance") ? s.name + " [" + Math.round(d) + "m]" : s.name;
                    LB.add(new Lb(new Vec3(c.x, s.box.maxY + 0.45, c.z), txt, s.c, (float) sm.n("Label size")));
                }
            }
        }

        // ------------------------------------------------------------ ore ESP
        if (fOre) {
            Mod om = find("OreESP");
            if (ticks - oreAt >= 30) { scanOres(mc, om); oreAt = ticks; }
            for (Ore o : ORES) {
                AABB b = new AABB(o.pos).inflate(0.003);
                boxL(b, o.c);
                if (om.b("Fill")) FL.add(new Fl(b, o.c, 0.25f));
                if (om.b("Labels")) LB.add(new Lb(b.getCenter().add(0, 0.8, 0), o.name, o.c, 0.7f));
            }
        }

        if (fLl) {
            Mod lm = find("LightLevel");
            if (ticks - lightAt >= 20) { scanLight(mc, lm); lightAt = ticks; }
            FL.addAll(LIGHT);
        }

        if (fTj) trajectory(mc, pt);

        if (fBh && mc.hitResult instanceof BlockHitResult bhr && bhr.getType() == HitResult.Type.BLOCK) {
            AABB b = new AABB(bhr.getBlockPos()).inflate(0.002);
            int c = accent(0f);
            Mod hm = find("BlockHighlight");
            boxLA(b, c, (int) (hm.n("Line opacity") * 255));
            if (hm.b("Fill")) FL.add(new Fl(b, c, (float) hm.n("Fill opacity")));
        }

        if (fBc && CRUMBS.size() > 1) {
            for (int i = 1; i < CRUMBS.size(); i++) {
                Vec3 a = CRUMBS.get(i - 1), b = CRUMBS.get(i);
                line(a.x, a.y + 0.05, a.z, b.x, b.y + 0.05, b.z, accent(i * 0.008f));
            }
        }

        if (fCb) chunkBorders(mc);

        if (LN.isEmpty() && FL.isEmpty() && LB.isEmpty()) return;

        // ------------------------------------------------------------- draw
        Matrix4f m = ps.last().pose();
        RenderSystem.disableDepthTest();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();

        if (!FL.isEmpty()) {
            RenderSystem.disableCull();
            RenderSystem.setShader(CoreShaders.POSITION_COLOR);
            BufferBuilder q = Tesselator.getInstance().begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_COLOR);
            for (Fl f : FL) {
                AABB a = f.a;
                fillBox(q, m, (float) (a.minX - cx), (float) (a.minY - cy), (float) (a.minZ - cz),
                    (float) (a.maxX - cx), (float) (a.maxY - cy), (float) (a.maxZ - cz),
                    (f.c >> 16) & 255, (f.c >> 8) & 255, f.c & 255, (int) (f.al * 255));
            }
            MeshData md = q.build();
            if (md != null) BufferUploader.drawWithShader(md);
            RenderSystem.enableCull();
        }

        if (!LN.isEmpty()) {
            RenderSystem.setShader(CoreShaders.POSITION_COLOR);
            RenderSystem.lineWidth(2.0f);
            BufferBuilder b = Tesselator.getInstance().begin(VertexFormat.Mode.DEBUG_LINES, DefaultVertexFormat.POSITION_COLOR);
            for (Ln l : LN) {
                int r = (l.c >> 16) & 255, g = (l.c >> 8) & 255, bl = l.c & 255;
                b.addVertex(m, l.x1, l.y1, l.z1).setColor(r, g, bl, l.a);
                b.addVertex(m, l.x2, l.y2, l.z2).setColor(r, g, bl, l.a);
            }
            MeshData md = b.build();
            if (md != null) BufferUploader.drawWithShader(md);
            RenderSystem.lineWidth(1.0f);
        }

        if (!LB.isEmpty()) {
            Font font = mc.font;
            var buf = mc.renderBuffers().bufferSource();
            for (Lb l : LB) {
                double dx = l.p.x - cx, dy = l.p.y - cy, dz = l.p.z - cz;
                double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
                if (dist > 260) continue;
                float s = (float) Math.max(0.016, 0.0042 * dist) * l.sc;
                ps.pushPose();
                ps.translate(dx, dy, dz);
                ps.mulPose(ctx.camera().rotation());
                ps.scale(-s, -s, s);
                float w = font.width(l.t);
                font.drawInBatch(l.t, -w / 2f, 0f, 0xFF000000 | l.c, false, ps.last().pose(), buf,
                    Font.DisplayMode.SEE_THROUGH, 0x77000000, 15728880);
                ps.popPose();
            }
            buf.endBatch();
        }

        RenderSystem.enableDepthTest();
        RenderSystem.disableBlend();
    }

    // =====================================================================
    //  Scanners (cached, refreshed every N ticks)
    // =====================================================================
    static void scanStorage(Minecraft mc, Mod sm) {
        List<Store> out = new ArrayList<>();
        ChunkPos cp = mc.player.chunkPosition();
        int R = (int) Math.min(10, Math.ceil(sm.n("Range") / 16.0) + 1);
        for (int x = cp.x - R; x <= cp.x + R; x++) {
            for (int z = cp.z - R; z <= cp.z + R; z++) {
                ChunkAccess ca = mc.level.getChunk(x, z, ChunkStatus.FULL, false);
                if (!(ca instanceof LevelChunk chunk)) continue;
                for (BlockEntity be : chunk.getBlockEntities().values()) {
                    BlockPos pos = be.getBlockPos();
                    BlockState bs = be.getBlockState();
                    AABB box = new AABB(pos);
                    String name;
                    int c;
                    if (be instanceof EnderChestBlockEntity) {
                        if (!sm.b("Ender")) continue;
                        name = "Ender Chest"; c = 0xB266FF;
                    } else if (be instanceof ChestBlockEntity) {
                        if (!sm.b("Chests")) continue;
                        boolean trapped = be instanceof TrappedChestBlockEntity;
                        name = trapped ? "Trapped Chest" : "Chest";
                        c = trapped ? 0xFF4646 : 0xFFD23C;
                        if (bs.hasProperty(ChestBlock.TYPE)) {
                            ChestType t = bs.getValue(ChestBlock.TYPE);
                            if (t == ChestType.LEFT) continue;
                            if (t == ChestType.RIGHT) {
                                BlockPos other = pos.relative(ChestBlock.getConnectedDirection(bs));
                                box = box.minmax(new AABB(other));
                                name = "Double " + name;
                            }
                        }
                    } else if (be instanceof ShulkerBoxBlockEntity) {
                        if (!sm.b("Shulkers")) continue;
                        name = "Shulker"; c = 0xFF69DC;
                    } else if (be instanceof BarrelBlockEntity) {
                        if (!sm.b("Barrels")) continue;
                        name = "Barrel"; c = 0xE0823A;
                    } else if (be instanceof HopperBlockEntity) {
                        if (!sm.b("Hoppers")) continue;
                        name = "Hopper"; c = 0xB0B0B0;
                    } else if (be instanceof AbstractFurnaceBlockEntity) {
                        if (!sm.b("Furnaces")) continue;
                        name = "Furnace"; c = 0xC0C0C0;
                    } else if (be instanceof DispenserBlockEntity) {
                        if (!sm.b("Dispensers")) continue;
                        name = "Dispenser/Dropper"; c = 0x9AA5B5;
                    } else if (be instanceof SpawnerBlockEntity) {
                        if (!sm.b("Spawners")) continue;
                        name = "Spawner"; c = 0x55FF55;
                    } else {
                        continue;
                    }
                    out.add(new Store(box, c, name));
                }
            }
        }
        STORES.clear();
        STORES.addAll(out);
    }

    static final List<Fl> LIGHT = new ArrayList<>();
    static int lightAt = -100;

    /** Marks floor tiles with block light 0: red = spawnable any time, yellow = spawnable at night. */
    static void scanLight(Minecraft mc, Mod lm) {
        List<Fl> out = new ArrayList<>();
        int R = (int) lm.n("Range");
        boolean night = lm.b("Night spawns");
        BlockPos c = mc.player.blockPosition();
        BlockPos.MutableBlockPos mp = new BlockPos.MutableBlockPos(), mb = new BlockPos.MutableBlockPos();
        outer:
        for (int x = c.getX() - R; x <= c.getX() + R; x++) {
            for (int z = c.getZ() - R; z <= c.getZ() + R; z++) {
                for (int y = c.getY() - 4; y <= c.getY() + 3; y++) {
                    mp.set(x, y, z);
                    if (!mc.level.getBlockState(mp).isAir()) continue;
                    mb.set(x, y - 1, z);
                    BlockState below = mc.level.getBlockState(mb);
                    if (!below.isFaceSturdy(mc.level, mb, Direction.UP)) continue;
                    if (mc.level.getBrightness(LightLayer.BLOCK, mp) > 0) continue;
                    int sky = mc.level.getBrightness(LightLayer.SKY, mp);
                    if (sky > 0 && !night) continue;
                    int col = sky == 0 ? 0xFF4040 : 0xFFD23C;
                    out.add(new Fl(new AABB(x + 0.12, y + 0.02, z + 0.12, x + 0.88, y + 0.06, z + 0.88), col, 0.5f));
                    if (out.size() >= 1800) break outer;
                }
            }
        }
        LIGHT.clear();
        LIGHT.addAll(out);
    }

    static void scanOres(Minecraft mc, Mod om) {
        List<Ore> out = new ArrayList<>();
        int R = (int) om.n("Range");
        BlockPos c = mc.player.blockPosition();
        BlockPos.MutableBlockPos mp = new BlockPos.MutableBlockPos();
        boolean dia = om.b("Diamond"), anc = om.b("Ancient Debris"), eme = om.b("Emerald"), gld = om.b("Gold"),
            irn = om.b("Iron"), cop = om.b("Copper"), lap = om.b("Lapis"), red = om.b("Redstone"), coa = om.b("Coal");
        for (int x = c.getX() - R; x <= c.getX() + R; x++) {
            for (int y = c.getY() - R; y <= c.getY() + R; y++) {
                for (int z = c.getZ() - R; z <= c.getZ() + R; z++) {
                    mp.set(x, y, z);
                    BlockState s = mc.level.getBlockState(mp);
                    if (s.isAir()) continue;
                    int col;
                    String nm;
                    if (dia && s.is(BlockTags.DIAMOND_ORES)) { col = 0x4DEBFF; nm = "Diamond"; }
                    else if (anc && s.is(Blocks.ANCIENT_DEBRIS)) { col = 0xFF8A3D; nm = "Ancient Debris"; }
                    else if (eme && s.is(BlockTags.EMERALD_ORES)) { col = 0x2EFF6A; nm = "Emerald"; }
                    else if (gld && s.is(BlockTags.GOLD_ORES)) { col = 0xFFE13A; nm = "Gold"; }
                    else if (irn && s.is(BlockTags.IRON_ORES)) { col = 0xE6C3A8; nm = "Iron"; }
                    else if (cop && s.is(BlockTags.COPPER_ORES)) { col = 0xE8834D; nm = "Copper"; }
                    else if (lap && s.is(BlockTags.LAPIS_ORES)) { col = 0x4466FF; nm = "Lapis"; }
                    else if (red && s.is(BlockTags.REDSTONE_ORES)) { col = 0xFF3333; nm = "Redstone"; }
                    else if (coa && s.is(BlockTags.COAL_ORES)) { col = 0x9A9A9A; nm = "Coal"; }
                    else continue;
                    out.add(new Ore(mp.immutable(), col, nm));
                    if (out.size() >= 600) break;
                }
            }
        }
        ORES.clear();
        ORES.addAll(out);
    }

    // =====================================================================
    //  Trajectory prediction (bow, pearls, snowballs, eggs, potions)
    // =====================================================================
    static boolean throwable(ItemStack s) {
        return s.is(Items.ENDER_PEARL) || s.is(Items.SNOWBALL) || s.is(Items.EGG)
            || s.is(Items.SPLASH_POTION) || s.is(Items.LINGERING_POTION);
    }

    static void trajectory(Minecraft mc, float pt) {
        Player p = mc.player;
        double speed, grav;
        if (p.isUsingItem() && p.getUseItem().is(Items.BOW)) {
            float f = p.getTicksUsingItem() / 20f;
            f = (f * f + f * 2f) / 3f;
            if (f < 0.1f) return;
            if (f > 1f) f = 1f;
            speed = f * 3.0;
            grav = 0.05;
        } else {
            ItemStack h = p.getMainHandItem();
            if (!throwable(h)) h = p.getOffhandItem();
            if (!throwable(h)) return;
            boolean potion = h.is(Items.SPLASH_POTION) || h.is(Items.LINGERING_POTION);
            speed = potion ? 0.5 : 1.5;
            grav = potion ? 0.05 : 0.03;
        }
        Vec3 prev = p.getEyePosition(pt).add(0, -0.1, 0);
        Vec3 vel = p.getViewVector(pt).scale(speed);
        for (int i = 0; i < 200; i++) {
            Vec3 next = prev.add(vel);
            BlockHitResult hr = mc.level.clip(new ClipContext(prev, next, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
            boolean hit = hr.getType() != HitResult.Type.MISS;
            Vec3 end = hit ? hr.getLocation() : next;
            line(prev.x, prev.y, prev.z, end.x, end.y, end.z, accent(i * 0.006f));
            if (hit) {
                FL.add(new Fl(new AABB(end.x - 0.25, end.y - 0.25, end.z - 0.25, end.x + 0.25, end.y + 0.25, end.z + 0.25), 0xFF4040, 0.55f));
                break;
            }
            prev = next;
            vel = vel.scale(0.99).add(0, -grav, 0);
            if (prev.y < -100) break;
        }
    }

    static void chunkBorders(Minecraft mc) {
        ChunkPos cp = mc.player.chunkPosition();
        double y = mc.player.getY();
        double y1 = y - 24, y2 = y + 24;
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                int x0 = (cp.x + dx) * 16, z0 = (cp.z + dz) * 16, x1 = x0 + 16, z1 = z0 + 16;
                int col = (dx == 0 && dz == 0) ? 0xFFE066 : 0x6A6A88;
                line(x0, y1, z0, x0, y2, z0, col);
                line(x1, y1, z0, x1, y2, z0, col);
                line(x1, y1, z1, x1, y2, z1, col);
                line(x0, y1, z1, x0, y2, z1, col);
                if (dx == 0 && dz == 0) {
                    double base = Math.floor(y / 16.0) * 16.0;
                    for (int k = 0; k <= 1; k++) {
                        double yy = base + k * 16;
                        line(x0, yy, z0, x1, yy, z0, 0x55E6FF);
                        line(x1, yy, z0, x1, yy, z1, 0x55E6FF);
                        line(x1, yy, z1, x0, yy, z1, 0x55E6FF);
                        line(x0, yy, z1, x0, yy, z0, 0x55E6FF);
                    }
                }
            }
        }
    }

    // =====================================================================
    //  Geometry helpers
    // =====================================================================
    /** Entity bounding box interpolated with the partial tick. */
    static AABB ibox(Entity e, float pt) {
        double ix = Mth.lerp(pt, e.xo, e.getX()) - e.getX();
        double iy = Mth.lerp(pt, e.yo, e.getY()) - e.getY();
        double iz = Mth.lerp(pt, e.zo, e.getZ()) - e.getZ();
        return e.getBoundingBox().move(ix, iy, iz);
    }

    static void line(double x1, double y1, double z1, double x2, double y2, double z2, int c) {
        lineA(x1, y1, z1, x2, y2, z2, c, 255);
    }

    static void lineA(double x1, double y1, double z1, double x2, double y2, double z2, int c, int a) {
        LN.add(new Ln((float) (x1 - cx), (float) (y1 - cy), (float) (z1 - cz),
            (float) (x2 - cx), (float) (y2 - cy), (float) (z2 - cz), c, a));
    }

    /** Box outline with its own opacity (0..255). */
    static void boxLA(AABB a, int c, int al) {
        double x1 = a.minX, y1 = a.minY, z1 = a.minZ, x2 = a.maxX, y2 = a.maxY, z2 = a.maxZ;
        lineA(x1, y1, z1, x2, y1, z1, c, al); lineA(x2, y1, z1, x2, y1, z2, c, al);
        lineA(x2, y1, z2, x1, y1, z2, c, al); lineA(x1, y1, z2, x1, y1, z1, c, al);
        lineA(x1, y2, z1, x2, y2, z1, c, al); lineA(x2, y2, z1, x2, y2, z2, c, al);
        lineA(x2, y2, z2, x1, y2, z2, c, al); lineA(x1, y2, z2, x1, y2, z1, c, al);
        lineA(x1, y1, z1, x1, y2, z1, c, al); lineA(x2, y1, z1, x2, y2, z1, c, al);
        lineA(x2, y1, z2, x2, y2, z2, c, al); lineA(x1, y1, z2, x1, y2, z2, c, al);
    }

    static void boxL(AABB a, int c) {
        double x1 = a.minX, y1 = a.minY, z1 = a.minZ, x2 = a.maxX, y2 = a.maxY, z2 = a.maxZ;
        line(x1, y1, z1, x2, y1, z1, c); line(x2, y1, z1, x2, y1, z2, c);
        line(x2, y1, z2, x1, y1, z2, c); line(x1, y1, z2, x1, y1, z1, c);
        line(x1, y2, z1, x2, y2, z1, c); line(x2, y2, z1, x2, y2, z2, c);
        line(x2, y2, z2, x1, y2, z2, c); line(x1, y2, z2, x1, y2, z1, c);
        line(x1, y1, z1, x1, y2, z1, c); line(x2, y1, z1, x2, y2, z1, c);
        line(x2, y1, z2, x2, y2, z2, c); line(x1, y1, z2, x1, y2, z2, c);
    }

    static void v(BufferBuilder b, Matrix4f m, float x, float y, float z, int r, int g, int bl, int a) {
        b.addVertex(m, x, y, z).setColor(r, g, bl, a);
    }

    static void fillBox(BufferBuilder b, Matrix4f m, float x1, float y1, float z1, float x2, float y2, float z2,
                        int r, int g, int bl, int a) {
        v(b, m, x1, y1, z1, r, g, bl, a); v(b, m, x2, y1, z1, r, g, bl, a); v(b, m, x2, y1, z2, r, g, bl, a); v(b, m, x1, y1, z2, r, g, bl, a);
        v(b, m, x1, y2, z1, r, g, bl, a); v(b, m, x1, y2, z2, r, g, bl, a); v(b, m, x2, y2, z2, r, g, bl, a); v(b, m, x2, y2, z1, r, g, bl, a);
        v(b, m, x1, y1, z1, r, g, bl, a); v(b, m, x1, y2, z1, r, g, bl, a); v(b, m, x2, y2, z1, r, g, bl, a); v(b, m, x2, y1, z1, r, g, bl, a);
        v(b, m, x1, y1, z2, r, g, bl, a); v(b, m, x2, y1, z2, r, g, bl, a); v(b, m, x2, y2, z2, r, g, bl, a); v(b, m, x1, y2, z2, r, g, bl, a);
        v(b, m, x1, y1, z1, r, g, bl, a); v(b, m, x1, y1, z2, r, g, bl, a); v(b, m, x1, y2, z2, r, g, bl, a); v(b, m, x1, y2, z1, r, g, bl, a);
        v(b, m, x2, y1, z1, r, g, bl, a); v(b, m, x2, y2, z1, r, g, bl, a); v(b, m, x2, y2, z2, r, g, bl, a); v(b, m, x2, y1, z2, r, g, bl, a);
    }

    static void ring(double x, double y, double z, double r, int seg, int c) {
        for (int i = 0; i < seg; i++) {
            double a1 = i * Math.PI * 2 / seg, a2 = (i + 1) * Math.PI * 2 / seg;
            line(x + Math.cos(a1) * r, y, z + Math.sin(a1) * r, x + Math.cos(a2) * r, y, z + Math.sin(a2) * r, c);
        }
    }

    /** TargetEsp, HitRange and ChinaHat. */
    static void extras(Minecraft mc, float pt, boolean fTg, boolean fHr, boolean fCh) {
        Player p = mc.player;
        double px = Mth.lerp(pt, p.xo, p.getX()), py = Mth.lerp(pt, p.yo, p.getY()), pz = Mth.lerp(pt, p.zo, p.getZ());
        if (fHr) {
            double r = find("HitRange").n("Radius");
            boolean near = false;
            for (Entity e : mc.level.entitiesForRendering()) {
                if (e != p && e instanceof LivingEntity le && le.isAlive() && p.distanceTo(e) <= r) { near = true; break; }
            }
            ring(px, py + 0.05, pz, r, 48, near ? 0xFF4040 : accent(0f));
        }
        if (fTg) {
            Mod tm = find("TargetEsp");
            LivingEntity tEnt = null;
            if (tm.b("Crosshair") && mc.crosshairPickEntity instanceof LivingEntity ce && ce.isAlive() && ce != p) tEnt = ce;
            else if (target != null && target.isAlive() && System.currentTimeMillis() - targetAt < tm.n("Seconds") * 1000) tEnt = target;
            if (tEnt != null) {
                AABB b = ibox(tEnt, pt);
                if (tm.b("Box")) boxL(b, accent(0f));
                if (tm.b("Ring")) {
                    double t = (System.currentTimeMillis() % 2000) / 2000.0;
                    double h = (Math.sin(t * Math.PI * 2) * 0.5 + 0.5) * (b.maxY - b.minY);
                    Vec3 c = b.getCenter();
                    double rad = Math.max(b.maxX - b.minX, b.maxZ - b.minZ) * 0.8 + 0.2;
                    ring(c.x, b.minY + h, c.z, rad, 32, accent((float) t));
                }
                if (tm.b("Crystals")) crystals(b, (int) tm.n("Crystal count"));
            }
        }
        if (fCh && !mc.options.getCameraType().isFirstPerson()) {
            Mod hm = find("ChinaHat");
            double top = py + p.getBbHeight() + 0.02;
            double s = hm.n("Size");
            int seg = 24;
            for (int i = 0; i < seg; i++) {
                double a1 = i * Math.PI * 2 / seg, a2 = (i + 1) * Math.PI * 2 / seg;
                int c = hm.b("Rainbow") ? accent(i / (float) seg) : accent(0f);
                double x1 = px + Math.cos(a1) * s, z1 = pz + Math.sin(a1) * s;
                double x2 = px + Math.cos(a2) * s, z2 = pz + Math.sin(a2) * s;
                line(x1, top, z1, x2, top, z2, c);
                line(px, top + s * 0.45, pz, x1, top, z1, c);
            }
            ring(px, top + s * 0.22, pz, s * 0.5, 24, accent(0.5f));
        }
    }

    // ------------------------------------------------ orbiting crystals around a target
    static void crystals(AABB b, int n) {
        Vec3 c = b.getCenter();
        double h = b.maxY - b.minY, rad = Math.max(b.maxX - b.minX, b.maxZ - b.minZ) * 0.5 + 0.55;
        double t = (System.currentTimeMillis() % 100000) / 1000.0;
        for (int i = 0; i < n; i++) {
            double a = t * 1.8 + i * Math.PI * 2 / n;
            double y = b.minY + h * 0.5 + Math.sin(t * 2.4 + i * 1.3) * h * 0.32;
            crystal(c.x + Math.cos(a) * rad, y, c.z + Math.sin(a) * rad, 0.16 + 0.04 * Math.sin(t * 3 + i), t * 3 + i, accent(i / (float) n));
        }
    }

    static void crystal(double x, double y, double z, double s, double spin, int col) {
        double h = s * 1.5;
        double[] px = new double[4], pz = new double[4];
        for (int k = 0; k < 4; k++) {
            double a = spin + k * Math.PI / 2;
            px[k] = x + Math.cos(a) * s;
            pz[k] = z + Math.sin(a) * s;
        }
        for (int k = 0; k < 4; k++) {
            int k2 = (k + 1) % 4;
            line(px[k], y, pz[k], px[k2], y, pz[k2], col);
            line(x, y + h, z, px[k], y, pz[k], col);
            line(x, y - h, z, px[k], y, pz[k], col);
        }
        FL.add(new Fl(new AABB(x - s * 0.35, y - h * 0.45, z - s * 0.35, x + s * 0.35, y + h * 0.45, z + s * 0.35), col, 0.45f));
    }

    // ------------------------------------------------------------------ BlockESP
    static void blockEsp(Minecraft mc, float pt) {
        Mod bm = find("BlockESP");
        HitResult hr = mc.player.pick(bm.n("Range"), pt, false);
        if (hr.getType() != HitResult.Type.BLOCK || !(hr instanceof BlockHitResult bhr)) return;
        BlockPos pos = bhr.getBlockPos();
        var st = mc.level.getBlockState(pos);
        if (st.isAir()) return;
        double pulse = bm.b("Pulse") ? 0.5 + 0.5 * Math.sin(System.currentTimeMillis() / 220.0) : 1.0;
        int col = accent(0f);
        AABB b = new AABB(pos).inflate(0.003 + 0.006 * pulse);
        boxL(b, col);
        if (bm.b("Fill")) FL.add(new Fl(b, col, (float) (0.12 + 0.16 * pulse)));
        double x1 = b.minX, y1 = b.minY, z1 = b.minZ, x2 = b.maxX, y2 = b.maxY, z2 = b.maxZ;
        net.minecraft.core.Direction d = bhr.getDirection();
        switch (d) {
            case UP -> y1 = y2 - 0.02;
            case DOWN -> y2 = y1 + 0.02;
            case EAST -> x1 = x2 - 0.02;
            case WEST -> x2 = x1 + 0.02;
            case SOUTH -> z1 = z2 - 0.02;
            case NORTH -> z2 = z1 + 0.02;
        }
        FL.add(new Fl(new AABB(x1, y1, z1, x2, y2, z2), mix(col, 0xFFFFFF, 0.4f), 0.5f));
        if (bm.b("Label")) {
            Vec3 c = Vec3.atCenterOf(pos);
            String txt = st.getBlock().getName().getString() + "  [" + Math.round(mc.player.getEyePosition().distanceTo(c)) + "m]";
            LB.add(new Lb(c.add(0, 0.95, 0), txt, col, 0.8f));
        }
    }

    // --------------------------------------------------------- damage indicator
    record Pop(Vec3 p, String t, int c, long at) {}
    static final java.util.Map<Integer, Float> HP = new java.util.HashMap<>();
    static final List<Pop> POPS = new ArrayList<>();

    static void damagePops(Minecraft mc) {
        long now = System.currentTimeMillis();
        double range = find("DamageIndicator").n("Range");
        for (Entity e : mc.level.entitiesForRendering()) {
            if (!(e instanceof LivingEntity le) || e == mc.player || mc.player.distanceTo(e) > range) continue;
            float hp = le.getHealth();
            Float old = HP.put(e.getId(), hp);
            if (old != null && Math.abs(old - hp) >= 0.5f) {
                boolean dmg = hp < old;
                POPS.add(new Pop(new Vec3(e.getX() + (Math.random() - 0.5) * 0.6, e.getY() + e.getBbHeight() + 0.2, e.getZ() + (Math.random() - 0.5) * 0.6),
                    (dmg ? "-" : "+") + String.format("%.1f", Math.abs(old - hp)), dmg ? 0xFF5555 : 0x55FF77, now));
            }
        }
        if (HP.size() > 400) HP.clear();
        POPS.removeIf(pp -> now - pp.at() > 1200);
        for (Pop pp : POPS) {
            double k = (now - pp.at()) / 1200.0;
            LB.add(new Lb(pp.p().add(0, k * 0.9, 0), pp.t(), pp.c(), (float) (1.0 - k * 0.3)));
        }
    }
}
