package com.pretty.client;

import static com.pretty.client.PrettyClient.*;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.ClickEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.AbstractFurnaceBlockEntity;
import net.minecraft.world.level.block.entity.BarrelBlockEntity;
import net.minecraft.world.level.block.entity.BeaconBlockEntity;
import net.minecraft.world.level.block.entity.BedBlockEntity;
import net.minecraft.world.level.block.entity.BellBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BrewingStandBlockEntity;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.block.entity.CrafterBlockEntity;
import net.minecraft.world.level.block.entity.DispenserBlockEntity;
import net.minecraft.world.level.block.entity.EnchantingTableBlockEntity;
import net.minecraft.world.level.block.entity.EnderChestBlockEntity;
import net.minecraft.world.level.block.entity.HopperBlockEntity;
import net.minecraft.world.level.block.entity.LecternBlockEntity;
import net.minecraft.world.level.block.entity.ShulkerBoxBlockEntity;
import net.minecraft.world.level.block.entity.SignBlockEntity;
import net.minecraft.world.level.block.entity.SpawnerBlockEntity;
import net.minecraft.world.level.block.entity.TrappedChestBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;
import net.minecraft.world.level.chunk.status.ChunkStatus;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * BaseFinder: looks for player bases in the chunks the server has already sent you (no extra packets).
 *
 *  - scores every loaded chunk: containers, furnaces, beds, shulkers, ender chests, beacons, enchanting tables ...
 *    (a mix of different things scores higher than a pile of one thing) plus "unnatural" blocks (planks, glass,
 *    concrete, redstone parts, storage blocks)
 *  - merges neighbouring chunks into one base, so a big base is ONE result with a combined score
 *  - villages are damped (villagers nearby), single natural chests do not reach the threshold
 *  - a found base is written only to YOUR chat (local, nobody else sees it, nothing is sent to the server),
 *    saved to config/prettybases.txt, drawn through walls with a tracer and shown in the HUD
 *  - if Xaero's Minimap is installed the chat line gets a clickable waypoint link
 */
final class BaseFinder {
    private BaseFinder() {}

    static final class CI {
        final int cx, cz;
        final long key;
        double score, ev, sx, sy, sz, sw, blockW, strongW;
        boolean bell;
        double miny = 1e9, maxy = -1e9;
        long at;
        final int[] cnt = new int[8];

        CI(int cx, int cz) { this.cx = cx; this.cz = cz; this.key = key(cx, cz); }

        void hot(double x, double y, double z, double w) {
            sx += x * w; sy += y * w; sz += z * w; sw += w;
            miny = Math.min(miny, y); maxy = Math.max(maxy, y);
        }
    }

    static final class Base {
        int id;
        String dim;
        double x, y, z, score;
        String info = "";
        AABB box;
    }

    static final Map<Long, CI> CHUNKS = new HashMap<>();
    static final List<Base> BASES = new ArrayList<>();
    static final List<Long> LIST = new ArrayList<>();
    static Object level;
    static int idx, listAt = -1000, clusterAt = -1000, nextId = 1;

    static long key(int cx, int cz) { return ((long) cx << 32) ^ (cz & 0xFFFFFFFFL); }

    static String dimName(Minecraft mc) {
        return mc.level.dimension().location().getPath();
    }

    static String serverKey(Minecraft mc) {
        var s = mc.getCurrentServer();
        return s == null ? "singleplayer" : s.ip.replace('|', '_');
    }

    static final String FILE_TAG = "#v2";

    static Path file() { return PrettyClient.cfgFile("prettybases.txt"); }

    // ------------------------------------------------------------------ block weights
    /** Blocks players build with and that practically never generate in the world (a few pistons in a jungle temple do not count). */
    static final Set<String> STRONG = Set.of("piston", "sticky_piston", "observer", "repeater", "comparator",
        "redstone_lamp", "redstone_block", "slime_block", "honey_block", "daylight_detector", "target",
        "iron_block", "diamond_block", "emerald_block", "netherite_block", "lapis_block", "beacon");
    /** Blocks that mark a GENERATED structure (mineshaft, dungeon, stronghold, ancient city, trial chamber, village roads ...). */
    static final Set<String> NATURAL = Set.of("cobweb", "rail", "powered_rail", "dirt_path", "mossy_cobblestone",
        "mossy_stone_bricks", "cracked_stone_bricks", "chiseled_stone_bricks", "infested_stone_bricks", "end_portal_frame",
        "reinforced_deepslate", "cracked_deepslate_bricks", "cracked_deepslate_tiles", "soul_lantern", "soul_fire",
        "hay_block", "bone_block", "magma_block", "gold_block", "chiseled_tuff_bricks", "tuff_bricks", "copper_bulb", "heavy_core",
        "vault", "trial_spawner", "spawner", "crying_obsidian", "blackstone", "gilded_blackstone", "polished_blackstone_bricks");
    /** weight: 4 = strong, 1 = weak (planks, glass ...), -1 = marker of a generated structure, 0 = ignored. */
    static final Map<Block, Integer> W = new IdentityHashMap<>();

    static int weight(BlockState s) {
        Block b = s.getBlock();
        Integer c = W.get(b);
        if (c != null) return c;
        String p = BuiltInRegistries.BLOCK.getKey(b).getPath();
        int w = 0;
        if (STRONG.contains(p)) w = 4;
        else if (NATURAL.contains(p) || p.startsWith("sculk")) w = -1;
        else if (p.endsWith("_planks") || p.endsWith("_wool") || p.endsWith("glass") || p.endsWith("glass_pane")
            || p.endsWith("_concrete") || p.equals("bricks") || p.equals("smooth_stone")
            || p.equals("quartz_block") || p.equals("sea_lantern")) w = 1;
        W.put(b, w);
        return w;
    }

    static boolean interesting(BlockState s) { return weight(s) != 0; }

    // kinds: 0 containers, 1 ender, 2 shulker, 3 furnace, 4 redstone/hopper, 5 bed, 6 special, 7 sign
    static final String[] KIND = {"containers", "ender chests", "shulkers", "furnaces", "hoppers/dispensers", "beds", "special", "signs"};

    static int[] classify(BlockEntity be, Mod m) {
        if (be instanceof EnderChestBlockEntity) return new int[] {3, 1};
        if (be instanceof TrappedChestBlockEntity) return new int[] {3, 0};
        if (be instanceof ChestBlockEntity || be instanceof BarrelBlockEntity) return new int[] {2, 0};
        if (be instanceof ShulkerBoxBlockEntity) return new int[] {5, 2};
        if (be instanceof AbstractFurnaceBlockEntity) return new int[] {2, 3};
        if (be instanceof HopperBlockEntity || be instanceof DispenserBlockEntity) return new int[] {2, 4};
        if (be instanceof CrafterBlockEntity) return new int[] {3, 4};
        if (be instanceof BedBlockEntity) return new int[] {3, 5};
        if (be instanceof BrewingStandBlockEntity) return new int[] {3, 6};
        if (be instanceof EnchantingTableBlockEntity) return new int[] {5, 6};
        if (be instanceof BeaconBlockEntity) return new int[] {12, 6};
        if (be instanceof LecternBlockEntity) return new int[] {2, 6};
        if (be instanceof BellBlockEntity) return new int[] {0, 6};
        if (be instanceof SignBlockEntity) return new int[] {1, 7};
        if (be instanceof SpawnerBlockEntity) return m.b("Count spawners") ? new int[] {3, 6} : null;
        return null;
    }

    // ------------------------------------------------------------------ scanning
    static void tick(Minecraft mc, Mod m) {
        if (mc.level != level) {
            level = mc.level;
            CHUNKS.clear(); BASES.clear(); LIST.clear();
            idx = 0; listAt = -1000; clusterAt = -1000;
            loadFile(mc);
        }
        if (ticks - listAt >= 100 || LIST.isEmpty()) rebuild(mc, m);
        int n = (int) m.n("Speed");
        for (int i = 0; i < n && !LIST.isEmpty(); i++) {
            if (idx >= LIST.size()) idx = 0;
            long k = LIST.get(idx++);
            int cx = (int) (k >> 32), cz = (int) k;
            CI old = CHUNKS.get(k);
            if (old != null && ticks - old.at < 1200) continue;
            scan(mc, m, cx, cz);
        }
        if (ticks - clusterAt >= 20) { cluster(mc, m); clusterAt = ticks; }
    }

    static void rebuild(Minecraft mc, Mod m) {
        listAt = ticks;
        LIST.clear();
        int R = (int) m.n("Range chunks");
        ChunkPos pc = mc.player.chunkPosition();
        List<int[]> tmp = new ArrayList<>();
        for (int x = -R; x <= R; x++) {
            for (int z = -R; z <= R; z++) tmp.add(new int[] {pc.x + x, pc.z + z, x * x + z * z});
        }
        tmp.sort((a, b) -> Integer.compare(a[2], b[2]));
        for (int[] t : tmp) LIST.add(key(t[0], t[1]));
        CHUNKS.values().removeIf(c -> Math.abs(c.cx - pc.x) > R + 3 || Math.abs(c.cz - pc.z) > R + 3);
    }

    static boolean villagersNear(Minecraft mc, int cx, int cz) {
        AABB box = new AABB(cx * 16 - 24, -64, cz * 16 - 24, cx * 16 + 40, 320, cz * 16 + 40);
        return !mc.level.getEntitiesOfClass(Villager.class, box).isEmpty();
    }

    static void scan(Minecraft mc, Mod m, int cx, int cz) {
        ChunkAccess ca = mc.level.getChunk(cx, cz, ChunkStatus.FULL, false);
        if (!(ca instanceof LevelChunk ch)) return;
        CI ci = new CI(cx, cz);
        ci.at = ticks;
        int mask = 0;
        double beScore = 0;
        for (BlockEntity be : ch.getBlockEntities().values()) {
            int[] k = classify(be, m);
            if (k == null) continue;
            BlockPos p = be.getBlockPos();
            if (be instanceof BellBlockEntity) { ci.bell = true; continue; }   // a bell = village, never a base
            beScore += k[0];
            mask |= 1 << k[1];
            ci.cnt[k[1]]++;
            ci.hot(p.getX() + 0.5, p.getY() + 0.5, p.getZ() + 0.5, k[0]);
        }
        int variety = Integer.bitCount(mask & 0x7F);
        double score = beScore * (1 + 0.3 * Math.max(0, variety - 1));

        // EVIDENCE = things only players put in the world: containers, furnaces, beds ... and redstone / storage blocks
        double ev = score;
        double weakScore = 0;
        if (m.b("Unnatural blocks")) {
            LevelChunkSection[] secs = ch.getSections();
            int minSec = mc.level.dimensionType().minY() >> 4;
            int hits = 0, nat = 0;
            double weakW = 0;
            for (int i = 0; i < secs.length; i++) {
                LevelChunkSection s = secs[i];
                if (s == null || s.hasOnlyAir() || !s.maybeHas(BaseFinder::interesting)) continue;
                int by = (minSec + i) << 4;
                for (int y = 0; y < 16; y++) {
                    for (int z = 0; z < 16; z++) {
                        for (int x = 0; x < 16; x++) {
                            int w = weight(s.getBlockState(x, y, z));
                            if (w == 0) continue;
                            if (w < 0) { nat++; continue; }
                            if (w >= 4) ci.strongW += w; else weakW += w;
                            if (w >= 4 && (++hits & 3) == 0) ci.hot(cx * 16 + x + 0.5, by + y + 0.5, cz * 16 + z + 0.5, w * 8 / 50.0);
                        }
                    }
                }
            }
            ev += Math.min(12.0, ci.strongW / 8.0);
            // planks / glass / wool alone are what mineshafts, mansions and villages are made of: they only add a little,
            // and nothing at all when the chunk contains markers of a generated structure (cobwebs, rails, cracked bricks ...)
            if (nat < 3) {
                weakScore = Math.min(3.0, weakW / 300.0);
                ci.blockW = weakW;
            }
        }
        score = ev + weakScore;
        ci.ev = ev;
        if (score > 0 && m.b("Ignore villages") && villagersNear(mc, cx, cz)) { score *= 0.25; ci.ev *= 0.25; }
        ci.score = score;
        CHUNKS.put(ci.key, ci);
    }

    // ------------------------------------------------------------------ clustering
    static void cluster(Minecraft mc, Mod m) {
        double thr = m.n("Sensitivity");
        double minChunk = Math.max(2, thr * 0.2);
        Set<Long> seen = new HashSet<>();
        String dim = dimName(mc);
        for (CI start : new ArrayList<>(CHUNKS.values())) {
            if (start.score < minChunk || !seen.add(start.key)) continue;
            ArrayDeque<CI> q = new ArrayDeque<>();
            q.add(start);
            double total = 0, evTotal = 0; boolean village = false; double sx = 0, sy = 0, sz = 0, sw = 0, blockW = 0, miny = 1e9, maxy = -1e9;
            int minX = Integer.MAX_VALUE, maxX = Integer.MIN_VALUE, minZ = Integer.MAX_VALUE, maxZ = Integer.MIN_VALUE;
            int[] cnt = new int[8];
            while (!q.isEmpty()) {
                CI c = q.poll();
                total += c.score; evTotal += c.ev; village |= c.bell; sx += c.sx; sy += c.sy; sz += c.sz; sw += c.sw; blockW += c.blockW;
                miny = Math.min(miny, c.miny); maxy = Math.max(maxy, c.maxy);
                minX = Math.min(minX, c.cx); maxX = Math.max(maxX, c.cx);
                minZ = Math.min(minZ, c.cz); maxZ = Math.max(maxZ, c.cz);
                for (int i = 0; i < 8; i++) cnt[i] += c.cnt[i];
                for (int dx = -2; dx <= 2; dx++) {
                    for (int dz = -2; dz <= 2; dz++) {
                        CI o = CHUNKS.get(key(c.cx + dx, c.cz + dz));
                        if (o != null && o.score >= minChunk && seen.add(o.key)) q.add(o);
                    }
                }
            }
            if (village && m.b("Ignore villages")) { total *= 0.3; evTotal *= 0.3; }
            // a base needs real evidence (containers / redstone / storage blocks), not only building blocks
            if (total < thr || evTotal < thr * 0.6 || sw <= 0) continue;
            double x = sx / sw, y = sy / sw, z = sz / sw;
            StringBuilder info = new StringBuilder();
            for (int i = 0; i < 8; i++) if (cnt[i] > 0) info.append(cnt[i]).append(' ').append(KIND[i]).append(", ");
            if (blockW > 0) info.append("~").append((int) blockW).append(" build-blocks, ");
            info.append("evidence ").append(Math.round(evTotal)).append(", ");
            if (info.length() > 2) info.setLength(info.length() - 2);
            AABB box = new AABB(minX * 16, Math.min(miny, y) - 2, minZ * 16, (maxX + 1) * 16, Math.max(maxy, y) + 3, (maxZ + 1) * 16);

            Base found = null;
            for (Base b : BASES) {
                if (!b.dim.equals(dim)) continue;
                if (Math.hypot(b.x - x, b.z - z) < 96) { found = b; break; }
            }
            if (found != null) {
                found.x = x; found.y = y; found.z = z; found.score = total; found.info = info.toString(); found.box = box;
            } else {
                Base b = new Base();
                b.id = nextId++;
                b.dim = dim; b.x = x; b.y = y; b.z = z; b.score = total; b.info = info.toString(); b.box = box;
                BASES.add(b);
                announce(mc, m, b);
            }
        }
    }

    // ------------------------------------------------------------------ output
    static void announce(Minecraft mc, Mod m, Base b) {
        int bx = (int) Math.round(b.x), by = (int) Math.round(b.y), bz = (int) Math.round(b.z);
        boolean hide = on("StreamerMode");
        if (m.b("Chat message")) {
            double dist = Math.hypot(b.x - mc.player.getX(), b.z - mc.player.getZ());
            String where = hide ? "" : "  X " + bx + "  Y " + by + "  Z " + bz;
            MutableComponent c = Component.literal("[BaseFinder] ").withStyle(ChatFormatting.LIGHT_PURPLE)
                .append(Component.literal("Base #" + b.id + " found" + where + "  (" + Math.round(dist) + " m, score "
                    + Math.round(b.score) + ")  " + b.info + "  ").withStyle(ChatFormatting.WHITE));
            if (!hide) {
                c.append(Component.literal("[copy]").withStyle(Style.EMPTY.withColor(ChatFormatting.AQUA)
                    .withClickEvent(new ClickEvent(ClickEvent.Action.COPY_TO_CLIPBOARD, bx + " " + by + " " + bz))));
                if (m.b("Xaero link") && (FabricLoader.getInstance().isModLoaded("xaerominimap")
                    || FabricLoader.getInstance().isModLoaded("xaerominimapfair"))) {
                    String set = b.dim.equals("the_nether") ? "Internal-nether-waypoints"
                        : b.dim.equals("the_end") ? "Internal-the-end-waypoints" : "Internal-overworld-waypoints";
                    String cmd = "/xaero_waypoint_add:Base_" + b.id + ":B:" + bx + ":" + by + ":" + bz + ":5:false:0:" + set;
                    c.append(Component.literal(" [+Xaero]").withStyle(Style.EMPTY.withColor(ChatFormatting.GREEN)
                        .withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, cmd))));
                }
            }
            // local only: addMessage never sends anything to the server
            mc.gui.getChat().addMessage(c);
        }
        if (m.b("Sound ping")) {
            mc.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.PLAYER_LEVELUP, 1.4f, 0.8f));
        }
        if (m.b("Save to file")) {
            try {
                String line = serverKey(mc) + "|" + b.dim + "|" + bx + "|" + by + "|" + bz + "|" + Math.round(b.score)
                    + "|" + LocalDateTime.now().withNano(0) + "\n";
                if (!Files.exists(file())) Files.writeString(file(), FILE_TAG + "\n");
                Files.writeString(file(), line, StandardOpenOption.CREATE, StandardOpenOption.APPEND);
            } catch (IOException | RuntimeException ignored) {
            }
        }
    }

    /** Bases saved earlier for this server and dimension come back silently, so they are not announced again. */
    static void loadFile(Minecraft mc) {
        try {
            Path p = file();
            if (!Files.exists(p)) return;
            List<String> all = Files.readAllLines(p);
            if (!all.isEmpty() && !all.get(0).equals(FILE_TAG)) {
                // saved by the old algorithm (it also stored mineshafts / villages): keep a backup, start clean
                Files.move(p, p.resolveSibling("prettybases_old.txt"), java.nio.file.StandardCopyOption.REPLACE_EXISTING);
                return;
            }
            String sk = serverKey(mc), dim = dimName(mc);
            for (String line : all) {
                String[] t = line.split("\\|");
                if (t.length < 6 || !t[0].equals(sk) || !t[1].equals(dim)) continue;
                Base b = new Base();
                b.id = nextId++;
                b.dim = dim;
                b.x = Double.parseDouble(t[2]); b.y = Double.parseDouble(t[3]); b.z = Double.parseDouble(t[4]);
                b.score = Double.parseDouble(t[5]);
                b.box = new AABB(b.x - 8, b.y - 4, b.z - 8, b.x + 8, b.y + 6, b.z + 8);
                BASES.add(b);
            }
        } catch (IOException | RuntimeException ignored) {
        }
    }

    // ------------------------------------------------------------------ drawing
    static void render(Minecraft mc) {
        Mod m = find("BaseFinder");
        if (m == null || !m.enabled || mc.level == null) return;
        String dim = dimName(mc);
        double thr = m.n("Sensitivity");
        Base nearest = null;
        double nd = 1e18;
        for (Base b : BASES) {
            if (!b.dim.equals(dim)) continue;
            double d = Math.hypot(b.x - mc.player.getX(), b.z - mc.player.getZ());
            if (d < nd) { nd = d; nearest = b; }
        }
        for (Base b : BASES) {
            if (!b.dim.equals(dim) || !m.b("ESP")) continue;
            int col = mix(0xFFD23C, 0xFF3B3B, Math.min(1f, (float) (b.score / (thr * 3))));
            WorldRender.boxL(b.box, col);
            WorldRender.FL.add(new WorldRender.Fl(b.box, col, 0.10f));
            WorldRender.line(b.x, b.y - 30, b.z, b.x, b.y + 120, b.z, col);
            double d = Math.hypot(b.x - mc.player.getX(), b.z - mc.player.getZ());
            WorldRender.LB.add(new WorldRender.Lb(new Vec3(b.x, b.box.maxY + 1.5, b.z),
                "BASE #" + b.id + "  " + Math.round(d) + "m  [" + Math.round(b.score) + "]", col, 1.4f));
            if (m.b("Tracer") && b == nearest) {
                WorldRender.line(WorldRender.cx, WorldRender.cy - 0.2, WorldRender.cz, b.x, b.y, b.z, col);
            }
        }
    }

    static void hud(GuiGraphics g, Minecraft mc, int sw, int y) {
        if (mc.level == null) return;
        String dim = dimName(mc);
        Base best = null;
        double bd = 1e18;
        for (Base b : BASES) {
            if (!b.dim.equals(dim)) continue;
            double d = Math.hypot(b.x - mc.player.getX(), b.z - mc.player.getZ());
            if (d < bd) { bd = d; best = b; }
        }
        if (best == null) return;
        String t = "Base #" + best.id + "  " + Math.round(bd) + " m"
            + (on("StreamerMode") ? "" : "   " + Math.round(best.x) + " " + Math.round(best.y) + " " + Math.round(best.z));
        int w = Ui.w(t) + 16, x = sw / 2 - w / 2;
        rr(g, x, y, w, 14, 4, alpha(0x101018, 0.75f));
        Ui.d(g, t, x + 8, y + 3, alpha(accent(0f), 1f), false);
    }
}
