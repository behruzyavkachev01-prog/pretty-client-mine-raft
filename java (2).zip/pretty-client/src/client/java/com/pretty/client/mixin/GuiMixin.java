package com.pretty.client.mixin;

import com.pretty.client.Hooks;
import net.minecraft.client.gui.Gui;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** NoRender: pumpkin blur and powder snow overlay. */
@Mixin(Gui.class)
public class GuiMixin {
    @Inject(method = "renderTextureOverlay", at = @At("HEAD"), cancellable = true)
    private void pretty$noOverlay(CallbackInfo ci) {
        if (Hooks.noRender("Pumpkin and snow")) ci.cancel();
    }
}
