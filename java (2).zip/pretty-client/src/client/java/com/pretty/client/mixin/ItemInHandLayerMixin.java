package com.pretty.client.mixin;

import com.mojang.blaze3d.vertex.PoseStack;
import com.pretty.client.Hooks;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.layers.ItemInHandLayer;
import net.minecraft.client.renderer.entity.state.ArmedEntityRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** CrowdBoost: items in the hands of far players are not drawn while a crowd is around. */
@Mixin(ItemInHandLayer.class)
public class ItemInHandLayerMixin {
    @Inject(method = "render(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;ILnet/minecraft/client/renderer/entity/state/ArmedEntityRenderState;FF)V",
        at = @At("HEAD"), cancellable = true)
    private void pretty$held(PoseStack ps, MultiBufferSource buf, int light, ArmedEntityRenderState state, float yRot, float xRot, CallbackInfo ci) {
        if (Hooks.hideHeld(state.distanceToCameraSq)) ci.cancel();
    }
}
