package com.pretty.client.mixin;

import com.pretty.client.Hooks;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.material.FluidState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Jesus: the same hook striders use to walk on lava, so water gets a real collision under your feet. */
@Mixin(LivingEntity.class)
public class LivingEntityMixin {
    @Inject(method = "canStandOnFluid", at = @At("HEAD"), cancellable = true)
    private void pretty$jesus(FluidState fluid, CallbackInfoReturnable<Boolean> cir) {
        if (Hooks.jesus(this, fluid)) cir.setReturnValue(true);
    }
}
