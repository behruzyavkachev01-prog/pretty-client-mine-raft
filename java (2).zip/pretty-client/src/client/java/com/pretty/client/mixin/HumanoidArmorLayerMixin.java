package com.pretty.client.mixin;

import com.mojang.blaze3d.vertex.PoseStack;
import com.pretty.client.Hooks;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.client.renderer.entity.state.HumanoidRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** CrowdBoost: no armor layers (the most expensive part of a player model) on far players in a crowd. */
@Mixin(HumanoidArmorLayer.class)
public class HumanoidArmorLayerMixin {
    @Inject(method = "render(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;ILnet/minecraft/client/renderer/entity/state/HumanoidRenderState;FF)V",
        at = @At("HEAD"), cancellable = true)
    private void pretty$armor(PoseStack ps, MultiBufferSource buf, int light, HumanoidRenderState state, float yRot, float xRot, CallbackInfo ci) {
        if (Hooks.hideArmor(state.distanceToCameraSq)) ci.cancel();
    }
}
