package com.pretty.client;

import static com.pretty.client.PrettyClient.*;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ParticleStatus;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import org.lwjgl.glfw.GLFW;

/** Third batch: SwingAnimation, ShiftTap, ClickGuiWalk, ItemScroller, World, Particles, Zoom, StreamerMode and the world-render visuals. */
final class Modules3 {
    private Modules3() {}

    static int shiftTicks;
    static boolean shiftForced, walkForced;
    static int scrollCd;
    static boolean heldBlock;

    private static final SoundEvent[] CUSTOM = new SoundEvent[5];

    /** Our own keyboard / chime sounds from assets/pretty/sounds (thock, clack, creamy, crystal, bell). */
    static SoundEvent custom(int i) {
        String[] n = {"crit_thock", "crit_clack", "crit_creamy", "crit_crystal", "crit_bell"};
        if (CUSTOM[i] == null) {
            CUSTOM[i] = SoundEvent.createVariableRangeEvent(
                net.minecraft.resources.ResourceLocation.fromNamespaceAndPath("pretty", n[i]));
        }
        return CUSTOM[i];
    }

    /**
     * CritSound: plays a pleasant sound on every hit, from the ground or the air.
     * A real vanilla crit already gets its sound from the server, so it is skipped to avoid a double sound.
     */
    static void critSound(Player p, Entity target) {
        Mod m = find("CritSound");
        if (m == null || !m.enabled || !(target instanceof LivingEntity)) return;
        float strength = p.getAttackStrengthScale(0.5f);
        boolean realCrit = strength > 0.9f && p.fallDistance > 0f && !p.onGround() && !p.onClimbable()
            && !p.isInWater() && !p.hasEffect(MobEffects.BLINDNESS) && !p.isPassenger() && !p.isSprinting();
        if (realCrit) return;
        if (m.b("Only full charge") && strength < 0.9f) return;
        int mode = (int) m.n("Sound");
        SoundEvent snd = switch (mode) {
            case 1 -> SoundEvents.EXPERIENCE_ORB_PICKUP;
            case 2 -> SoundEvents.AMETHYST_BLOCK_CHIME;
            case 3, 4, 5, 6, 7 -> custom(mode - 3);
            default -> SoundEvents.PLAYER_ATTACK_CRIT;
        };
        float pitch = (float) m.n("Pitch");
        if (m.b("Random pitch")) pitch *= 0.96f + p.getRandom().nextFloat() * 0.08f;
        Minecraft.getInstance().getSoundManager().play(
            net.minecraft.client.resources.sounds.SimpleSoundInstance.forUI(snd, pitch, (float) m.n("Volume")));
    }

    // ------------------------------------------------------------------ KeySounds
    private static final boolean[] KEY_DOWN = new boolean[GLFW.GLFW_KEY_LAST + 1];
    private static final boolean[] MOUSE_DOWN = new boolean[8];
    private static boolean keyInit;

    /**
     * KeySounds: a pleasant keyboard sound for every key press (and a softer one on release), played by the game itself,
     * so it sounds good even on a bad keyboard. Polled once per frame, so there is no extra delay.
     */
    static void keySounds(Minecraft mc) {
        Mod m = find("KeySounds");
        if (m == null || !m.enabled) { keyInit = false; return; }
        long win = mc.getWindow().getWindow();
        boolean focused = mc.isWindowActive();
        boolean menusOnly = m.b("Only in menus & chat");
        boolean move = m.b("Movement keys");
        if (!keyInit) {
            for (int k = GLFW.GLFW_KEY_SPACE; k <= GLFW.GLFW_KEY_LAST; k++) KEY_DOWN[k] = GLFW.glfwGetKey(win, k) == GLFW.GLFW_PRESS;
            keyInit = true;
            return;
        }
        for (int k = GLFW.GLFW_KEY_SPACE; k <= GLFW.GLFW_KEY_LAST; k++) {
            boolean now = GLFW.glfwGetKey(win, k) == GLFW.GLFW_PRESS;
            if (now == KEY_DOWN[k]) continue;
            KEY_DOWN[k] = now;
            if (!focused || (menusOnly && mc.screen == null)) continue;
            if (!move && mc.screen == null && isMoveKey(mc, k)) continue;
            if (now) playKey(mc, m, k, false);
            else if (m.b("Release sound")) playKey(mc, m, k, true);
        }
        if (m.b("Mouse clicks") && focused && (!menusOnly || mc.screen != null)) {
            for (int b = 0; b < 3; b++) {
                boolean now = GLFW.glfwGetMouseButton(win, b) == GLFW.GLFW_PRESS;
                if (now != MOUSE_DOWN[b]) {
                    MOUSE_DOWN[b] = now;
                    if (now) { if ((int) m.n("Sound") == 3) playPack(mc, m, "mouse_down"); else playKey(mc, m, GLFW.GLFW_KEY_SPACE, false); }
                    else if ((int) m.n("Sound") == 3 && m.b("Release sound")) playPack(mc, m, "mouse_up");
                }
            }
        }
    }

    private static boolean isMoveKey(Minecraft mc, int k) {
        var o = mc.options;
        return o.keyUp.matches(k, 0) || o.keyDown.matches(k, 0) || o.keyLeft.matches(k, 0) || o.keyRight.matches(k, 0)
            || o.keyJump.matches(k, 0) || o.keySprint.matches(k, 0) || o.keyShift.matches(k, 0);
    }

    private static final java.util.Map<String, SoundEvent> PACK = new java.util.HashMap<>();

    /** Sound event from sounds.json (pretty:key_down ...). A resource pack can replace these with real recordings. */
    static SoundEvent packEvent(String name) {
        return PACK.computeIfAbsent(name, n -> SoundEvent.createVariableRangeEvent(
            net.minecraft.resources.ResourceLocation.fromNamespaceAndPath("pretty", n)));
    }

    private static void playPack(Minecraft mc, Mod m, String name) {
        float pitch = (float) m.n("Pitch");
        if (m.b("Random pitch")) pitch *= 0.98f + mc.level.random.nextFloat() * 0.04f;
        mc.getSoundManager().play(net.minecraft.client.resources.sounds.SimpleSoundInstance.forUI(
            packEvent(name), Math.max(0.5f, Math.min(2.0f, pitch)), (float) m.n("Volume")));
    }

    private static void playKey(Minecraft mc, Mod m, int key, boolean release) {
        if ((int) m.n("Sound") == 3) {
            playPack(mc, m, release ? "key_up" : key == GLFW.GLFW_KEY_SPACE ? "key_space"
                : (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) ? "key_enter" : "key_down");
            return;
        }
        float pitch = (float) m.n("Pitch");
        if (key == GLFW.GLFW_KEY_SPACE) pitch *= 0.78f;                       // space bar: deeper
        else if (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) pitch *= 0.88f;
        else if (key == GLFW.GLFW_KEY_BACKSPACE) pitch *= 0.95f;
        else if (key == GLFW.GLFW_KEY_LEFT_SHIFT || key == GLFW.GLFW_KEY_RIGHT_SHIFT || key == GLFW.GLFW_KEY_LEFT_CONTROL
            || key == GLFW.GLFW_KEY_RIGHT_CONTROL || key == GLFW.GLFW_KEY_LEFT_ALT || key == GLFW.GLFW_KEY_TAB) pitch *= 0.9f;
        if (m.b("Random pitch")) pitch *= 0.95f + mc.level.random.nextFloat() * 0.1f;
        float vol = (float) m.n("Volume");
        if (release) { pitch *= 1.3f; vol *= 0.45f; }
        pitch = Math.max(0.5f, Math.min(2.0f, pitch));
        mc.getSoundManager().play(net.minecraft.client.resources.sounds.SimpleSoundInstance.forUI(
            custom((int) m.n("Sound")), pitch, vol));
    }

    private static boolean down(Minecraft mc, int key) {
        return InputConstants.isKeyDown(mc.getWindow().getWindow(), key);
    }

    static void register() {
        // ------------------------------------------------------------ combat
        add(new Mod("ShiftTap", Cat.COMBAT).with(new Num("Ticks", 1, 6, 2, 1)).def()
            .tick((mc, m) -> {
                if (shiftTicks > 0) {
                    mc.options.keyShift.setDown(true);
                    shiftForced = true;
                    shiftTicks--;
                } else if (shiftForced) {
                    shiftForced = false;
                    mc.options.keyShift.setDown(down(mc, GLFW.GLFW_KEY_LEFT_SHIFT));
                }
            })
            .off((mc, m) -> { shiftTicks = 0; if (shiftForced) { shiftForced = false; mc.options.keyShift.setDown(false); } }));

        add(new Mod("CritSound", Cat.COMBAT).with(new Num("Sound", 0, 7, 3, 1), new Num("Volume", 0.1, 2.0, 1.0, 0.1),
            new Num("Pitch", 0.5, 2.0, 1.0, 0.05), new Bool("Random pitch", true), new Bool("Only full charge", false)).def());
        add(new Mod("HitRange", Cat.COMBAT).with(new Num("Radius", 2, 6, 3, 0.5)));

        // ---------------------------------------------------------- movement
        add(new Mod("SafeWalk", Cat.MOVEMENT).with(new Bool("Only with blocks", false)));
        add(new Mod("AutoBlockSwap", Cat.PLAYER).def().tick((mc, m) -> {
            Player p = mc.player;
            ItemStack h = p.getMainHandItem();
            if (h.getItem() instanceof BlockItem) { heldBlock = true; return; }
            if (heldBlock && h.isEmpty()) {
                int s = Modules.findHotbar(p, is -> is.getItem() instanceof BlockItem);
                if (s >= 0) p.getInventory().selected = s;
            }
            heldBlock = false;
        }));
        add(new Mod("BlockCounter", Cat.HUD).def());
        add(new Mod("ClickGuiWalk", Cat.MOVEMENT).def().tick((mc, m) -> {
            boolean gui = mc.screen instanceof Gui gg && !gg.isTyping();
            if (gui) {
                mc.options.keyUp.setDown(down(mc, GLFW.GLFW_KEY_W));
                mc.options.keyDown.setDown(down(mc, GLFW.GLFW_KEY_S));
                mc.options.keyLeft.setDown(down(mc, GLFW.GLFW_KEY_A));
                mc.options.keyRight.setDown(down(mc, GLFW.GLFW_KEY_D));
                mc.options.keyJump.setDown(down(mc, GLFW.GLFW_KEY_SPACE));
                walkForced = true;
            } else if (walkForced && mc.screen == null) {
                walkForced = false;
                mc.options.keyUp.setDown(down(mc, GLFW.GLFW_KEY_W));
                mc.options.keyDown.setDown(down(mc, GLFW.GLFW_KEY_S));
                mc.options.keyLeft.setDown(down(mc, GLFW.GLFW_KEY_A));
                mc.options.keyRight.setDown(down(mc, GLFW.GLFW_KEY_D));
                mc.options.keyJump.setDown(down(mc, GLFW.GLFW_KEY_SPACE));
            }
        }));

        // ------------------------------------------------------------ visuals
        add(new Mod("SwingAnimation", Cat.VISUAL).with(new Num("Speed", 0.2, 3.0, 0.6, 0.1)).tick((mc, m) -> {
            Player p = mc.player;
            if (!p.swinging) { m.acc = 0; return; }
            m.acc += m.n("Speed") - 1.0;
            while (m.acc <= -1.0) { p.swingTime = Math.max(0, p.swingTime - 1); m.acc += 1.0; }
            while (m.acc >= 1.0) { p.swingTime++; m.acc -= 1.0; }
        }));

        add(new Mod("NoRender", Cat.VISUAL).with(new Bool("Fire", true), new Bool("Water", true),
            new Bool("Pumpkin and snow", true), new Bool("Hurt cam", false)));
        add(new Mod("TargetEsp", Cat.VISUAL).with(new Num("Seconds", 1, 10, 3, 1), new Bool("Ring", true), new Bool("Box", true),
            new Bool("Crystals", true), new Num("Crystal count", 3, 8, 5, 1), new Bool("Crosshair", true)).def());
        add(new Mod("ChinaHat", Cat.VISUAL).with(new Num("Size", 0.3, 1.0, 0.6, 0.05), new Bool("Rainbow", true)));

        add(new Mod("SkyChanger", Cat.VISUAL).with(new Bool("Sky color", true), new Bool("Cloud color", true),
            new Bool("Rainbow", false), new Num("Speed", 0.1, 3.0, 0.6, 0.1), new Num("Hue", 0, 1, 0.5, 0.01),
            new Num("Saturation", 0, 1, 0.65, 0.05), new Num("Brightness", 0, 1, 1, 0.05),
            new Num("Alpha", 0, 1, 1, 0.05), new Bool("Keep day/night", false),
            new Bool("Fixed time", false), new Num("Time", 0, 24000, 13000, 500)));
        add(new Mod("CustomHand", Cat.VISUAL).with(new Bool("Main hand", true), new Bool("Off hand", false),
            new Bool("Lying pose", true), new Num("X", -1, 1, 0, 0.01), new Num("Y", -1, 1, 0, 0.01),
            new Num("Z", -1.5, 1, 0, 0.01), new Num("Rot X", -180, 180, 0, 5), new Num("Rot Y", -180, 180, 0, 5),
            new Num("Rot Z", -180, 180, 0, 5), new Num("Scale", 0.3, 1.5, 1, 0.05),
            new Num("Arm X", -1, 1, 0, 0.01), new Num("Arm Y", -1, 1, 0, 0.01), new Num("Arm Z", -1, 1, 0, 0.01),
            new Num("Arm scale", 0.5, 1.5, 1, 0.05), new Num("Swing mode", 0, 3, 1, 1), new Num("Swing power", 0.2, 2, 1, 0.1),
            new Num("Swing smoothing", 0, 1, 0.6, 0.05)).def());
        add(new Mod("ItemShader", Cat.VISUAL).with(new Bool("Rainbow", false), new Num("Hue 1", 0, 1, 0.75, 0.01),
            new Num("Hue 2", 0, 1, 0.9, 0.01), new Num("Saturation", 0, 1, 0.9, 0.05),
            new Num("Gradient speed", 0, 3, 0.6, 0.1), new Num("Strength", 0, 1, 0.8, 0.05),
            new Bool("Totems", true), new Num("Totems hue shift", 0, 1, 0, 0.01),
            new Bool("Swords", false), new Num("Swords hue shift", 0, 1, 0, 0.01),
            new Bool("Tools", false), new Num("Tools hue shift", 0, 1, 0, 0.01),
            new Bool("Food", false), new Num("Food hue shift", 0, 1, 0, 0.01),
            new Bool("Blocks", false), new Num("Blocks hue shift", 0, 1, 0, 0.01),
            new Bool("Other", false), new Num("Other hue shift", 0, 1, 0, 0.01)).def());
        add(new Mod("SkyParticles", Cat.VISUAL).with(new Num("Mode", 0, 3, 0, 1), new Num("Amount", 1, 8, 2, 1),
            new Num("Interval", 2, 20, 6, 1), new Num("Radius", 1, 8, 4, 0.5), new Num("Size", 0.5, 2.5, 1.2, 0.1),
            new Bool("Follow sky color", true)).tick((mc, m) -> {
            if (ticks % Math.max(1, (int) m.n("Interval")) != 0) return;
            var r = mc.level.random;
            int mode = (int) m.n("Mode"), amt = (int) m.n("Amount");
            double rad = m.n("Radius");
            float size = (float) m.n("Size");
            int rgb = m.b("Follow sky color") ? Hooks.skyRgb() : 0xFF7AC8;
            Player p = mc.player;
            for (int i = 0; i < amt; i++) {
                double a = r.nextDouble() * Math.PI * 2, d = Math.sqrt(r.nextDouble()) * rad;
                double x = p.getX() + Math.cos(a) * d, z = p.getZ() + Math.sin(a) * d, y = p.getY() + r.nextDouble() * 2.5;
                int kind = mode == 1 ? 0 : mode == 2 ? 1 : mode == 3 ? 2 : r.nextInt(3);
                if (kind == 0) {
                    mc.level.addParticle(ParticleTypes.HEART, x, y, z, 0, 0.04, 0);
                    for (int k = 0; k < 2; k++) {
                        mc.level.addParticle(new DustParticleOptions(rgb, size * 0.6f), x + (r.nextDouble() - 0.5) * 0.3,
                            y + (r.nextDouble() - 0.5) * 0.3, z + (r.nextDouble() - 0.5) * 0.3, 0, 0.02, 0);
                    }
                } else if (kind == 1) {
                    mc.level.addParticle(new DustParticleOptions(rgb, size), x, y, z, 0, 0.03, 0);
                } else {
                    mc.level.addParticle(ParticleTypes.END_ROD, x, y, z, 0, 0.03, 0);
                    mc.level.addParticle(new DustParticleOptions(rgb, size * 0.8f), x, y, z, 0, 0.02, 0);
                }
            }
        }));
        add(new Mod("ChunkFade", Cat.VISUAL).with(new Num("Duration", 0.2, 3, 0.9, 0.1), new Num("Depth", 4, 64, 24, 2))
            .tick((mc, m) -> { if (ticks % 100 == 0) Hooks.chunkPrune(mc); }).def());
        add(new Mod("BaseFinder", Cat.RENDER).with(new Num("Sensitivity", 6, 80, 18, 1), new Num("Range chunks", 4, 32, 12, 1),
            new Num("Speed", 1, 8, 3, 1), new Bool("Chat message", true), new Bool("Xaero link", true),
            new Bool("Save to file", true), new Bool("ESP", true), new Bool("Tracer", false), new Bool("Sound ping", true),
            new Bool("Ignore villages", true), new Bool("Unnatural blocks", true), new Bool("Count spawners", false))
            .tick(BaseFinder::tick));
        add(new Mod("KeySounds", Cat.OTHER).with(new Num("Sound", 0, 3, 3, 1), new Num("Volume", 0.1, 2.0, 0.8, 0.1),
            new Num("Pitch", 0.5, 1.6, 1.0, 0.05), new Bool("Random pitch", true), new Bool("Release sound", true),
            new Bool("Movement keys", true), new Bool("Only in menus & chat", false), new Bool("Mouse clicks", false)).def());
        add(new Mod("Hands", Cat.VISUAL).with(new Bool("Rainbow", false), new Num("Hue 1", 0, 1, 0.33, 0.01),
            new Num("Hue 2", 0, 1, 0.0, 0.01), new Num("Saturation", 0, 1, 1, 0.05),
            new Num("Gradient speed", 0, 3, 0.6, 0.1), new Num("Alpha", 0.2, 1, 1, 0.05)));

        add(new Mod("World", Cat.VISUAL).with(new Bool("No rain", true)).tick((mc, m) -> {
            if (m.b("No rain")) {
                mc.level.setRainLevel(0f);
                mc.level.setThunderLevel(0f);
            }
        }));

        add(new Mod("Particles", Cat.VISUAL).with(new Num("Level", 0, 2, 1, 1)).tick((mc, m) -> {
            int l = (int) m.n("Level");
            force("partsmod", mc.options.particles(), l == 0 ? ParticleStatus.ALL : l == 1 ? ParticleStatus.DECREASED : ParticleStatus.MINIMAL);
        }).off((mc, m) -> restore("partsmod")));

        add(new Mod("Zoom", Cat.VISUAL).with(new Num("FOV", 10, 60, 25, 1)).def());

        // ------------------------------------------------------------- player
        add(new Mod("ItemScroller", Cat.PLAYER).with(new Num("Delay", 0, 5, 1, 1)).def().tick((mc, m) -> {
            if (!(mc.screen instanceof AbstractContainerScreen<?> cs) || mc.gameMode == null) return;
            if (scrollCd > 0) { scrollCd--; return; }
            long win = mc.getWindow().getWindow();
            boolean shift = down(mc, GLFW.GLFW_KEY_LEFT_SHIFT) || down(mc, GLFW.GLFW_KEY_RIGHT_SHIFT);
            boolean lmb = GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
            if (!shift || !lmb) return;
            Slot s = cs.hoveredSlot;
            if (s == null || !s.hasItem()) return;
            mc.gameMode.handleInventoryMouseClick(cs.getMenu().containerId, s.index, 0, ClickType.QUICK_MOVE, mc.player);
            scrollCd = (int) m.n("Delay");
        }));

        // -------------------------------------------------------------- other
        add(new Mod("StreamerMode", Cat.OTHER));
    }
}
