package com.pretty.client.mixin;

import com.pretty.client.Hooks;
import net.minecraft.client.renderer.ScreenEffectRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** NoRender: fire and underwater overlays. */
@Mixin(ScreenEffectRenderer.class)
public class ScreenEffectMixin {
    @Inject(method = "renderFire", at = @At("HEAD"), cancellable = true)
    private static void pretty$noFire(CallbackInfo ci) {
        if (Hooks.noRender("Fire")) ci.cancel();
    }

    @Inject(method = "renderWater", at = @At("HEAD"), cancellable = true)
    private static void pretty$noWater(CallbackInfo ci) {
        if (Hooks.noRender("Water")) ci.cancel();
    }
}
