package com.pretty.client.mixin;

import com.pretty.client.Hooks;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** SafeWalk: the player never walks off a block edge while on the ground. */
@Mixin(Player.class)
public class PlayerMixin {
    @Inject(method = "maybeBackOffFromEdge", at = @At("HEAD"), cancellable = true)
    private void pretty$safeWalk(Vec3 movement, MoverType type, CallbackInfoReturnable<Vec3> cir) {
        Vec3 r = Hooks.safeWalk((Player) (Object) this, movement);
        if (r != null) cir.setReturnValue(r);
    }
}
