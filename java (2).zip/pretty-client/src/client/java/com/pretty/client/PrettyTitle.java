package com.pretty.client;

import static com.pretty.client.PrettyClient.*;

import com.mojang.blaze3d.vertex.PoseStack;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.multiplayer.JoinMultiplayerScreen;
import net.minecraft.client.gui.screens.options.OptionsScreen;
import net.minecraft.client.gui.screens.worldselection.SelectWorldScreen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;

/**
 * Main menu: black screen, "PrettyClient" slowly emerges from the darkness in the center, then the menu
 * slides in with a stagger. Buttons ease toward their hover state, the background has mouse parallax.
 */
final class PrettyTitle extends Screen {
    private static final String TITLE = "PrettyClient";
    private static final String[] LABELS = {"Singleplayer", "Multiplayer", "Accounts", "Mods & Packs", "Options", "Quit"};
    private static final float MENU_AT = 2.6f;
    private static final int BW = 150, BH = 18, GAP = 4;

    private final long t0 = System.currentTimeMillis();
    private final float[] hov = new float[LABELS.length];
    private float smx = -1, smy = -1;
    private long lastNs = System.nanoTime();

    PrettyTitle() { super(Component.literal("PrettyClient")); }

    private float time() { return (System.currentTimeMillis() - t0) / 1000f; }

    private int titleY() { return (int) (height * 0.28f); }
    private int bx() { return width / 2 - BW / 2; }
    private int menuTop() {
        int total = LABELS.length * BH + (LABELS.length - 1) * GAP;
        return Math.min(titleY() + 44, height - total - 14);
    }
    private int by(int i) { return menuTop() + i * (BH + GAP); }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        long nowNs = System.nanoTime();
        float dt = Math.min((nowNs - lastNs) / 1e9f, 0.05f);
        lastNs = nowNs;
        if (smx < 0) { smx = mx; smy = my; }
        smx += (mx - smx) * Math.min(1f, dt * 4f);
        smy += (my - smy) * Math.min(1f, dt * 4f);

        float t = time();
        int acc = accent(0f);
        int cx = width / 2, cy = titleY();

        g.fill(0, 0, width, height, 0xFF05060B);
        float bg = ease(t / 2.0f);
        g.fillGradient(0, 0, width, height, alpha(mix(0x0B1020, acc, 0.10f), bg), alpha(0x04050A, bg));

        // slow aurora: three soft glows drifting on their own paths, tinted with the theme colour
        for (int bl = 0; bl < 3; bl++) {
            float ph = t * (0.12f + bl * 0.05f) + bl * 2.1f;
            int bx0 = (int) (width * (0.5f + 0.34f * Mth.sin(ph)) + (smx - cx) * 0.02f * (bl + 1));
            int by0 = (int) (height * (0.45f + 0.22f * Mth.cos(ph * 1.3f)) + (smy - cy) * 0.02f * (bl + 1));
            int bcol = accent(bl * 0.33f);
            for (int i = 0; i < 7; i++) {
                int r = 30 + i * 26;
                rr(g, bx0 - r * 2, by0 - r, r * 4, r * 2, r, alpha(bcol, 0.016f * bg));
            }
        }
        // vignette
        g.fillGradient(0, 0, width, height / 4, alpha(0x000000, 0.55f * bg), alpha(0x000000, 0f));
        g.fillGradient(0, height * 3 / 4, width, height, alpha(0x000000, 0f), alpha(0x000000, 0.6f * bg));

        // soft glow behind the title, follows the mouse a little
        float glow = ease((t - 0.3f) / 2.2f);
        int gx = cx + (int) ((smx - cx) * 0.03f), gy = cy + (int) ((smy - cy) * 0.03f);
        for (int i = 0; i < 8; i++) {
            int r = 26 + i * 20;
            rr(g, gx - r * 3, gy - r, r * 6, r * 2, r, alpha(acc, 0.018f * glow));
        }

        // drifting dust with parallax layers
        for (int i = 0; i < 64; i++) {
            float depth = 0.3f + (i % 4) * 0.35f;
            float sx = ((i * 97) % 100) / 100f;
            float sp = 5f + (i % 5) * 4f;
            float x = sx * width + (float) Math.sin(t * 0.5 + i) * 8f - (smx - cx) * 0.03f * depth;
            float y = height - ((t * sp + ((i * 53) % 100) / 100f * height) % height) - (smy - cy) * 0.03f * depth;
            float a = (0.12f + ((i * 31) % 10) / 40f) * bg;
            int s = i % 4 == 0 ? 2 : 1;
            g.fill((int) x, (int) y, (int) x + s, (int) y + s, alpha(mix(0xFFFFFF, acc, 0.5f), a));
        }

        // title: every letter fades out of the dark one after another
        float scale = 3f + (1f - ease(t / 3.5f)) * -0.35f;
        int fullW = Ui.wt(TITLE);
        float x = cx - fullW * scale / 2f + (smx - cx) * 0.008f;
        float ty = cy - 5 * scale;
        PoseStack ps = g.pose();
        for (int i = 0; i < TITLE.length(); i++) {
            String ch = String.valueOf(TITLE.charAt(i));
            float a = ease((t - 0.5f - i * 0.13f) / 1.1f);
            if (a > 0.01f) {
                int col = mix(0xFFFFFF, accent(i * 0.05f), 0.4f);
                float rise = (1f - a) * 6f;
                for (int k = 0; k < 2; k++) {
                    float sc = k == 0 ? scale * 1.10f : scale;
                    float ga = k == 0 ? a * 0.18f : a;
                    float ox = k == 0 ? -Ui.wt(ch) * scale * 0.05f : 0f;
                    ps.pushPose();
                    ps.translate(x + ox, ty + rise - (k == 0 ? scale * 0.4f : 0f), 0);
                    ps.scale(sc, sc, 1f);
                    Ui.dt(g, ch, 0, 0, alpha(col, ga), false);
                    ps.popPose();
                }
            }
            x += Ui.wt(ch) * scale;
        }

        // underline + subtitle
        float ua = ease((t - 2.0f) / 1.0f);
        int lw = (int) (fullW * scale * 0.8f * ua);
        int lineY = cy + 15;
        g.fillGradient(cx - lw / 2, lineY, cx + lw / 2, lineY + 1, alpha(accent(0f), ua), alpha(accent(0.3f), ua));
        String sub = "visuals & utility  |  1.21.4";
        Ui.center(g, sub, cx, lineY + 7, alpha(0x7C9A8A, ua));

        // menu: staggered slide-in, eased hover
        for (int i = 0; i < LABELS.length; i++) {
            float mt = ease((t - MENU_AT - i * 0.08f) / 0.7f);
            boolean hovered = mt > 0.9f && mx >= bx() && mx <= bx() + BW && my >= by(i) && my <= by(i) + BH;
            hov[i] += ((hovered ? 1f : 0f) - hov[i]) * Math.min(1f, dt * 14f);
            if (mt <= 0.01f) continue;
            float h = hov[i];
            int y = by(i) + (int) ((1f - mt) * 8f);
            int x0 = bx() - (int) (h * 3f);
            int w = BW + (int) (h * 6f);
            rr(g, x0 - 1, y - 1, w + 2, BH + 2, 6, alpha(acc, (0.10f + 0.35f * h) * mt));
            rr(g, x0, y, w, BH, 5, alpha(mix(0x0B0E16, mix(0x121828, acc, 0.26f), h), 0.94f * mt));
            int barH = (int) (BH * 0.6f * h);
            if (barH > 1) rr(g, x0, y + BH / 2 - barH / 2, 2, barH, 1, alpha(acc, mt));
            Ui.center(g, LABELS[i], cx + (int) (h * 2f), y + 5, alpha(mix(0xB5C7BC, 0xFFFFFF, h), mt));
        }

        float mt = ease((t - MENU_AT) / 0.9f);
        if (mt > 0.01f) {
            Ui.d(g, "Welcome back, " + (on("StreamerMode") ? "Streamer" : minecraft.getUser().getName()), 8, height - 14, alpha(0x7C9A8A, mt), false);
            String clock = LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm"));
            Ui.d(g, clock, width - 8 - Ui.w(clock), 8, alpha(0xB5C7BC, mt), false);
            String ver = "Right Shift: ClickGUI";
            Ui.d(g, ver, width - 8 - Ui.w(ver), height - 14, alpha(0x4C5F54, mt), false);
        }
    }

    @Override
    public boolean mouseClicked(double mx, double my, int btn) {
        if (btn == 0 && time() > MENU_AT + 0.6f) {
            for (int i = 0; i < LABELS.length; i++) {
                if (mx >= bx() && mx <= bx() + BW && my >= by(i) && my <= by(i) + BH) {
                    minecraft.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK, 1.0f));
                    switch (i) {
                        case 0 -> minecraft.setScreen(new SelectWorldScreen(this));
                        case 1 -> minecraft.setScreen(new JoinMultiplayerScreen(this));
                        case 2 -> minecraft.setScreen(new AccountsScreen(this));
                        case 3 -> minecraft.setScreen(new ModsScreen(this));
                        case 4 -> minecraft.setScreen(new OptionsScreen(this, minecraft.options));
                        default -> minecraft.stop();
                    }
                    return true;
                }
            }
        }
        return super.mouseClicked(mx, my, btn);
    }

    @Override
    public boolean shouldCloseOnEsc() { return false; }

    @Override
    public boolean isPauseScreen() { return false; }
}
