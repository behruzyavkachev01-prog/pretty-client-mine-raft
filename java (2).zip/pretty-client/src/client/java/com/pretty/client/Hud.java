package com.pretty.client;

import static com.pretty.client.PrettyClient.*;

import com.mojang.blaze3d.vertex.PoseStack;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/** All 2D overlays. */
final class Hud {
    private Hud() {}

    static long lastNs = System.nanoTime();
    static final DateTimeFormatter CLOCK = DateTimeFormatter.ofPattern("HH:mm");

    static void render(GuiGraphics g, DeltaTracker delta) {
        Minecraft mc = Minecraft.getInstance();
        long nowNs = System.nanoTime();
        float dt = Math.min((nowNs - lastNs) / 1e9f, 0.05f);
        lastNs = nowNs;
        for (Mod m : MODS) m.anim += ((m.enabled ? 1f : 0f) - m.anim) * Math.min(1f, dt * 12f);
        if (mc.level != null) Modules3.keySounds(mc);

        if (mc.player == null || mc.level == null || mc.options.hideGui) return;
        Font font = mc.font;
        int sw = g.guiWidth(), sh = g.guiHeight();

        if (on("BlockCounter")) blockCounter(g, mc, sw, sh);
        int ty = 4;   // top-centre stack: watermark, info, server, compass, base
        if (on("FrameGraph")) frameGraph(g, font, (nowNs - prevFrameNs) / 1e6f);
        prevFrameNs = nowNs;
        if (on("CPS")) cps(g, mc, sw, sh);
        if (on("Watermark")) { watermark(g, mc, font, sw, ty); ty += 20; }
        if (on("Info")) { info(g, font, sw, ty); ty += 18; }
        if (on("ServerInfo") && !on("StreamerMode")) { serverInfo(g, mc, sw, ty); ty += 18; }
        if (on("Compass")) { compass(g, mc, sw, ty); ty += 18; }
        if (on("BaseFinder")) BaseFinder.hud(g, mc, sw, ty);
        if (on("ShaderHands") && !Hooks.liteHud()) shaderHands(g, mc, sw, sh);
        if (on("ModuleList")) arrayList(g, font, sw);
        if (on("Coords") && !on("StreamerMode")) coords(g, mc, font, sh);
        if (on("Radar")) radar(g, mc);
        if (on("ItemCounter")) itemCounter(g, mc, sw, sh);
        if (on("InventoryHUD")) inventoryHud(g, mc, sw, sh);
        if (on("ArmorStatus")) armorStatus(g, mc, sw, sh);
        ServerHelper.panels(g, mc, sw, sh);
        if (on("Keystrokes")) keystrokes(g, mc, font, sh);
        if (on("PotionHUD")) potions(g, mc, font, sh);
        if (on("TargetHUD")) targetHud(g, mc, font, sw, sh, dt);
        if (on("ComboCounter")) comboCounter(g, font, sw, sh);
        if (on("Notifications")) notifications(g, font, sw, sh);
        welcome(g, mc);
    }

    // ---------------------------------------------------------------- FrameGraph / CPS
    private static long prevFrameNs = System.nanoTime();
    private static final float[] FT = new float[240];
    private static int ftPos, ftCount, ftTick;
    private static float ftAvg, ftLow;

    /** Frame-time graph (bar height = ms per frame) with the average and the "1% low" FPS, to judge the optimization. */
    static void frameGraph(GuiGraphics g, Font font, float ms) {
        Mod m = find("FrameGraph");
        int n = Math.max(30, Math.min(FT.length, (int) m.n("Samples")));
        FT[ftPos] = Math.min(ms, 200f);
        ftPos = (ftPos + 1) % FT.length;
        ftCount = Math.min(FT.length, ftCount + 1);
        if (++ftTick % 30 == 1 || ftCount < 5) {
            int c = Math.min(n, ftCount);
            float[] s = new float[c];
            float sum = 0;
            for (int i = 0; i < c; i++) { s[i] = FT[(ftPos - 1 - i + FT.length) % FT.length]; sum += s[i]; }
            java.util.Arrays.sort(s);
            ftAvg = sum / c;
            int k = Math.max(1, c / 100);               // slowest 1% of the frames
            float w = 0;
            for (int i = 0; i < k; i++) w += s[c - 1 - i];
            ftLow = 1000f / Math.max(1f, w / k);
        }
        int h = 34, x = 6, y = 6, c = Math.min(n, ftCount);
        rr(g, x - 3, y - 3, n + 6, h + 17, 4, alpha(0x101018, 0.7f));
        for (int i = 0; i < c; i++) {
            float v = FT[(ftPos - 1 - i + FT.length) % FT.length];
            int bh = Math.max(1, Math.min(h, (int) (v * 1.4f)));
            int col = alpha(mix(0x50FF70, 0xFF4040, Math.min(1f, v / 30f)), 1f);
            g.fill(x + n - 1 - i, y + h - bh, x + n - i, y + h, col);
        }
        Ui.d(g, String.format("%.1f ms  1%% low %d", ftAvg, (int) ftLow), x, y + h + 3, 0xFFCCCCDD, false);
    }

    private static final java.util.ArrayDeque<Long> CLK_L = new java.util.ArrayDeque<>(), CLK_R = new java.util.ArrayDeque<>();
    private static boolean clkLDown, clkRDown;

    /** Clicks per second (left | right), counted from the raw mouse state once per frame. */
    static void cps(GuiGraphics g, Minecraft mc, int sw, int sh) {
        long now = System.currentTimeMillis();
        long win = mc.getWindow().getWindow();
        boolean l = mc.screen == null && org.lwjgl.glfw.GLFW.glfwGetMouseButton(win, org.lwjgl.glfw.GLFW.GLFW_MOUSE_BUTTON_LEFT) == org.lwjgl.glfw.GLFW.GLFW_PRESS;
        boolean r = mc.screen == null && org.lwjgl.glfw.GLFW.glfwGetMouseButton(win, org.lwjgl.glfw.GLFW.GLFW_MOUSE_BUTTON_RIGHT) == org.lwjgl.glfw.GLFW.GLFW_PRESS;
        if (l && !clkLDown) CLK_L.add(now);
        if (r && !clkRDown) CLK_R.add(now);
        clkLDown = l;
        clkRDown = r;
        while (!CLK_L.isEmpty() && now - CLK_L.peekFirst() > 1000) CLK_L.pollFirst();
        while (!CLK_R.isEmpty() && now - CLK_R.peekFirst() > 1000) CLK_R.pollFirst();
        String t = CLK_L.size() + " | " + CLK_R.size() + " CPS";
        int w = Ui.w(t) + 10, x = sw / 2 - w / 2, y = sh - 62;
        rr(g, x, y, w, 14, 4, alpha(0x101018, 0.6f));
        Ui.d(g, t, x + 5, y + 3, alpha(accent(0f), 1f), false);
    }

    // ---------------------------------------------------------------- basics
    static void watermark(GuiGraphics g, Minecraft mc, Font font, int sw, int y) {
        String ping = "";
        if (mc.getConnection() != null) {
            var info = mc.getConnection().getPlayerInfo(mc.player.getUUID());
            if (info != null) ping = "  " + info.getLatency() + "ms";
        }
        String t = mc.getFps() + " fps" + ping;
        int w = Ui.w("PrettyClient") + Ui.w(t) + 22;
        int x = sw / 2 - w / 2;
        rr(g, x, y, w, 16, 4, alpha(0x101018, 0.75f));
        g.fillGradient(x + 2, y + 14, x + w - 2, y + 15, alpha(accent(0f), 1f), alpha(accent(0.25f), 1f));
        Ui.d(g, "PrettyClient", x + 5, y + 4, alpha(accent(0f), 1f), false);
        Ui.d(g, t, x + 5 + Ui.w("PrettyClient") + 8, y + 4, 0xFFCCCCDD, false);
    }

    static void arrayList(GuiGraphics g, Font font, int sw) {
        List<Mod> list = new ArrayList<>();
        for (Mod m : MODS) if (m.anim > 0.02f && m.cat != Cat.HUD) list.add(m);
        list.sort((a, b) -> Ui.w(b.name) - Ui.w(a.name));
        int y = 4;
        for (int i = 0; i < list.size(); i++) {
            Mod m = list.get(i);
            int w = Ui.w(m.name) + 10;
            int x = sw - w - 4 + (int) ((1 - ease(m.anim)) * (w + 8));
            rr(g, x, y, w, 12, 3, alpha(0x101018, 0.7f * m.anim));
            g.fill(x + w - 2, y + 2, x + w, y + 10, alpha(accent(i * 0.07f), m.anim));
            Ui.d(g, m.name, x + 4, y + 2, alpha(accent(i * 0.07f), m.anim), false);
            y += 13;
        }
    }

    static void coords(GuiGraphics g, Minecraft mc, Font font, int sh) {
        Player p = mc.player;
        String extra = "";
        if (mc.level.dimension() == Level.OVERWORLD)
            extra = String.format("   Nether %.0f %.0f", p.getX() / 8.0, p.getZ() / 8.0);
        else if (mc.level.dimension() == Level.NETHER)
            extra = String.format("   Overworld %.0f %.0f", p.getX() * 8.0, p.getZ() * 8.0);
        String s = String.format("XYZ  %.1f  %.1f  %.1f   %s%s", p.getX(), p.getY(), p.getZ(), p.getDirection().getName(), extra);
        int w = Ui.w(s) + 10;
        rr(g, 4, sh - 20, w, 14, 4, alpha(0x101018, 0.7f));
        Ui.d(g, s, 9, sh - 16, 0xFFEEEEF5, false);
    }

    static void info(GuiGraphics g, Font font, int sw, int y) {
        String s = String.format("%.1f b/s   %s", bps, LocalTime.now().format(CLOCK));
        int w = Ui.w(s) + 12;
        rr(g, sw / 2 - w / 2, y, w, 14, 4, alpha(0x101018, 0.7f));
        Ui.d(g, s, sw / 2 - w / 2 + 6, y + 4, alpha(accent(0.3f), 1f), false);
    }

    // ----------------------------------------------------------- new overlays
    static final String[] DIRS = {"S", "SW", "W", "NW", "N", "NE", "E", "SE"};

    static void compass(GuiGraphics g, Minecraft mc, int sw, int y) {
        int w = 170, x = sw / 2 - w / 2;
        rr(g, x, y, w, 14, 5, alpha(0x101018, 0.7f));
        float yaw = Mth.wrapDegrees(mc.player.getYRot());
        g.enableScissor(x + 2, y, x + w - 2, y + 14);
        for (int i = 0; i < 8; i++) {
            float ang = i * 45f;                         // 0 = south
            float diff = Mth.wrapDegrees(ang - yaw);
            if (Math.abs(diff) > 95) continue;
            float fade = 1f - Math.abs(diff) / 95f;
            int px = x + w / 2 + (int) (diff / 95f * (w / 2f - 12));
            boolean card = i % 2 == 0;
            String t = DIRS[i];
            Ui.d(g, t, px - Ui.w(t) / 2, y + 3, alpha(card ? accent(0f) : 0xB5C7BC, fade), false);
        }
        g.disableScissor();
        g.fill(x + w / 2, y + 11, x + w / 2 + 1, y + 13, alpha(0xFFFFFF, 0.9f));
    }

    static final long SESSION_START = System.currentTimeMillis();

    static void serverInfo(GuiGraphics g, Minecraft mc, int sw, int y) {
        String ip = mc.getCurrentServer() == null ? "Singleplayer" : mc.getCurrentServer().ip;
        String ping = "";
        int online = 0;
        if (mc.getConnection() != null) {
            var info = mc.getConnection().getPlayerInfo(mc.player.getUUID());
            if (info != null) ping = info.getLatency() + "ms   ";
            online = mc.getConnection().getOnlinePlayers().size();
        }
        long sec = (System.currentTimeMillis() - SESSION_START) / 1000;
        String s = ip + "   " + ping + online + " online   " + String.format("%d:%02d", sec / 60, sec % 60);
        int w = Ui.w(s) + 12;
        rr(g, sw / 2 - w / 2, y, w, 14, 4, alpha(0x101018, 0.7f));
        Ui.d(g, s, sw / 2 - w / 2 + 6, y + 4, alpha(accent(0.5f), 1f), false);
    }

    static int countItem(Player p, net.minecraft.world.item.Item... items) {
        int c = 0;
        for (int i = 0; i < p.getInventory().getContainerSize(); i++) {
            ItemStack st = p.getInventory().getItem(i);
            for (var it : items) if (st.is(it)) c += st.getCount();
        }
        return c;
    }

    static void itemCounter(GuiGraphics g, Minecraft mc, int sw, int sh) {
        Player p = mc.player;
        ItemStack[] icons = {
            new ItemStack(net.minecraft.world.item.Items.TOTEM_OF_UNDYING),
            new ItemStack(net.minecraft.world.item.Items.ENCHANTED_GOLDEN_APPLE),
            new ItemStack(net.minecraft.world.item.Items.ENDER_PEARL),
            new ItemStack(net.minecraft.world.item.Items.END_CRYSTAL),
            new ItemStack(net.minecraft.world.item.Items.ARROW)};
        int[] counts = {
            countItem(p, net.minecraft.world.item.Items.TOTEM_OF_UNDYING),
            countItem(p, net.minecraft.world.item.Items.ENCHANTED_GOLDEN_APPLE, net.minecraft.world.item.Items.GOLDEN_APPLE),
            countItem(p, net.minecraft.world.item.Items.ENDER_PEARL),
            countItem(p, net.minecraft.world.item.Items.END_CRYSTAL),
            countItem(p, net.minecraft.world.item.Items.ARROW)};
        int cell = 34, total = icons.length * cell;
        int x = sw / 2 - total / 2, y = sh - 76;
        rr(g, x - 4, y - 3, total + 8, 24, 6, alpha(0x101018, 0.55f));
        for (int i = 0; i < icons.length; i++) {
            int ix = x + i * cell;
            g.renderItem(icons[i], ix, y);
            String c = String.valueOf(counts[i]);
            Ui.d(g, c, ix + 17, y + 8, counts[i] == 0 ? 0xFF6A6A : alpha(0xFFFFFF, 1f), true);
        }
    }

    static void inventoryHud(GuiGraphics g, Minecraft mc, int sw, int sh) {
        int cell = 17, w = cell * 9 + 8, h = cell * 3 + 8;
        int x = sw - w - 6, y = sh / 2 + 42;
        rr(g, x, y, w, h, 5, alpha(0x101018, 0.6f));
        for (int i = 0; i < 27; i++) {
            ItemStack st = mc.player.getInventory().getItem(9 + i);
            int ix = x + 4 + (i % 9) * cell, iy = y + 4 + (i / 9) * cell;
            g.fill(ix, iy, ix + 16, iy + 16, alpha(0xFFFFFF, 0.05f));
            if (st.isEmpty()) continue;
            g.renderItem(st, ix, iy);
            g.renderItemDecorations(mc.font, st, ix, iy);
        }
    }

    // ----------------------------------------------------------------- radar
    static void radar(GuiGraphics g, Minecraft mc) {
        Mod rm = find("Radar");
        Player p = mc.player;
        int size = (int) rm.n("Size");
        double range = rm.n("Range");
        int x = 4, y = 26, cx, cy;
        Mod mini = find("Minimap");
        if (mini != null && mini.enabled && (int) mini.n("Corner") == 0)
            y += (int) mini.n("Size") + (mini.b("Coords") ? 24 : 10);
        cx = x + size / 2;
        cy = y + size / 2;
        rr(g, x, y, size, size, 5, alpha(0x101018, 0.72f));
        g.fill(cx, y + 3, cx + 1, y + size - 3, alpha(0xFFFFFF, 0.12f));
        g.fill(x + 3, cy, x + size - 3, cy + 1, alpha(0xFFFFFF, 0.12f));
        double yaw = p.getYRot() * Mth.DEG_TO_RAD;
        double sin = Math.sin(yaw), cos = Math.cos(yaw);
        double half = size / 2.0 - 3;
        for (Entity e : mc.level.entitiesForRendering()) {
            if (e == p || !(e instanceof LivingEntity le) || !le.isAlive()) continue;
            boolean pl = e instanceof Player, mob = e instanceof Monster, an = e instanceof Animal;
            if (!((pl && rm.b("Players")) || (mob && rm.b("Mobs")) || (an && rm.b("Animals")))) continue;
            Vec3 rel = e.position().subtract(p.position());
            double dr = rel.x * -cos + rel.z * -sin;
            double df = rel.x * -sin + rel.z * cos;
            double len = Math.sqrt(dr * dr + df * df);
            double k = len > range ? range / len : 1.0;
            int px = (int) (cx + dr * k / range * half);
            int py = (int) (cy - df * k / range * half);
            int col = pl ? 0x55E6FF : mob ? 0xFF5555 : 0x66FF66;
            g.fill(px - 1, py - 1, px + 2, py + 2, alpha(col, len > range ? 0.45f : 1f));
        }
        g.fill(cx - 1, cy - 1, cx + 2, cy + 2, alpha(accent(0f), 1f));
    }

    // ------------------------------------------------------------- armor hud
    // ------------------------------------------------------------ keystrokes
    static void keyBox(GuiGraphics g, Font font, int x, int y, int w, int h, String label, boolean down) {
        rr(g, x, y, w, h, 3, alpha(mix(0x14141e, accent(0f), down ? 0.55f : 0f), 0.75f));
        Ui.d(g, label, x + (w - Ui.w(label)) / 2, y + (h - 8) / 2, alpha(down ? 0xFFFFFF : 0xA8A8BC, 1f), false);
    }

    static void keystrokes(GuiGraphics g, Minecraft mc, Font font, int sh) {
        var o = mc.options;
        int x = 6, y = sh / 2 + 10;
        keyBox(g, font, x + 20, y, 18, 18, "W", o.keyUp.isDown());
        keyBox(g, font, x, y + 20, 18, 18, "A", o.keyLeft.isDown());
        keyBox(g, font, x + 20, y + 20, 18, 18, "S", o.keyDown.isDown());
        keyBox(g, font, x + 40, y + 20, 18, 18, "D", o.keyRight.isDown());
        keyBox(g, font, x, y + 40, 29, 18, "LMB " + CLICKS_L.size(), o.keyAttack.isDown());
        keyBox(g, font, x + 31, y + 40, 29, 18, "RMB " + CLICKS_R.size(), o.keyUse.isDown());
        keyBox(g, font, x, y + 60, 60, 12, "SPACE", o.keyJump.isDown());
    }

    // ----------------------------------------------------------------- potions
    static void potions(GuiGraphics g, Minecraft mc, Font font, int sh) {
        int y = sh - 38;
        for (MobEffectInstance e : mc.player.getActiveEffects()) {
            String name = e.getEffect().value().getDisplayName().getString() + " " + (e.getAmplifier() + 1);
            String time = e.isInfiniteDuration() ? "inf" : String.format("%d:%02d", e.getDuration() / 1200, (e.getDuration() / 20) % 60);
            String s = name + "  " + time;
            int w = Ui.w(s) + 10;
            rr(g, 4, y, w, 12, 3, alpha(0x101018, 0.7f));
            Ui.d(g, s, 9, y + 2, alpha(accent(y * 0.01f), 1f), false);
            y -= 13;
        }
    }

    // ---------------------------------------------------------------- targethud
    static void targetHud(GuiGraphics g, Minecraft mc, Font font, int sw, int sh, float dt) {
        long now = System.currentTimeMillis();
        LivingEntity t = target;
        if (t == null || !t.isAlive() || now - targetAt > 5000) return;
        float fade = Mth.clamp((5000 - (now - targetAt)) / 600f, 0f, 1f);
        int w = 132, h = 38, x = sw / 2 + 24, y = sh / 2 + 24;
        float hp = t.getHealth() + t.getAbsorptionAmount();
        float ratio = Mth.clamp(t.getHealth() / Math.max(1f, t.getMaxHealth()), 0f, 1f);
        targetHpAnim += (ratio - targetHpAnim) * Math.min(1f, dt * 8f);
        rr(g, x, y, w, h, 5, alpha(0x101018, 0.78f * fade));
        Ui.d(g, t.getName().getString(), x + 6, y + 5, alpha(0xFFFFFF, fade), false);
        String d = String.format("%.1fm", mc.player.distanceTo(t));
        Ui.d(g, d, x + w - 6 - Ui.w(d), y + 5, alpha(0xA8A8BC, fade), false);
        int bx = x + 6, by = y + 18, bw = w - 12;
        rr(g, bx, by, bw, 6, 3, alpha(0x2a2a3a, fade));
        int fw = Math.max(3, (int) (bw * targetHpAnim));
        int col = mix(0xFF3B3B, 0x40FF70, targetHpAnim);
        rr(g, bx, by, fw, 6, 3, alpha(col, fade));
        Ui.d(g, String.format("%.1f HP", hp), x + 6, y + 27, alpha(col, fade), false);
    }

    static void comboCounter(GuiGraphics g, Font font, int sw, int sh) {
        if (combo < 2) return;
        String s = "COMBO x" + combo;
        PoseStack ps = g.pose();
        ps.pushPose();
        ps.translate(sw / 2f, sh / 2f + 46, 0);
        ps.scale(1.6f, 1.6f, 1f);
        Ui.d(g, s, -Ui.w(s) / 2, 0, alpha(accent(combo * 0.05f), 1f), true);
        ps.popPose();
    }

    // ------------------------------------------------------------ notifications
    static void notifications(GuiGraphics g, Font font, int sw, int sh) {
        long now = System.currentTimeMillis();
        NOTES.removeIf(n -> now - n.at() > 2600);
        int y = sh - 30;
        for (int i = NOTES.size() - 1; i >= 0; i--) {
            Note n = NOTES.get(i);
            long age = now - n.at();
            float in = ease(age / 250f);
            float out = age > 2200 ? 1f - (age - 2200) / 400f : 1f;
            String s = n.text() + (n.on() ? "  enabled" : "  disabled");
            int w = Ui.w(s) + 16;
            int x = sw - w - 6 + (int) ((1f - in) * (w + 10));
            int col = n.on() ? accent(i * 0.1f) : 0xFF6A6A;
            rr(g, x, y, w, 16, 4, alpha(0x101018, 0.8f * out));
            g.fill(x + 2, y + 3, x + 4, y + 13, alpha(col, out));
            Ui.d(g, s, x + 8, y + 4, alpha(0xFFFFFF, out), false);
            y -= 19;
        }
    }

    // ------------------------------------------------------------------ welcome
    static void welcome(GuiGraphics g, Minecraft mc) {
        if (joinAt < 0) return;
        float t = (System.currentTimeMillis() - joinAt) / 1000f;
        float total = 5f;
        if (t > total) return;
        float al = t < 0.6f ? t / 0.6f : (t > total - 1f ? total - t : 1f);
        al = Mth.clamp(al, 0f, 1f);
        if (al < 0.06f) return;

        Font font = mc.font;
        String name = mc.getUser().getName();
        String hello = "WELCOME";
        int cx = g.guiWidth() / 2;
        int y = 30 + (int) ((1f - ease(t / 0.6f)) * -14f);
        int nameW = Ui.w(name) * 2;
        int bw = Math.max(nameW, Ui.w(hello)) + 40;

        rr(g, cx - bw / 2, y - 8, bw, 48, 6, alpha(0x101018, 0.8f * al));
        int lineW = (int) ((bw - 16) * ease(t / 1.0f));
        g.fillGradient(cx - lineW / 2, y + 38, cx + lineW / 2, y + 39, alpha(accent(0f), al), alpha(accent(0.3f), al));
        Ui.d(g, hello, cx - Ui.w(hello) / 2, y - 2, alpha(accent(0.5f), al), false);

        PoseStack ps = g.pose();
        ps.pushPose();
        ps.translate(cx, y + 12, 0);
        ps.scale(2f, 2f, 1f);
        Ui.d(g, name, -Ui.w(name) / 2, 0, alpha(accent(0f), al), false);
        ps.popPose();
    }

    static float handSwing;
    static long handLast;

    /**
     * Animated aura + sparkles over the first-person hands (bottom right of the screen).
     * Style 0 = aura (rainbow / accent), 1 = galaxy (violet-cyan, twinkling stars), 2 = fire (embers).
     * The swing reaction is smoothed per frame, layers keep the same total brightness at any quality.
     */
    static void shaderHands(GuiGraphics g, Minecraft mc, int sw, int sh) {
        if (!mc.options.getCameraType().isFirstPerson() || mc.screen != null || mc.player == null) return;
        Mod m = find("ShaderHands");
        float k = (float) m.n("Intensity"), size = (float) m.n("Size"), sp = (float) m.n("Speed");
        int layers = Math.max(4, (int) m.n("Layers")), style = (int) m.n("Style");
        boolean rainbow = m.b("Rainbow");
        long now = System.currentTimeMillis();
        float dt = Math.min(0.1f, (now - handLast) / 1000f);
        handLast = now;
        handSwing += (mc.player.getAttackAnim(0f) - handSwing) * (1f - (float) Math.exp(-dt * 14f));
        float t = (now % 1000000) / 1000f * sp;
        float swing = handSwing;
        int cy = (int) (sh * 0.90f);
        boolean both = m.b("Both hands") && !mc.player.getOffhandItem().isEmpty();
        float norm = 9f / layers;
        for (int side = 0; side < (both ? 2 : 1); side++) {
            int cx = (int) (sw * (side == 0 ? 0.80f : 0.20f));
            int rw = (int) (sw * 0.17f * size), rh = (int) (sh * 0.30f * size);
            for (int i = 0; i < layers; i++) {
                float f = 1f - i / (float) layers;
                int col;
                if (style == 1) col = mix(0x7A3DFF, 0x00D4FF, 0.5f + 0.5f * (float) Math.sin(t * 0.8 + i * 0.25));
                else if (style == 2) col = mix(0xFF3A00, 0xFFC400, f);
                else col = rainbow ? accent(i * 0.03f * norm + t * 0.05f) : accent(0f);
                float pulse = 0.75f + 0.25f * (float) Math.sin(t * 2.2 + i * 0.4);
                float a = 0.055f * norm * k * pulse * (1f + swing * 1.2f);
                int w = (int) (rw * (0.35f + f * 0.9f)), h = (int) (rh * (0.35f + f * 0.9f));
                rr(g, cx - w, cy - h, w * 2, h * 2, Math.min(w, h), alpha(col, a));
            }
            if (m.b("Shimmer")) {
                int n = style == 0 ? 14 : 24;
                for (int i = 0; i < n; i++) {
                    float ph = (t * (style == 2 ? 0.9f : 0.6f) + i * 0.37f) % 1f;
                    float px = cx - rw * 0.8f + (float) Math.sin(i * 12.9 + t * 0.7) * rw * 0.7f;
                    float py = cy + rh * 0.7f - ph * rh * 1.6f;
                    float a = (1f - ph) * ph * 4f * 0.55f * k;
                    int sc = style == 2 ? mix(0xFFE08A, 0xFF6A00, ph) : mix(0xFFFFFF, accent(i * 0.07f), style == 1 ? 0.25f : 0.5f);
                    if (style == 1) a *= 0.5f + 0.5f * (float) Math.sin(t * 4f + i * 1.7f);
                    int sz = style == 2 ? 3 : 2;
                    g.fill((int) px, (int) py, (int) px + sz, (int) py + sz, alpha(sc, a));
                }
            }
        }
    }

    /** Shows how many blocks you have while a block is in your hand. */
    static void blockCounter(GuiGraphics g, Minecraft mc, int sw, int sh) {
        Player p = mc.player;
        ItemStack held = p.getMainHandItem();
        if (!(held.getItem() instanceof net.minecraft.world.item.BlockItem)) return;
        int total = 0;
        for (int i = 0; i < p.getInventory().getContainerSize(); i++) {
            ItemStack s = p.getInventory().getItem(i);
            if (s.getItem() instanceof net.minecraft.world.item.BlockItem) total += s.getCount();
        }
        String t = total + " блоков";
        int w = Ui.w(t) + 30, x = sw / 2 - w / 2, y = sh - 66;
        rr(g, x, y, w, 20, 8, alpha(0x101814, 0.6f));
        g.renderItem(held, x + 4, y + 2);
        Ui.d(g, t, x + 24, y + 6, total < 16 ? 0xFFFF7A6A : 0xFFFFFFFF, false);
    }

    /** Armor next to the hotbar (icons, bars, percent) and the armor of the target you are hitting. */
    static void armorStatus(GuiGraphics g, Minecraft mc, int sw, int sh) {
        Mod am = find("ArmorStatus");
        EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
        drawArmorRow(g, mc.player, slots, sw / 2 + 108, sh - 46, am.b("Percent"), "Ты");
        long now = System.currentTimeMillis();
        LivingEntity t = target;
        if (am.b("Target armor") && t != null && t.isAlive() && now - targetAt < 5000) {
            drawArmorRow(g, t, slots, sw / 2 + 24, sh / 2 + 68, am.b("Percent"), t.getName().getString());
        }
    }

    static void drawArmorRow(GuiGraphics g, LivingEntity e, EquipmentSlot[] slots, int x0, int y, boolean pct, String title) {
        int cell = 26;
        rr(g, x0 - 4, y - 14, cell * 4 + 8, pct ? 48 : 38, 7, alpha(0x101814, 0.6f));
        Ui.d(g, title, x0, y - 11, alpha(accent(0f), 1f), false);
        for (int i = 0; i < 4; i++) {
            ItemStack st = e.getItemBySlot(slots[i]);
            int cx = x0 + i * cell + 4;
            if (st.isEmpty()) { rr(g, cx, y + 2, 16, 16, 3, alpha(0xFFFFFF, 0.07f)); continue; }
            g.renderItem(st, cx, y + 2);
            if (st.isDamageableItem()) {
                int p = 100 - st.getDamageValue() * 100 / Math.max(1, st.getMaxDamage());
                int col = mix(0xFF4040, 0x50FF70, p / 100f) | 0xFF000000;
                g.fill(cx, y + 20, cx + 16, y + 22, 0x99000000);
                g.fill(cx, y + 20, cx + 16 * p / 100, y + 22, col);
                if (pct) {
                    String s = p + "%";
                    Ui.d(g, s, cx + 8 - Ui.w(s) / 2, y + 24, col, false);
                }
            }
        }
    }
}
