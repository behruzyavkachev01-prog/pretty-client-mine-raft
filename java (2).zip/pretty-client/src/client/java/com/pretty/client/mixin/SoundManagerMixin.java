package com.pretty.client.mixin;

import com.pretty.client.Hooks;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.client.sounds.SoundManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** CrowdBoost: per-tick sound budget for far sounds while a crowd is around. */
@Mixin(SoundManager.class)
public class SoundManagerMixin {
    @Inject(method = "play(Lnet/minecraft/client/resources/sounds/SoundInstance;)V", at = @At("HEAD"), cancellable = true)
    private void pretty$budget(SoundInstance s, CallbackInfo ci) {
        if (!Hooks.allowSound(s)) ci.cancel();
    }
}
