package com.pretty.client;

import static com.pretty.client.PrettyClient.*;

import java.awt.Color;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import org.lwjgl.glfw.GLFW;

/**
 * Account manager (main menu): offline accounts without a password. Smooth open animation, eased hover,
 * search, add / random / delete, double click or "Войти" to switch the nickname.
 */
final class AccountsScreen extends Screen {
    private static final int PW = 300, ROW = 24, GAP = 4, VISIBLE = 5;

    private final Screen parent;
    private final Map<String, Float> hov = new HashMap<>();
    private final float[] btnHov = new float[6];
    private float open, closeAnim, scroll, scrollT, backHov, flash;
    private long last = System.nanoTime(), lastClick;
    private String query = "", input = "", selected, lastClicked, status = "";
    private boolean searching, adding, closing;
    private long statusAt;

    AccountsScreen(Screen parent) {
        super(Component.literal("Accounts"));
        this.parent = parent;
        AccountManager.load();
        selected = AccountManager.current;
    }

    // ------------------------------------------------------------ layout
    private int ph() { return 34 + VISIBLE * (ROW + GAP) + 40; }
    private int px() { return width / 2 - PW / 2; }
    private int py() { return Math.max(24, height / 2 - ph() / 2 - 10); }
    private int listTop() { return py() + 32; }
    private int listBot() { return listTop() + VISIBLE * (ROW + GAP) - GAP; }
    private int footY() { return py() + ph() - 30; }

    private List<String> filtered() {
        List<String> out = new ArrayList<>();
        String q = query.toLowerCase();
        for (String n : AccountManager.NAMES) if (q.isEmpty() || n.toLowerCase().contains(q)) out.add(n);
        return out;
    }

    /** Footer buttons: x, w for index. 0 delete, 1 add, 2 random, 3 login | adding: 4 ok, 5 cancel */
    private int[] btn(int i) {
        int x = px() + 10, right = px() + PW - 10;
        if (!adding) {
            int wLogin = 54, wRand = 64, wAdd = 58, wDel = 56;
            return switch (i) {
                case 3 -> new int[]{right - wLogin, wLogin};
                case 2 -> new int[]{right - wLogin - 4 - wRand, wRand};
                case 1 -> new int[]{right - wLogin - 4 - wRand - 4 - wAdd, wAdd};
                default -> new int[]{x, wDel};
            };
        }
        return i == 5 ? new int[]{right - 58, 58} : new int[]{right - 58 - 4 - 40, 40};
    }

    private static int avatar(String n) {
        return Color.HSBtoRGB((Math.abs(n.hashCode()) % 360) / 360f, 0.45f, 0.9f) & 0xFFFFFF;
    }

    private void say(String s) { status = s; statusAt = System.currentTimeMillis(); }

    // ------------------------------------------------------------ render
    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        long now = System.nanoTime();
        float dt = Math.min((now - last) / 1e9f, 0.05f);
        last = now;
        if (closing) closeAnim = Math.min(1f, closeAnim + dt * 5f);
        else open = Math.min(1f, open + dt * 3.2f);
        float e = ease(open) * (1f - ease(closeAnim));
        if (closing && closeAnim >= 1f) { minecraft.setScreen(parent); return; }
        flash = Math.max(0f, flash - dt * 2.5f);
        int acc = accent(0f);

        g.fill(0, 0, width, height, 0xFF030504);
        g.fillGradient(0, 0, width, height, 0xFF0A1A12, 0xFF020403);
        for (int i = 0; i < 48; i++) {
            float sx = ((i * 97) % 100) / 100f;
            float sp = 4f + (i % 5) * 3f;
            float t = (System.currentTimeMillis() % 1000000) / 1000f;
            float x = sx * width + (float) Math.sin(t * 0.5 + i) * 8f;
            float y = height - ((t * sp + ((i * 53) % 100) / 100f * height) % height);
            g.fill((int) x, (int) y, (int) x + 1, (int) y + 1, alpha(mix(0xFFFFFF, acc, 0.5f), 0.22f));
        }

        // back button
        boolean bh = mx >= 10 && mx <= 62 && my >= 10 && my <= 26;
        backHov += ((bh ? 1f : 0f) - backHov) * Math.min(1f, dt * 14f);
        rr(g, 10, 10, 52, 16, 5, alpha(mix(0x0B120E, mix(0x101A14, acc, 0.26f), backHov), 0.92f * e));
        Ui.center(g, "< Назад", 36, 14, alpha(mix(0xB5C7BC, 0xFFFFFF, backHov), e));
        Ui.center(g, "PrettyClient", width / 2, 12, alpha(mix(0xFFFFFF, acc, 0.4f), e));

        int x0 = px(), y0 = py() + (int) ((1f - e) * 16f);
        int ph = ph();
        // glow + panel
        for (int i = 3; i >= 1; i--) rr(g, x0 - i * 2, y0 - i * 2, PW + i * 4, ph + i * 4, 8 + i, alpha(acc, 0.03f * e));
        rr(g, x0 - 1, y0 - 1, PW + 2, ph + 2, 8, alpha(acc, (0.30f + 0.25f * flash) * e));
        rr(g, x0, y0, PW, ph, 7, alpha(0x08100C, 0.97f * e));

        // header
        Ui.d(g, "Аккаунты", x0 + 12, y0 + 11, alpha(0xFFFFFF, e), false);
        String cnt = String.valueOf(AccountManager.NAMES.size());
        int cw = Ui.w("Аккаунты");
        rr(g, x0 + 12 + cw + 6, y0 + 9, Ui.w(cnt) + 8, 11, 5, alpha(mix(0x101A14, acc, 0.35f), e));
        Ui.d(g, cnt, x0 + 12 + cw + 10, y0 + 11, alpha(mix(0xFFFFFF, acc, 0.5f), e), false);

        int sw = 116, sx = x0 + PW - 12 - sw;
        rr(g, sx, y0 + 7, sw, 15, 5, alpha(searching ? mix(0x111A15, acc, 0.2f) : 0x111A15, e));
        String sh = query.isEmpty() && !searching ? "Поиск аккаунта..."
            : query + (searching && (System.currentTimeMillis() / 500) % 2 == 0 ? "_" : "");
        Ui.d(g, sh, sx + 6, y0 + 11, alpha(query.isEmpty() ? 0x647A6D : 0xFFFFFF, e), false);

        // list
        List<String> list = filtered();
        int total = Math.max(0, list.size() * (ROW + GAP) - GAP);
        int viewH = VISIBLE * (ROW + GAP) - GAP;
        scrollT = Mth.clamp(scrollT, 0f, Math.max(0, total - viewH));
        scroll += (scrollT - scroll) * Math.min(1f, dt * 14f);
        int lt = y0 + 32;
        g.enableScissor(x0 + 6, lt - 1, x0 + PW - 6, lt + viewH + 1);
        if (list.isEmpty()) {
            Ui.center(g, AccountManager.NAMES.isEmpty() ? "Нет аккаунтов. Нажми «Добавить»" : "Ничего не найдено",
                x0 + PW / 2, lt + viewH / 2 - 4, alpha(0x647A6D, e));
        }
        for (int i = 0; i < list.size(); i++) {
            String n = list.get(i);
            float rowA = ease((e * 1.6f) - i * 0.08f);
            int y = lt + i * (ROW + GAP) - Math.round(scroll);
            if (y + ROW < lt || y > lt + viewH) continue;
            boolean over = mx >= x0 + 10 && mx <= x0 + PW - 10 && my >= Math.max(y, lt) && my <= Math.min(y + ROW, lt + viewH);
            float h = hov.getOrDefault(n, 0f);
            h += ((over ? 1f : 0f) - h) * Math.min(1f, dt * 14f);
            hov.put(n, h);
            boolean sel = n.equals(selected);
            boolean cur = n.equals(AccountManager.current);
            int rx = x0 + 10 + (int) ((1f - rowA) * -10f), rw = PW - 20;
            if (sel) rr(g, rx - 1, y - 1, rw + 2, ROW + 2, 6, alpha(acc, 0.55f * e * rowA));
            rr(g, rx, y, rw, ROW, 5, alpha(mix(mix(0x0E1611, 0x16221B, h), acc, sel ? 0.16f : 0f), 0.98f * e * rowA));
            int ac = avatar(n);
            rr(g, rx + 6, y + 5, 14, 14, 4, alpha(ac, e * rowA));
            String ini = n.substring(0, 1).toUpperCase();
            Ui.d(g, ini, rx + 13 - Ui.w(ini) / 2, y + 8, alpha(0x101010, e * rowA), false);
            Ui.d(g, n, rx + 27, y + 8, alpha(mix(0xC4D2CA, 0xFFFFFF, Math.max(h, sel ? 1f : 0f)), e * rowA), false);
            String tag = cur ? "активен" : "оффлайн";
            int tw = Ui.w(tag) + 10;
            rr(g, rx + rw - 8 - tw, y + 6, tw, 12, 4, alpha(cur ? mix(0x101A14, acc, 0.5f) : 0x1A231E, e * rowA));
            Ui.d(g, tag, rx + rw - 3 - tw, y + 8, alpha(cur ? 0xFFFFFF : 0x7C9A8A, e * rowA), false);
        }
        g.disableScissor();
        // scrollbar
        if (total > viewH) {
            int bh2 = Math.max(12, viewH * viewH / total);
            int by = lt + (int) ((viewH - bh2) * (scroll / Math.max(1f, total - viewH)));
            rr(g, x0 + PW - 6, by, 2, bh2, 1, alpha(acc, 0.6f * e));
        }

        // footer
        int fy = y0 + ph - 30;
        g.fill(x0 + 10, fy - 6, x0 + PW - 10, fy - 5, alpha(0xFFFFFF, 0.07f * e));
        if (!adding) {
            drawBtn(g, 0, "Удалить", fy, mx, my, dt, e, acc, false);
            drawBtn(g, 1, "Добавить", fy, mx, my, dt, e, acc, false);
            drawBtn(g, 2, "Случайный", fy, mx, my, dt, e, acc, false);
            drawBtn(g, 3, "Войти", fy, mx, my, dt, e, acc, true);
        } else {
            int fx = x0 + 10, fw = btn(4)[0] - 4 - fx;
            rr(g, fx - 1, fy - 1, fw + 2, 22, 6, alpha(acc, 0.5f * e));
            rr(g, fx, fy, fw, 20, 5, alpha(0x111A15, e));
            String shown = input.isEmpty() ? "Введи ник (3-16: a-z 0-9 _)" : input
                + ((System.currentTimeMillis() / 500) % 2 == 0 ? "_" : "");
            Ui.d(g, shown, fx + 7, fy + 6, alpha(input.isEmpty() ? 0x647A6D : 0xFFFFFF, e), false);
            drawBtn(g, 4, "OK", fy, mx, my, dt, e, acc, true);
            drawBtn(g, 5, "Отмена", fy, mx, my, dt, e, acc, false);
        }

        // status
        if (!status.isEmpty()) {
            long age = System.currentTimeMillis() - statusAt;
            if (age > 2600) status = "";
            else Ui.center(g, status, width / 2, y0 + ph + 8, alpha(0x9DB8A8, e * Mth.clamp((2600 - age) / 400f, 0f, 1f)));
        }
        Ui.d(g, "Оффлайн аккаунты: пароль не нужен", 10, height - 14, alpha(0x4C5F54, e), false);
        String now2 = "Сейчас: " + minecraft.getUser().getName();
        Ui.d(g, now2, width - 10 - Ui.w(now2), height - 14, alpha(0x7C9A8A, e), false);
    }

    private void drawBtn(GuiGraphics g, int i, String label, int fy, int mx, int my, float dt, float e, int acc, boolean primary) {
        int[] b = btn(i);
        boolean over = mx >= b[0] && mx <= b[0] + b[1] && my >= fy && my <= fy + 20;
        btnHov[i] += ((over ? 1f : 0f) - btnHov[i]) * Math.min(1f, dt * 14f);
        float h = btnHov[i];
        int bg = primary ? mix(mix(0x1D4A35, acc, 0.55f), 0xFFFFFF, h * 0.15f) : mix(0x111A15, mix(0x1B2B22, acc, 0.25f), h);
        rr(g, b[0], fy - (int) h, b[1], 20, 5, alpha(bg, e));
        Ui.center(g, label, b[0] + b[1] / 2, fy + 6 - (int) h, alpha(primary ? 0x04140C : mix(0xB5C7BC, 0xFFFFFF, h), e));
    }

    // ------------------------------------------------------------ actions
    private void click() { minecraft.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK, 1.0f)); }

    private void doLogin() {
        if (selected == null || !AccountManager.NAMES.contains(selected)) { say("Выбери аккаунт в списке"); return; }
        AccountManager.login(selected);
        flash = 1f;
        say("Вход выполнен: " + selected);
    }

    private void confirmAdd() {
        String n = input.trim();
        if (!AccountManager.valid(n)) { say("Ник: 3-16 символов, a-z 0-9 _"); return; }
        if (!AccountManager.add(n)) { say("Такой аккаунт уже есть"); return; }
        selected = n;
        adding = false;
        input = "";
        AccountManager.login(n);
        flash = 1f;
        say("Добавлен и активирован: " + n);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int btn) {
        if (btn != 0) return super.mouseClicked(mx, my, btn);
        boolean wasSearch = searching;
        searching = false;
        if (mx >= 10 && mx <= 62 && my >= 10 && my <= 26) { click(); onClose(); return true; }

        int x0 = px(), y0 = py();
        int sw = 116, sx = x0 + PW - 12 - sw;
        if (mx >= sx && mx <= sx + sw && my >= y0 + 7 && my <= y0 + 22) { searching = true; adding = false; return true; }

        int fy = y0 + ph() - 30;
        if (my >= fy && my <= fy + 20) {
            int[] ids = adding ? new int[]{4, 5} : new int[]{0, 1, 2, 3};
            for (int i : ids) {
                int[] b = btn(i);
                if (mx < b[0] || mx > b[0] + b[1]) continue;
                click();
                switch (i) {
                    case 0 -> {
                        if (selected != null && AccountManager.NAMES.contains(selected)) {
                            AccountManager.remove(selected);
                            say("Удалён: " + selected);
                            selected = null;
                        } else say("Выбери аккаунт для удаления");
                    }
                    case 1 -> { adding = true; input = ""; }
                    case 2 -> { adding = true; input = AccountManager.random(); }
                    case 3 -> doLogin();
                    case 4 -> confirmAdd();
                    default -> { adding = false; input = ""; }
                }
                return true;
            }
        }

        List<String> list = filtered();
        int lt = y0 + 32, viewH = VISIBLE * (ROW + GAP) - GAP;
        if (my >= lt && my <= lt + viewH && mx >= x0 + 10 && mx <= x0 + PW - 10) {
            int idx = (int) ((my - lt + Math.round(scroll)) / (ROW + GAP));
            double within = (my - lt + Math.round(scroll)) - idx * (ROW + GAP);
            if (idx >= 0 && idx < list.size() && within <= ROW) {
                String n = list.get(idx);
                long t = System.currentTimeMillis();
                if (n.equals(lastClicked) && t - lastClick < 350) { selected = n; doLogin(); }
                selected = n;
                lastClicked = n;
                lastClick = t;
                click();
                return true;
            }
        }
        if (wasSearch) return true;
        return super.mouseClicked(mx, my, btn);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double sx, double sy) {
        scrollT -= (float) (sy * 26.0);
        return true;
    }

    @Override
    public boolean charTyped(char c, int mods) {
        if (adding) {
            if (input.length() < 16 && (Character.isLetterOrDigit(c) && c < 128 || c == '_')) { input += c; return true; }
            return true;
        }
        if (searching && query.length() < 16 && c >= 32) {
            query += c;
            scrollT = 0;
            return true;
        }
        return super.charTyped(c, mods);
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (adding) {
            if (key == GLFW.GLFW_KEY_BACKSPACE && !input.isEmpty()) input = input.substring(0, input.length() - 1);
            else if (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) confirmAdd();
            else if (key == GLFW.GLFW_KEY_ESCAPE) { adding = false; input = ""; }
            return true;
        }
        if (searching) {
            if (key == GLFW.GLFW_KEY_BACKSPACE && !query.isEmpty()) { query = query.substring(0, query.length() - 1); return true; }
            if (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_ESCAPE) { searching = false; return true; }
        }
        if (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) { doLogin(); return true; }
        if (key == GLFW.GLFW_KEY_ESCAPE) { onClose(); return true; }
        return super.keyPressed(key, scan, mods);
    }

    @Override
    public void onClose() { closing = true; }

    @Override
    public boolean shouldCloseOnEsc() { return false; }

    @Override
    public boolean isPauseScreen() { return false; }
}
