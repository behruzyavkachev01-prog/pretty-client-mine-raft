package com.pretty.client.mixin;

import com.mojang.blaze3d.vertex.PoseStack;
import com.pretty.client.Hooks;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.state.EntityRenderState;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** CrowdBoost: no name tags on far players while a crowd is around. */
@Mixin(EntityRenderer.class)
public class EntityRendererMixin {
    @Inject(method = "renderNameTag(Lnet/minecraft/client/renderer/entity/state/EntityRenderState;Lnet/minecraft/network/chat/Component;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V",
        at = @At("HEAD"), cancellable = true)
    private void pretty$tag(EntityRenderState state, Component name, PoseStack ps, MultiBufferSource buf, int light, CallbackInfo ci) {
        if (Hooks.hideNameTag(state.distanceToCameraSq)) ci.cancel();
    }
}
