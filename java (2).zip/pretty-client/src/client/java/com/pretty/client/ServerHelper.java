package com.pretty.client;

import static com.pretty.client.PrettyClient.*;

import com.mojang.blaze3d.platform.InputConstants;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/**
 * Helpers for servers with custom items (FunTime, HolyWorld, ReallyWorld).
 * Every "action" is a one-shot bindable module: a key press switches to the item whose NAME contains one of the
 * keywords, uses it and switches back. Keywords live in config/prettyhelpers.txt (one "Action name=word|word" per line,
 * edit them if a server calls its items differently).
 */
final class ServerHelper {
    private ServerHelper() {}

    record Profile(String prefix, String master, String title, String[][] items) {}

    static final String[] DIS = {"Disorient", "дезориентация|дезориент"};
    static final String[] TRAP = {"Trap", "трапка|ловушка"};
    static final String[] PLAST = {"Plast", "пласт"};
    static final String[] DUST = {"Dust", "явная пыль|пыль"};
    static final String[] AURA = {"Aura", "божья аура|аура"};
    static final String[] WATER = {"HolyWater", "святая вода"};

    static final Profile[] PROFILES = {
        new Profile("FT", "FunTimeHelper", "FunTime", new String[][]{DIS, TRAP, PLAST, DUST, AURA}),
        new Profile("HW", "HolyWorldHelper", "HolyWorld", new String[][]{WATER, DIS, TRAP, PLAST, DUST}),
        new Profile("RW", "ReallyWorldHelper", "ReallyWorld", new String[][]{DIS, TRAP, PLAST, DUST, AURA}),
    };

    static final Map<String, String> KEYWORDS = new LinkedHashMap<>();
    static int backSlot = -1, backIn;
    static int fireworkCd;

    // =====================================================================
    //  Engine
    // =====================================================================
    static Predicate<ItemStack> named(String kws) {
        String[] parts = kws.toLowerCase().split("\\|");
        return st -> {
            if (st.isEmpty()) return false;
            String n = st.getHoverName().getString().toLowerCase();
            for (String k : parts) if (!k.isBlank() && n.contains(k.trim())) return true;
            return false;
        };
    }

    static ItemStack findStack(Player p, Predicate<ItemStack> f) {
        for (int i = 0; i < 9; i++) {
            ItemStack st = p.getInventory().getItem(i);
            if (f.test(st)) return st;
        }
        return ItemStack.EMPTY;
    }

    static void msg(Minecraft mc, String text) {
        if (mc.player != null) mc.player.displayClientMessage(Component.literal(text), true);
    }

    static boolean swapBack(String master) {
        Mod m = find(master);
        return m == null || !m.enabled || m.b("Swap back");
    }

    /** Switches to the first matching hotbar item, uses it and (optionally) switches back on the next tick. */
    static boolean use(Minecraft mc, Predicate<ItemStack> f, String label, boolean back) {
        Player p = mc.player;
        if (p == null || mc.gameMode == null) return false;
        int s = Modules.findHotbar(p, f);
        if (s < 0) {
            msg(mc, label + ": нет предмета в хотбаре");
            return false;
        }
        if (backSlot < 0) backSlot = p.getInventory().selected;
        p.getInventory().selected = s;
        mc.gameMode.useItem(p, InteractionHand.MAIN_HAND);
        p.swing(InteractionHand.MAIN_HAND);
        if (back) backIn = 2;
        else backSlot = -1;
        return true;
    }

    static void tick(Minecraft mc) {
        if (fireworkCd > 0) fireworkCd--;
        if (backSlot >= 0 && mc.player != null && --backIn <= 0) {
            mc.player.getInventory().selected = backSlot;
            backSlot = -1;
        }
    }

    static void elytraSwap(Minecraft mc) {
        Player p = mc.player;
        if (p == null || mc.gameMode == null) return;
        AbstractContainerMenu menu = p.inventoryMenu;
        boolean wearing = p.getItemBySlot(EquipmentSlot.CHEST).is(Items.ELYTRA);
        int src = -1;
        for (int i = 9; i <= 44; i++) {
            ItemStack st = menu.getSlot(i).getItem();
            if (st.isEmpty()) continue;
            if (wearing) {
                var eq = st.get(DataComponents.EQUIPPABLE);
                if (eq != null && eq.slot() == EquipmentSlot.CHEST && !st.is(Items.ELYTRA)) { src = i; break; }
            } else if (st.is(Items.ELYTRA)) { src = i; break; }
        }
        if (src < 0) { msg(mc, wearing ? "ElytraSwap: нет нагрудника в инвентаре" : "ElytraSwap: нет элитры в инвентаре"); return; }
        int cid = menu.containerId;
        mc.gameMode.handleInventoryMouseClick(cid, src, 0, ClickType.PICKUP, p);
        mc.gameMode.handleInventoryMouseClick(cid, 6, 0, ClickType.PICKUP, p);
        mc.gameMode.handleInventoryMouseClick(cid, src, 0, ClickType.PICKUP, p);
    }

    // =====================================================================
    //  Registration
    // =====================================================================
    static void register() {
        loadKeywords();

        // ---- universal one-shot actions (bind a key in the ClickGUI with the middle mouse button)
        add(new Mod("UsePearl", Cat.PLAYER).action()
            .d("Одно нажатие бинда: достаёт жемчуг Края из хотбара, бросает и возвращает прежний слот.")
            .start((mc, m) -> use(mc, s -> s.is(Items.ENDER_PEARL), "Жемчуг", true)));
        add(new Mod("UseFirework", Cat.PLAYER).action()
            .d("Бинд: использует фейерверк из хотбара (ускорение на элитре) и возвращает слот.")
            .start((mc, m) -> use(mc, s -> s.is(Items.FIREWORK_ROCKET), "Фейерверк", true)));
        add(new Mod("UseWindCharge", Cat.PLAYER).action()
            .d("Бинд: бросает заряд ветра из хотбара и возвращает слот.")
            .start((mc, m) -> use(mc, s -> s.is(Items.WIND_CHARGE), "Заряд ветра", true)));
        add(new Mod("ElytraSwap", Cat.PLAYER).action()
            .d("Бинд: меняет нагрудник на элитру и обратно прямо из инвентаря.")
            .start((mc, m) -> elytraSwap(mc)));

        add(new Mod("AutoFirework", Cat.PLAYER).with(new Num("Delay sec", 1, 6, 3, 0.5), new Num("Min speed", 0.2, 2.0, 0.9, 0.1))
            .d("Пока летишь на элитре и скорость падает, сам запускает фейерверк из хотбара.")
            .tick((mc, m) -> {
                Player p = mc.player;
                if (!p.isFallFlying() || fireworkCd > 0) return;
                if (p.getDeltaMovement().length() > m.n("Min speed")) return;
                if (use(mc, s -> s.is(Items.FIREWORK_ROCKET), "Фейерверк", true)) fireworkCd = (int) (m.n("Delay sec") * 20);
            }));

        // ---- server helpers
        for (Profile pr : PROFILES) {
            add(new Mod(pr.master(), Cat.OTHER).with(new Bool("Panel", true), new Bool("Swap back", true))
                .d("Помощник для сервера " + pr.title() + ": панель с кастомными предметами из хотбара (готов / перезарядка) "
                    + "и биндами. Сами действия (" + pr.prefix() + " ...) назначаешь на клавиши в ClickGUI средней кнопкой мыши."));
            for (String[] it : pr.items()) {
                String name = pr.prefix() + " " + it[0];
                KEYWORDS.putIfAbsent(name, it[1]);
                final String master = pr.master();
                add(new Mod(name, Cat.OTHER).action()
                    .d("Бинд: находит в хотбаре предмет с названием «" + KEYWORDS.get(name) + "», использует его и возвращает слот. "
                        + "Слова для поиска меняются в config/prettyhelpers.txt.")
                    .start((mc, m) -> use(mc, named(KEYWORDS.get(m.name)), it[0], swapBack(master))));
            }
        }
    }

    // =====================================================================
    //  Keywords file
    // =====================================================================
    static Path file() { return PrettyClient.cfgFile("prettyhelpers.txt"); }

    static void loadKeywords() {
        // defaults first
        for (Profile pr : PROFILES) for (String[] it : pr.items()) KEYWORDS.put(pr.prefix() + " " + it[0], it[1]);
        try {
            Path f = file();
            if (!Files.exists(f)) {
                List<String> out = new ArrayList<>();
                out.add("# Action name=word|word   (item name must contain one of the words, case does not matter)");
                for (Map.Entry<String, String> e : KEYWORDS.entrySet()) out.add(e.getKey() + "=" + e.getValue());
                Files.write(f, out);
                return;
            }
            for (String line : Files.readAllLines(f)) {
                line = line.trim();
                if (line.isEmpty() || line.startsWith("#")) continue;
                int i = line.indexOf('=');
                if (i > 0 && KEYWORDS.containsKey(line.substring(0, i).trim())) KEYWORDS.put(line.substring(0, i).trim(), line.substring(i + 1).trim());
            }
        } catch (IOException | RuntimeException ignored) {
        }
    }

    // =====================================================================
    //  HUD panel
    // =====================================================================
    static void panels(GuiGraphics g, Minecraft mc, int sw, int sh) {
        if (mc.player == null) return;
        int y = sh / 2 - 30;
        for (Profile pr : PROFILES) {
            Mod master = find(pr.master());
            if (master == null || !master.enabled || !master.b("Panel")) continue;
            int rows = pr.items().length, w = 150, h = 18 + rows * 18;
            int x = sw - w - 6;
            rr(g, x, y, w, h, 7, alpha(0x101814, 0.62f));
            Ui.d(g, pr.title() + " helper", x + 7, y + 5, alpha(accent(0f), 1f), false);
            int yy = y + 18;
            for (String[] it : pr.items()) {
                Mod a = find(pr.prefix() + " " + it[0]);
                ItemStack st = findStack(mc.player, named(KEYWORDS.get(a.name)));
                boolean has = !st.isEmpty();
                if (has) g.renderItem(st, x + 4, yy);
                String key = a.key >= 0 ? InputConstants.getKey(a.key, 0).getDisplayName().getString() : "-";
                String state = !has ? "нет" : mc.player.getCooldowns().isOnCooldown(st) ? "КД" : "готов";
                int col = !has ? 0xFF8A8A8A : state.equals("КД") ? 0xFFFFB84D : 0xFF6DFF8B;
                Ui.d(g, it[0] + "  [" + key + "]", x + 24, yy + 4, 0xFFFFFFFF, false);
                Ui.d(g, state, x + w - 8 - Ui.w(state), yy + 4, col, false);
                yy += 18;
            }
            y += h + 6;
        }
    }
}
