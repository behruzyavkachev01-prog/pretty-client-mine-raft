package com.pretty.client.mixin;

import com.pretty.client.Hooks;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleEngine;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** CrowdBoost: particle budget per tick and no far particles while a crowd is around. */
@Mixin(ParticleEngine.class)
public class ParticleEngineMixin {
    @Inject(method = "add(Lnet/minecraft/client/particle/Particle;)V", at = @At("HEAD"), cancellable = true)
    private void pretty$cap(Particle p, CallbackInfo ci) {
        if (!Hooks.allowParticle(p)) ci.cancel();
    }
}
