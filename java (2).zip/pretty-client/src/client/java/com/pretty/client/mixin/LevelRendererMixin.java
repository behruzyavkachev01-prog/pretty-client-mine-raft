package com.pretty.client.mixin;

import com.pretty.client.Hooks;
import net.minecraft.client.renderer.LevelRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;

/** ChunkFade: shifts the per-section offset uniform, so new chunk sections rise smoothly into place. Vanilla renderer only. */
@Mixin(LevelRenderer.class)
public class LevelRendererMixin {
    @ModifyArgs(method = "renderSectionLayer",
        at = @At(value = "INVOKE", target = "Lcom/mojang/blaze3d/shaders/Uniform;set(FFF)V"))
    private void pretty$chunkRise(Args args) {
        float x = args.get(0), y = args.get(1), z = args.get(2);
        float dy = Hooks.chunkRise(x, y, z);
        if (dy != 0f) args.set(1, y + dy);
    }
}
